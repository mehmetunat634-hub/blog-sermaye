'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { Search, User, LogIn, ArrowLeft, ReceiptText } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/lib/AuthContext';
import { mockApps } from '@/lib/data';

export default function Navbar() {
  const { user } = useAuth();
  const pathname = usePathname();

  const currentApp = mockApps.find(app => pathname?.startsWith(`/${app.slug}`));
  const isInApp = !!currentApp;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {isInApp ? (
            <Link href="/" className="flex items-center space-x-3 group">
              <motion.div
                initial={{ rotate: 180, opacity: 0 }}
                animate={{ rotate: 0, opacity: 1 }}
                className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-gray-700 group-hover:bg-gray-900 group-hover:text-white transition-all"
              >
                <ArrowLeft className="h-5 w-5" />
              </motion.div>
              <div>
                <span className="text-sm font-bold text-gray-900 leading-tight block group-hover:text-blue-600 transition-colors">
                  {currentApp.name}
                </span>
                <span className="text-xs text-gray-400 font-medium">ParasızSepet'e Dön</span>
              </div>
            </Link>
          ) : (
            <Link href="/" className="flex items-center space-x-2">
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-xl"
              >
                P
              </motion.div>
              <span className="text-xl font-semibold tracking-tight text-gray-900">ParasızSepet</span>
            </Link>
          )}

          {/* Search Bar - only show on main site */}
          {!isInApp && (
            <div className="flex-1 max-w-md mx-8 hidden sm:block">
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-5 w-5 text-gray-400 group-focus-within:text-blue-500 transition-colors" />
                </div>
                <input
                  type="text"
                  placeholder="Uygulama ara..."
                  className="block w-full pl-10 pr-3 py-2 border border-gray-200 rounded-2xl bg-gray-50 text-sm placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
                />
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center space-x-4">
            {!isInApp && (
              <>
                <Link href="/about" className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
                  Hakkımızda
                </Link>
                {user?.role === 'admin' && (
                  <Link href="/admin" className="text-sm font-medium text-blue-600 hover:text-blue-800 transition-colors">
                    Admin
                  </Link>
                )}
              </>
            )}
            {user ? (
              <Link
                href="/profile"
                className="flex items-center space-x-2 px-4 py-2 bg-gray-900 text-white rounded-xl text-sm font-bold hover:bg-gray-800 transition-all"
              >
                <User className="h-4 w-4" />
                <span className="hidden sm:inline">{user.name.split(' ')[0]}</span>
              </Link>
            ) : (
              <Link
                href="/login"
                className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all"
              >
                <LogIn className="h-4 w-4" />
                <span className="hidden sm:inline">Giriş Yap</span>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
