'use client';

import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, Info, X } from 'lucide-react';

type ToastType = 'success' | 'error' | 'info';

interface Toast {
  id: number;
  message: string;
  type: ToastType;
}

interface ToastContextType {
  show: (message: string, type?: ToastType) => void;
}

const ToastContext = createContext<ToastContextType | null>(null);

let nextId = 0;

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const show = useCallback((message: string, type: ToastType = 'info') => {
    const id = nextId++;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3500);
  }, []);

  const remove = (id: number) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  };

  return (
    <ToastContext.Provider value={{ show }}>
      {children}

      <div className="fixed top-20 right-6 z-[60] flex flex-col space-y-2 max-w-sm w-full pointer-events-none">
        <AnimatePresence>
          {toasts.map((toast) => {
            const Icon = toast.type === 'success' ? CheckCircle
              : toast.type === 'error' ? XCircle
              : Info;

            const borderColor = toast.type === 'success' ? 'border-l-emerald-500'
              : toast.type === 'error' ? 'border-l-red-500'
              : 'border-l-blue-500';

            const iconColor = toast.type === 'success' ? 'text-emerald-500'
              : toast.type === 'error' ? 'text-red-500'
              : 'text-blue-500';

            return (
              <motion.div
                key={toast.id}
                initial={{ opacity: 0, x: 100, scale: 0.95 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: 100, scale: 0.95 }}
                className={`bg-white border border-gray-200 border-l-4 ${borderColor} rounded-2xl shadow-lg p-4 pointer-events-auto flex items-start space-x-3`}
              >
                <Icon className={`h-5 w-5 flex-shrink-0 mt-0.5 ${iconColor}`} />
                <p className="flex-grow text-sm font-medium text-gray-900">{toast.message}</p>
                <button
                  onClick={() => remove(toast.id)}
                  className="text-gray-400 hover:text-gray-600 transition-colors flex-shrink-0"
                >
                  <X className="h-4 w-4" />
                </button>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
}
