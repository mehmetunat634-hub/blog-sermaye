'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import { Star } from 'lucide-react';
import { WebApp } from '@/lib/data';

interface AppCardProps {
  app: WebApp;
}

export default function AppCard({ app }: AppCardProps) {
  return (
    <Link href={`/${app.slug}`}>
      <motion.div
        whileHover={{ y: -4, transition: { duration: 0.2 } }}
        className="group flex flex-col p-4 rounded-3xl transition-all hover:bg-gray-50"
      >
        {/* Icon Container */}
        <div className="relative aspect-square w-full mb-4 overflow-hidden rounded-2xl bg-gray-100 flex items-center justify-center text-5xl shadow-sm group-hover:shadow-md transition-shadow">
          {app.icon}
        </div>

        {/* Details */}
        <div className="flex flex-col space-y-1">
          <h3 className="font-semibold text-gray-900 line-clamp-2 leading-tight">
            {app.name}
          </h3>
          <p className="text-sm text-gray-500 truncate">{app.category}</p>
          
          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center space-x-1">
              <span className="text-sm font-medium text-gray-700">{app.rating}</span>
              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
            </div>
            <span className="text-sm font-semibold text-blue-600">
              {app.price === 0 ? 'Ücretsiz' : `${app.price} TL / ay`}
            </span>
          </div>
        </div>
      </motion.div>
    </Link>
  );
}
