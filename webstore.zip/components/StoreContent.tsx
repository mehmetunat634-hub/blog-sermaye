'use client';

import { useState } from 'react';
import Link from 'next/link';
import { mockApps } from '@/lib/data';
import AppCard from '@/components/AppCard';
import { ChevronRight } from 'lucide-react';

export default function StoreContent() {
  const [activeCategory, setActiveCategory] = useState('Hepsi');

  const categories = ['Hepsi', ...Array.from(new Set(mockApps.map(app => app.category)))];

  const filteredApps = activeCategory === 'Hepsi'
    ? mockApps
    : mockApps.filter(app => app.category === activeCategory);

  if (mockApps.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-50 rounded-3xl mb-8 text-blue-600">
          <svg className="w-10 h-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
        </div>
        <h2 className="text-3xl font-bold text-gray-900 tracking-tight mb-4">Sepetiniz Şimdilik Boş</h2>
        <p className="text-gray-500 max-w-md mx-auto text-lg">
          ParasızSepet'in ilk uygulamaları yolda. Çok yakında ilk uygulamamız olan <strong>Adisyon</strong> ile buradayız.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section / Categories */}
      <section className="mb-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Kategoriler</h2>
          <Link
            href="/categories"
            className="text-blue-600 font-medium flex items-center hover:underline"
          >
            Tümünü gör <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
        <div className="flex space-x-4 overflow-x-auto pb-4 scrollbar-hide">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full whitespace-nowrap font-bold text-sm transition-all ${
                activeCategory === category
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'border border-gray-200 text-gray-600 hover:bg-gray-50 hover:border-blue-500 hover:text-blue-600'
              }`}
            >
              {category}
            </button>
          ))}
        </div>
      </section>

      {/* Featured Apps */}
      <section className="mb-16">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 tracking-tight">
              {activeCategory === 'Hepsi' ? 'Popüler Uygulamalar' : `${activeCategory}`}
            </h2>
            <p className="text-gray-500">
              {activeCategory === 'Hepsi'
                ? 'Editörlerimizin seçtiği en iyi web uygulamaları'
                : `${activeCategory} kategorisindeki uygulamalar`}
            </p>
          </div>
        </div>

        {filteredApps.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
            {filteredApps.map((app) => (
              <AppCard key={app.id} app={app} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 text-gray-400 font-medium">
            Bu kategoride henüz uygulama bulunmuyor.
          </div>
        )}
      </section>

      {/* New Releases */}
      {activeCategory === 'Hepsi' && (
        <section className="mb-16">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Yeni Çıkanlar</h2>
              <p className="text-gray-500">En son eklenen yetenekli araçlar</p>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
            {filteredApps.slice().reverse().map((app) => (
              <AppCard key={app.id} app={app} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
