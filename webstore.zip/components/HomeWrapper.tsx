'use client';

import StoreGate from '@/components/StoreGate';

export default function HomeWrapper({ children }: { children: React.ReactNode }) {
  return <StoreGate>{children}</StoreGate>;
}
