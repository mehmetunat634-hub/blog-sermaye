'use client';

import StoreGate from '@/components/StoreGate';

export default function StoreGateWrapper({ children }: { children: React.ReactNode }) {
  return <StoreGate>{children}</StoreGate>;
}
