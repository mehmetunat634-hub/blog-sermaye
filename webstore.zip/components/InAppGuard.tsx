'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { useAdisyonRole } from '@/lib/adisyon/AdisyonRoleContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Shield, UserCog, Users, Eye, EyeOff, ArrowLeft } from 'lucide-react';

const STORAGE_KEY = 'in_app_unlocked_adisyon';

type Step = 'select' | 'owner-password' | 'staff-password';

export default function InAppGuard({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const { setRole } = useAdisyonRole();
  const [unlocked, setUnlocked] = useState(false);
  const [step, setStep] = useState<Step>('select');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [verifying, setVerifying] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const stored = sessionStorage.getItem(STORAGE_KEY);
      if (stored === 'true') {
        setUnlocked(true);
        setStep('select');
      }
    }
  }, []);

  const handleOwnerLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setVerifying(true);
    try {
      const token = localStorage.getItem('token');
      if (!token) throw new Error('Oturum bulunamadı');

      const res = await fetch('/api/auth/verify-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      sessionStorage.setItem(STORAGE_KEY, 'true');
      sessionStorage.setItem('in_app_role', 'owner');
      setRole({ type: 'owner', name: 'Sahip' });
      setUnlocked(true);
      setPassword('');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setVerifying(false);
    }
  };

  const handleStaffLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setVerifying(true);
    try {
      const res = await fetch('/api/adisyon/staff-login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      sessionStorage.setItem(STORAGE_KEY, 'true');
      sessionStorage.setItem('in_app_role', data.role.name);
      setRole({ type: 'staff', name: data.role.name });
      setUnlocked(true);
      setPassword('');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setVerifying(false);
    }
  };

  if (loading) return <>{children}</>;

  const renderSelect = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full max-w-sm text-center space-y-8"
    >
      <div className="space-y-4">
        <div className="w-20 h-20 bg-amber-50 rounded-3xl flex items-center justify-center mx-auto">
          <Shield className="h-10 w-10 text-amber-600" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Adisyon</h1>
          <p className="text-gray-500 mt-2">Giriş yöntemi seçin</p>
        </div>
      </div>

      <div className="space-y-4">
        <button
          onClick={() => { setStep('owner-password'); setError(''); setPassword(''); }}
          className="w-full p-5 bg-gray-900 text-white rounded-2xl text-left flex items-center space-x-4 hover:bg-gray-800 transition-all active:scale-[0.98]"
        >
          <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center flex-shrink-0">
            <UserCog className="h-6 w-6" />
          </div>
          <div>
            <div className="font-bold">Ana Hesap</div>
            <div className="text-sm text-gray-400 font-medium">Tam yetkili yönetici girişi</div>
          </div>
        </button>

        <button
          onClick={() => { setStep('staff-password'); setError(''); setPassword(''); }}
          className="w-full p-5 bg-amber-50 border-2 border-amber-200 text-gray-900 rounded-2xl text-left flex items-center space-x-4 hover:bg-amber-100 transition-all active:scale-[0.98]"
        >
          <div className="w-12 h-12 bg-amber-200 rounded-xl flex items-center justify-center flex-shrink-0">
            <Users className="h-6 w-6 text-amber-700" />
          </div>
          <div>
            <div className="font-bold">Personel Girişi</div>
            <div className="text-sm text-gray-500 font-medium">Rol şifreniz ile giriş</div>
          </div>
        </button>
      </div>
    </motion.div>
  );

  const renderPassword = (type: 'owner' | 'staff') => (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="w-full max-w-sm text-center space-y-8"
    >
      <div className="space-y-4">
        <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto">
          <Shield className="h-10 w-10 text-gray-900" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">
            {type === 'owner' ? 'Ana Hesap' : 'Personel Girişi'}
          </h1>
          <p className="text-gray-500 mt-2">
            {type === 'owner'
              ? `Merhaba, ${user?.name}. Şifrenizi girin.`
              : 'Rol şifrenizi girin.'}
          </p>
        </div>
      </div>

      <form onSubmit={type === 'owner' ? handleOwnerLogin : handleStaffLogin} className="space-y-4">
        {error && (
          <div className="p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium">{error}</div>
        )}

        <div className="relative">
          <input
            type={showPassword ? 'text' : 'password'}
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Şifre"
            autoFocus
            className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-amber-500/10 focus:border-amber-500 transition-all pr-12"
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
          >
            {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </button>
        </div>

        <button
          type="submit"
          disabled={!password || verifying}
          className="w-full py-4 bg-amber-600 text-white font-bold rounded-2xl hover:bg-amber-700 transition-all active:scale-[0.98] disabled:opacity-50"
        >
          {verifying ? (
            <div className="flex items-center justify-center space-x-2">
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Doğrulanıyor...</span>
            </div>
          ) : (
            'Giriş Yap'
          )}
        </button>

        <button
          type="button"
          onClick={() => { setStep('select'); setError(''); setPassword(''); setShowPassword(false); }}
          className="flex items-center justify-center space-x-2 text-sm text-gray-500 hover:text-gray-900 font-medium mx-auto transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Geri dön</span>
        </button>
      </form>
    </motion.div>
  );

  return (
    <>
      <AnimatePresence mode="wait">
        {!unlocked && user && (
          <motion.div
            key="overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-white flex items-center justify-center p-4"
          >
            {step === 'select' && renderSelect()}
            {step === 'owner-password' && renderPassword('owner')}
            {step === 'staff-password' && renderPassword('staff')}
          </motion.div>
        )}
      </AnimatePresence>

      {children}
    </>
  );
}
