'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Table, ChefHat, BarChart3, CalendarDays, Settings, ReceiptText, LogOut } from 'lucide-react';
import { useAdisyonRole } from '@/lib/adisyon/AdisyonRoleContext';

export default function Sidebar() {
  const pathname = usePathname();
  const { role, isOwner, roleName, setRole } = useAdisyonRole();

  const navItems = [
    { href: '/adisyon', label: 'Dashboard', icon: LayoutDashboard, roles: ['owner', 'staff'] as const },
    { href: '/adisyon/tables', label: 'Masalar', icon: Table, roles: ['owner', 'staff'] as const },
    { href: '/adisyon/kitchen', label: 'Mutfak', icon: ChefHat, roles: ['owner', 'staff'] as const },
    { href: '/adisyon/reports', label: 'Raporlar', icon: BarChart3, roles: ['owner'] as const },
    { href: '/adisyon/reservations', label: 'Rezervasyonlar', icon: CalendarDays, roles: ['owner'] as const },
    { href: '/adisyon/ayarlar', label: 'Ayarlar', icon: Settings, roles: ['owner'] as const },
  ];

  const visibleItems = navItems.filter(item => {
    if (isOwner) return (item.roles as readonly string[]).includes('owner');
    return (item.roles as readonly string[]).includes('staff');
  });

  const handleLogout = () => {
    sessionStorage.removeItem('in_app_unlocked_adisyon');
    sessionStorage.removeItem('in_app_role');
    setRole(null);
  };

  return (
    <aside className="w-64 bg-gray-900 min-h-screen flex flex-col flex-shrink-0">
      {/* Logo */}
      <div className="p-6 border-b border-gray-800">
        <Link href="/adisyon" className="flex items-center space-x-3">
          <div className="w-9 h-9 bg-blue-600 rounded-xl flex items-center justify-center text-white">
            <ReceiptText className="h-5 w-5" />
          </div>
          <div>
            <h1 className="font-bold text-white text-sm leading-tight">Adisyon</h1>
            <p className="text-[10px] text-gray-500 font-medium">Restoran Yönetimi</p>
          </div>
        </Link>
      </div>

      {/* Role badge */}
      <div className="px-6 py-3 border-b border-gray-800">
        <div className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${
          isOwner ? 'bg-amber-500/10 text-amber-400' : 'bg-emerald-500/10 text-emerald-400'
        }`}>
          <div className={`w-1.5 h-1.5 rounded-full ${isOwner ? 'bg-amber-400' : 'bg-emerald-400'}`} />
          <span>{roleName}</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-grow p-4 space-y-1">
        {visibleItems.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href || (item.href !== '/adisyon' && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              }`}
            >
              <Icon className="h-5 w-5 flex-shrink-0" />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-gray-800 space-y-2">
        <button
          onClick={handleLogout}
          className="w-full flex items-center space-x-2 px-4 py-2 text-xs text-gray-500 hover:text-red-400 font-medium transition-colors"
        >
          <LogOut className="h-4 w-4" />
          <span>Uygulamadan Çık</span>
        </button>
        <Link
          href="/"
          className="flex items-center space-x-2 px-4 py-2 text-xs text-gray-500 hover:text-gray-300 font-medium transition-colors"
        >
          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
          </svg>
          <span>ParasızSepet</span>
        </Link>
      </div>
    </aside>
  );
}
