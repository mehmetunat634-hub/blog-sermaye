'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, PlusCircle, BarChart3, Settings, Megaphone } from 'lucide-react';

const NAV_ITEMS = [
  { href: '/golet/panel', label: 'İlanlarım', icon: LayoutDashboard },
  { href: '/golet/panel/ilan-ekle', label: 'Yeni İlan', icon: PlusCircle },
  { href: '/golet/panel/istatistikler', label: 'İstatistikler', icon: BarChart3 },
  { href: '/golet/panel/ayarlar', label: 'Ayarlar', icon: Settings },
];

export default function GoletSidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 flex-shrink-0 bg-white border-r border-gray-100 min-h-[calc(100vh-4rem)] py-6 px-3 hidden lg:block">
      <div className="px-4 mb-6">
        <Link href="/golet/panel" className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-pink-500 rounded-lg flex items-center justify-center text-white">
            <Megaphone className="h-4 w-4" />
          </div>
          <span className="font-bold text-gray-900">GoLet Panel</span>
        </Link>
      </div>
      <nav className="space-y-1">
        {NAV_ITEMS.map(item => {
          const isActive = pathname === item.href || (item.href !== '/golet/panel' && pathname.startsWith(item.href));
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}
              className={`flex items-center space-x-3 px-4 py-3 rounded-2xl text-sm font-medium transition-all ${
                isActive ? 'bg-orange-50 text-orange-700' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}>
              <Icon className={`h-5 w-5 ${isActive ? 'text-orange-600' : 'text-gray-400'}`} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="mt-8 px-4">
        <Link href="/golet"
          className="block text-center px-4 py-2.5 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all text-sm">
          İlanlara Dön
        </Link>
      </div>
    </aside>
  );
}
