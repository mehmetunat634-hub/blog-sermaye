'use client';

import { useState, useEffect } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/Toast';
import { motion } from 'framer-motion';
import {
  Sparkles,
  Search,
  ShoppingBag,
  MessageCircle,
  BarChart3,
  Settings,
  ShoppingCart,
  Shield,
  Check,
  Loader2,
} from 'lucide-react';
import Link from 'next/link';

interface Props {
  children: React.ReactNode;
}

export default function GoletPurchaseGuard({ children }: Props) {
  const { user, refreshUser } = useAuth();
  const toast = useToast();
  const [purchased, setPurchased] = useState<boolean | null>(null);
  const [purchasing, setPurchasing] = useState(false);
  const [balanceError, setBalanceError] = useState(false);

  useEffect(() => {
    checkPurchase();
  }, []);

  async function checkPurchase() {
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/apps/purchases', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        const hasIt = data.purchases?.some((p: any) => p.app_slug === 'golet');
        setPurchased(!!hasIt);
      } else {
        setPurchased(false);
      }
    } catch {
      setPurchased(false);
    }
  }

  async function handlePurchase() {
    setPurchasing(true);
    setBalanceError(false);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/apps/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ appSlug: 'golet' }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 402) {
          setBalanceError(true);
          throw new Error('Yetersiz bakiye');
        }
        throw new Error(data.error);
      }
      await refreshUser();
      toast.show('GoLet satın alındı!', 'success');
      setPurchased(true);
    } catch (err: any) {
      if (!balanceError) {
        toast.show(err.message, 'error');
      }
    } finally {
      setPurchasing(false);
    }
  }

  if (purchased === null) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto" />
          <p className="font-medium text-gray-500">Yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (purchased) {
    return <>{children}</>;
  }

  const features = [
    { icon: Search, title: 'İlanları Keşfedin', desc: 'Binlerce ilan arasından aradığınızı kolayca bulun.' },
    { icon: ShoppingBag, title: 'İlan Verin', desc: 'Sıfır veya ikinci el ürünlerinizi saniyeler içinde listeleyin.' },
    { icon: MessageCircle, title: 'Alıcı Takibi', desc: 'Gelen mesajları yönetin, alıcılarla iletişime geçin.' },
    { icon: BarChart3, title: 'İlan İstatistikleri', desc: 'İlanlarınızın görüntülenme ve mesaj performansını görün.' },
    { icon: Settings, title: 'Kolay Yönetim', desc: 'Tüm ilanlarınızı tek panelden yönetin.' },
  ];

  return (
    <div className="min-h-screen bg-white">
      <header className="border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-pink-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-orange-500/20">
              <Sparkles className="h-5 w-5" />
            </div>
            <span className="font-bold text-gray-900">GoLet</span>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-sm text-gray-500 font-medium">
              Bakiye: <span className="font-bold text-gray-900">{user?.balance.toLocaleString()} TL</span>
            </div>
            <Link href="/profile" className="text-sm text-blue-600 hover:text-blue-700 font-bold transition-colors">
              Bakiye Ekle
            </Link>
          </div>
        </div>
      </header>

      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50 via-white to-pink-50" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-orange-200/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-pink-200/20 rounded-full blur-3xl" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="flex flex-col lg:flex-row items-center gap-16">
            <div className="flex-1 text-center lg:text-left space-y-8">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
                <div className="inline-flex items-center space-x-2 px-4 py-1.5 bg-orange-100 text-orange-700 rounded-full text-sm font-bold">
                  <Sparkles className="h-4 w-4" />
                  <span>Alışverişin Yeni Adresi</span>
                </div>
                <h1 className="text-5xl lg:text-6xl font-black text-gray-900 tracking-tight leading-tight">
                  Go<span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-pink-500">Let</span>
                </h1>
                <p className="text-xl text-gray-600 max-w-xl leading-relaxed">
                  Alışverişin en kolay hali. İkinci el ve sıfır ürünleri keşfedin, ilan verin, satışa çıkarın.
                </p>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
                className="flex flex-col sm:flex-row items-center gap-4">
                <button onClick={handlePurchase} disabled={purchasing}
                  className="inline-flex items-center space-x-2 px-8 py-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-2xl hover:from-orange-600 hover:to-pink-600 transition-all active:scale-[0.98] shadow-xl shadow-orange-500/25 disabled:opacity-50 text-lg">
                  {purchasing ? (
                    <><Loader2 className="h-5 w-5 animate-spin" /><span>Satın alınıyor...</span></>
                  ) : (
                    <><ShoppingCart className="h-5 w-5" /><span>100 TL / ay Satın Al</span></>
                  )}
                </button>
                <Link href="/golet"
                  className="inline-flex items-center space-x-2 px-8 py-4 bg-white border-2 border-gray-200 text-gray-700 font-bold rounded-2xl hover:border-orange-500 hover:text-orange-600 transition-all active:scale-[0.98] text-lg">
                  <span>İlanları Keşfet</span>
                </Link>
                <div className="flex items-center space-x-2 text-sm text-gray-500 font-medium">
                  <Shield className="h-4 w-4 text-emerald-500" />
                  <span>7 gün iade garantisi</span>
                </div>
              </motion.div>

              {balanceError && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
                  className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between">
                  <div>
                    <p className="font-bold text-amber-800">Yetersiz Bakiye</p>
                    <p className="text-sm text-amber-700">Bakiyeniz GoLet'i satın almak için yetersiz.</p>
                  </div>
                  <Link href="/profile" className="px-5 py-2.5 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700 transition-all text-sm flex-shrink-0">
                    Bakiye Ekle
                  </Link>
                </motion.div>
              )}
            </div>

            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.2 }}
              className="flex-shrink-0">
              <div className="relative">
                <div className="w-72 h-80 bg-gradient-to-br from-orange-500 to-pink-500 rounded-[3rem] flex items-center justify-center shadow-2xl shadow-orange-500/20">
                  <div className="text-center space-y-4">
                    <div className="text-8xl">📢</div>
                    <div className="text-white font-black text-2xl">GoLet</div>
                    <div className="text-white/70 font-medium text-sm">Alışverişin Yeni Adresi</div>
                  </div>
                </div>
                <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-amber-50 rounded-3xl flex items-center justify-center shadow-lg border border-amber-100">
                  <div className="text-center">
                    <div className="font-black text-amber-600 text-xl">100</div>
                    <div className="text-xs font-bold text-amber-500">TL / ay</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 space-y-4">
            <h2 className="text-4xl font-black text-gray-900 tracking-tight">Tüm Özellikler Tek Platformda</h2>
            <p className="text-lg text-gray-500 max-w-2xl mx-auto font-medium">
              İlan verin, satışa çıkarın, alıcılarla buluşun. Her şey bir tık uzağınızda.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <motion.div key={f.title} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
                  className="bg-white rounded-[2rem] p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:border-gray-200 transition-all">
                  <div className="w-12 h-12 bg-gradient-to-br from-orange-50 to-pink-50 rounded-2xl flex items-center justify-center mb-4">
                    <Icon className="h-6 w-6 text-orange-600" />
                  </div>
                  <h3 className="font-bold text-gray-900 mb-1">{f.title}</h3>
                  <p className="text-sm text-gray-500 font-medium leading-relaxed">{f.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center space-y-8">
            <div className="inline-flex items-center space-x-2 px-4 py-1.5 bg-emerald-100 text-emerald-700 rounded-full text-sm font-bold">
              <Check className="h-4 w-4" />
              <span>Aylık abonelik, dilediğiniz zaman iptal</span>
            </div>
            <h2 className="text-4xl font-black text-gray-900 tracking-tight">Hemen Başlayın</h2>
            <p className="text-lg text-gray-500 font-medium">
              İlanlarınızı yayınlayın, satışa çıkarın. İlk ay ücretsiz deneyin, memnun kalmazsanız iade edin.
            </p>
            <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-[3rem] p-10 text-white text-center shadow-2xl max-w-md mx-auto">
              <div className="text-5xl mb-4">📢</div>
              <h3 className="text-2xl font-black mb-2">GoLet</h3>
              <div className="flex items-baseline justify-center space-x-1 mb-6">
                <span className="text-5xl font-black">100</span>
                <span className="text-xl text-gray-400 font-medium">TL/ay</span>
              </div>
              <ul className="space-y-3 mb-8 text-left">
                {['Sınırsız ilan yayınlama', 'Alıcı mesaj takibi', 'İlan istatistikleri', 'Fiyat tahmincisi', 'Öncelikli destek'].map(item => (
                  <li key={item} className="flex items-center space-x-3 text-sm text-gray-300">
                    <Check className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <button onClick={handlePurchase} disabled={purchasing}
                className="w-full py-4 bg-white text-gray-900 font-black rounded-2xl hover:bg-gray-100 transition-all active:scale-[0.98] disabled:opacity-50 text-lg">
                {purchasing ? 'Satın alınıyor...' : '100 TL ile Başla'}
              </button>
            </div>
          </div>
        </div>
      </section>

      <footer className="border-t border-gray-100 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-sm text-gray-500 font-medium">
          &copy; 2026 ParasızSepet. Tüm hakları saklıdır.
        </div>
      </footer>
    </div>
  );
}
