'use client';

import { useState } from 'react';
import { OrderItem, PaymentMethod, ServiceChargeRate } from '@/lib/adisyon-pro/constants';
import { X, Plus, Minus, StickyNote, ReceiptText, Send } from 'lucide-react';

interface Props {
  tableName: string;
  orders: OrderItem[];
  tableNote: string;
  isOpen: boolean;
  onRemoveOrder: (itemId: string) => void;
  onAddOrder: (item: OrderItem) => void;
  onSetOrderNote: (itemId: string, note: string) => void;
  onSetTableNote: (note: string) => void;
  onCloseTable: (method: PaymentMethod, discount: number) => void;
  onSendToKitchen?: () => void;
}

export default function BillSummary({ tableName, orders, tableNote, isOpen, onRemoveOrder, onAddOrder, onSetOrderNote, onSetTableNote, onCloseTable, onSendToKitchen }: Props) {
  const [showPayment, setShowPayment] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [discount, setDiscount] = useState(0);
  const [noteInput, setNoteInput] = useState(tableNote);
  const [itemNote, setItemNote] = useState<{ id: string; note: string } | null>(null);

  const subtotal = orders.reduce((total, item) => total + (item.price * item.quantity), 0);
  const serviceCharge = Math.round(subtotal * ServiceChargeRate);
  const grandTotal = subtotal + serviceCharge - discount;

  const handleClose = () => {
    onCloseTable(paymentMethod, discount);
    setShowPayment(false);
    setDiscount(0);
  };

  const handleSaveTableNote = () => {
    onSetTableNote(noteInput);
  };

  return (
    <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-xl overflow-hidden flex flex-col h-[calc(100vh-12rem)] sticky top-24">
      {/* Header */}
      <div className="p-6 border-b border-gray-100 bg-gray-50/50">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-xl font-black text-gray-900 tracking-tight">{tableName}</h2>
          <span className={`px-3 py-1 rounded-full text-xs font-bold ${isOpen ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-400'}`}>
            {isOpen ? 'Açık' : 'Boş'}
          </span>
        </div>
        {isOpen && (
          <div className="flex items-center space-x-2">
            <StickyNote className="h-4 w-4 text-gray-400" />
            <input
              value={noteInput}
              onChange={e => setNoteInput(e.target.value)}
              onBlur={handleSaveTableNote}
              placeholder="Masa notu..."
              className="flex-grow bg-transparent text-sm text-gray-500 placeholder-gray-300 focus:outline-none font-medium"
            />
          </div>
        )}
      </div>

      {/* Order Items */}
      <div className="flex-grow overflow-y-auto p-6 space-y-4">
        {orders.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center space-y-3 text-gray-300 py-12">
            <ReceiptText className="h-12 w-12 opacity-20" />
            <p className="font-bold uppercase tracking-widest text-xs">Sipariş Eklenmedi</p>
            <p className="text-xs text-gray-200">Sol taraftan ürün ekleyin</p>
          </div>
        ) : (
          orders.map((order) => (
            <div key={order.id} className="group">
              <div className="flex items-center justify-between">
                <div className="flex-grow min-w-0">
                  <div className="font-bold text-gray-900 text-sm flex items-center space-x-2">
                    <span>{order.name}</span>
                    {order.note && (
                      <span className="text-xs text-gray-400 font-normal">• {order.note}</span>
                    )}
                  </div>
                  <div className="text-xs font-bold text-gray-400">
                    {order.price} TL x {order.quantity}
                  </div>
                </div>
                <div className="flex items-center space-x-1 ml-4">
                  <button
                    onClick={() => setItemNote(itemNote?.id === order.id ? null : { id: order.id, note: order.note })}
                    className={`w-8 h-8 rounded-lg flex items-center justify-center transition-all ${order.note ? 'text-blue-500 bg-blue-50' : 'text-gray-300 hover:text-gray-500 hover:bg-gray-50'}`}
                  >
                    <StickyNote className="h-4 w-4" />
                  </button>
                  <button
                    onClick={() => onRemoveOrder(order.id)}
                    className="w-8 h-8 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400 hover:bg-red-50 hover:text-red-500 transition-all"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="w-6 text-center font-black text-gray-900 text-sm">{order.quantity}</span>
                  <button
                    onClick={() => onAddOrder(order)}
                    className="w-8 h-8 bg-gray-50 rounded-lg flex items-center justify-center text-gray-400 hover:bg-blue-50 hover:text-blue-500 transition-all"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>
              {itemNote?.id === order.id && (
                <div className="mt-2 pl-2">
                  <input
                    value={itemNote.note}
                    onChange={e => setItemNote({ ...itemNote, note: e.target.value })}
                    onBlur={() => { onSetOrderNote(order.id, itemNote.note); setItemNote(null); }}
                    onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()}
                    placeholder="Not ekle (ör: az şekerli)"
                    className="w-full px-3 py-2 bg-gray-50 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    autoFocus
                  />
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Footer - Totals & Close */}
      {isOpen && (
        <div className="p-6 border-t border-gray-100 bg-gray-50/50 space-y-4">
          {/* Send to Kitchen */}
          {orders.length > 0 && onSendToKitchen && (
            <button
              onClick={onSendToKitchen}
              className="w-full py-3 bg-amber-500 text-white font-bold text-sm rounded-2xl hover:bg-amber-600 transition-all active:scale-[0.98] flex items-center justify-center space-x-2"
            >
              <Send className="h-4 w-4" />
              <span>Mutfağa Gönder</span>
            </button>
          )}

          {/* Totals */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-500 font-medium">Ara Toplam</span>
              <span className="font-bold text-gray-900">{subtotal} TL</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-500 font-medium">Hizmet Bedeli (%10)</span>
              <span className="font-bold text-gray-900">+{serviceCharge} TL</span>
            </div>
            <div className="flex justify-between text-sm items-center">
              <span className="text-gray-500 font-medium">İndirim</span>
              <div className="flex items-center space-x-2">
                <span className="font-bold text-red-500">-{discount} TL</span>
                <button
                  onClick={() => setDiscount(prev => Math.min(prev + 10, subtotal))}
                  className="text-xs text-blue-600 font-bold hover:underline"
                >
                  +10
                </button>
                {discount > 0 && (
                  <button onClick={() => setDiscount(0)} className="text-xs text-gray-400 hover:text-red-500">×</button>
                )}
              </div>
            </div>
            <div className="border-t border-gray-200 pt-2 flex justify-between">
              <span className="text-gray-900 font-black">Genel Toplam</span>
              <span className="text-2xl font-black text-gray-900">{grandTotal} TL</span>
            </div>
          </div>

          {!showPayment ? (
            <button
              onClick={() => setShowPayment(true)}
              className="w-full py-4 bg-blue-600 text-white font-bold text-base rounded-2xl shadow-lg shadow-blue-500/20 hover:bg-blue-700 transition-all active:scale-[0.98]"
            >
              Hesabı Kapat
            </button>
          ) : (
            <div className="space-y-3">
              <div className="flex space-x-2">
                <button
                  onClick={() => setPaymentMethod('cash')}
                  className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${
                    paymentMethod === 'cash' ? 'bg-green-600 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  💵 Nakit
                </button>
                <button
                  onClick={() => setPaymentMethod('card')}
                  className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${
                    paymentMethod === 'card' ? 'bg-purple-600 text-white shadow-md' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-50'
                  }`}
                >
                  💳 Kart
                </button>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => setShowPayment(false)}
                  className="flex-1 py-3 bg-white border border-gray-200 text-gray-500 font-bold rounded-xl hover:bg-gray-50 transition-all"
                >
                  İptal
                </button>
                <button
                  onClick={handleClose}
                  className="flex-1 py-3 bg-gray-900 text-white font-bold rounded-xl hover:bg-gray-800 transition-all active:scale-[0.98]"
                >
                  {grandTotal} TL • Onayla
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
