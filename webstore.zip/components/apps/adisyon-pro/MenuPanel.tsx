'use client';

import { useState } from 'react';
import { MENU_ITEMS, MenuItem } from '@/lib/adisyon-pro/constants';
import { Plus, Search } from 'lucide-react';

interface Props {
  onAddOrder: (item: MenuItem) => void;
  onAddOrderWithQty: (item: MenuItem, qty: number) => void;
}

export default function MenuPanel({ onAddOrder, onAddOrderWithQty }: Props) {
  const [activeCategory, setActiveCategory] = useState<string>('Hepsi');
  const [search, setSearch] = useState('');

  const categories = ['Hepsi', ...Array.from(new Set(MENU_ITEMS.map(i => i.category)))];

  const filteredMenu = MENU_ITEMS.filter(item => {
    const matchCategory = activeCategory === 'Hepsi' || item.category === activeCategory;
    const matchSearch = item.name.toLowerCase().includes(search.toLowerCase());
    return matchCategory && matchSearch;
  });

  return (
    <div className="space-y-6">
      {/* Search */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Ürün ara..."
          className="w-full pl-12 pr-4 py-3 bg-gray-100 border-0 rounded-2xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:bg-white transition-all"
        />
      </div>

      {/* Categories */}
      <div className="flex space-x-2 overflow-x-auto pb-2 scrollbar-hide">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-5 py-2 rounded-full whitespace-nowrap font-bold text-sm transition-all ${
              activeCategory === cat
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-white text-gray-500 border border-gray-100 hover:bg-gray-50'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {filteredMenu.map((item) => (
          <ProductCard key={item.id} item={item} onAdd={onAddOrder} onAddWithQty={onAddOrderWithQty} />
        ))}
        {filteredMenu.length === 0 && (
          <div className="col-span-full text-center py-12 text-gray-400 font-medium">Ürün bulunamadı</div>
        )}
      </div>
    </div>
  );
}

function ProductCard({ item, onAdd, onAddWithQty }: { item: MenuItem; onAdd: (item: MenuItem) => void; onAddWithQty: (item: MenuItem, qty: number) => void }) {
  const [showQty, setShowQty] = useState(false);
  const [qty, setQty] = useState(1);

  const handleQuickAdd = () => {
    if (showQty && qty > 1) {
      onAddWithQty(item, qty);
      setQty(1);
      setShowQty(false);
    } else {
      onAdd(item);
    }
  };

  return (
    <div className="bg-white p-4 rounded-[1.5rem] border border-gray-100 shadow-sm hover:shadow-md hover:border-blue-100 transition-all flex flex-col justify-between aspect-[4/3] group">
      <div>
        <div className="font-bold text-gray-900 leading-tight text-sm">{item.name}</div>
        <div className="text-xs text-gray-400 font-bold mt-1">{item.category}</div>
      </div>
      <div className="mt-auto space-y-2">
        <div className="text-base font-black text-gray-500">{item.price} TL</div>
        {showQty ? (
          <div className="flex items-center space-x-2" onClick={e => e.stopPropagation()}>
            <input
              type="number"
              min={1}
              max={99}
              value={qty}
              onChange={e => setQty(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-14 px-2 py-1.5 bg-gray-100 border-0 rounded-lg text-sm font-bold text-center focus:outline-none focus:ring-2 focus:ring-blue-500/20"
            />
            <button
              onClick={() => { onAddWithQty(item, qty); setQty(1); setShowQty(false); }}
              className="flex-grow py-1.5 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700 transition-all"
            >
              Ekle
            </button>
          </div>
        ) : (
          <div className="flex space-x-1">
            <button
              onClick={handleQuickAdd}
              className="flex-grow py-2 bg-gray-50 rounded-xl flex items-center justify-center space-x-1 text-gray-600 font-bold text-sm hover:bg-blue-600 hover:text-white transition-all group-hover:bg-blue-600 group-hover:text-white"
            >
              <Plus className="h-4 w-4" />
              <span>Ekle</span>
            </button>
            <button
              onClick={e => { e.stopPropagation(); setShowQty(true); }}
              className="w-10 h-10 bg-gray-50 rounded-xl flex items-center justify-center text-gray-400 font-bold text-sm hover:bg-gray-100 transition-all"
              title="Adet girin"
            >
              #️⃣
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
