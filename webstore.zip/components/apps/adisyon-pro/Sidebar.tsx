'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, Table, ChefHat, BarChart3, CalendarDays, Settings, LogOut, Package, Users as UsersIcon, CreditCard, Sparkles, X } from 'lucide-react';
import { useAdisyonRole } from '@/lib/adisyon-pro/AdisyonRoleContext';
import { useSidebar } from './SidebarContext';
import { motion } from 'framer-motion';

export default function Sidebar() {
  const pathname = usePathname();
  const { role, isOwner, roleName, setRole } = useAdisyonRole();
  const { isOpen, close } = useSidebar();

  const primaryItems = [
    { href: '/adisyon-pro', label: 'Dashboard', icon: LayoutDashboard, roles: ['owner', 'staff'] as const },
    { href: '/adisyon-pro/tables', label: 'Masalar', icon: Table, roles: ['owner', 'staff'] as const },
    { href: '/adisyon-pro/kitchen', label: 'Mutfak', icon: ChefHat, roles: ['owner', 'staff'] as const },
  ];

  const managementItems = [
    { href: '/adisyon-pro/stok', label: 'Stok Yönetimi', icon: Package, roles: ['owner'] as const },
    { href: '/adisyon-pro/personel', label: 'Personel', icon: UsersIcon, roles: ['owner'] as const },
    { href: '/adisyon-pro/finans', label: 'Finans', icon: CreditCard, roles: ['owner'] as const },
  ];

  const analyticsItems = [
    { href: '/adisyon-pro/reports', label: 'Raporlar', icon: BarChart3, roles: ['owner'] as const },
    { href: '/adisyon-pro/reservations', label: 'Rezervasyonlar', icon: CalendarDays, roles: ['owner'] as const },
    { href: '/adisyon-pro/ayarlar', label: 'Ayarlar', icon: Settings, roles: ['owner'] as const },
  ];

  const handleLogout = () => {
    sessionStorage.removeItem('in_app_unlocked_adisyon_pro');
    sessionStorage.removeItem('in_app_role');
    setRole(null);
    close();
  };

  const renderSection = (items: { href: string; label: string; icon: any; roles: readonly string[] }[], label?: string) => {
    const visible = isOwner ? items : items.filter(i => (i.roles as readonly string[]).includes('staff'));
    if (visible.length === 0) return null;

    return (
      <div>
        {label && (
          <div className="px-4 py-2">
            <span className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">{label}</span>
          </div>
        )}
        <div className="space-y-0.5">
          {visible.map((item) => {
            const Icon = item.icon;
            const isActive = pathname === item.href || (item.href !== '/adisyon-pro' && pathname.startsWith(item.href));
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={close}
                className={`flex items-center space-x-3 px-4 py-2.5 mx-2 rounded-xl text-sm font-bold transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-600 to-blue-500 text-white shadow-lg shadow-blue-600/20'
                    : 'text-gray-400 hover:text-white hover:bg-white/5'
                }`}
              >
                <Icon className={`h-5 w-5 flex-shrink-0 ${isActive ? 'text-white' : 'text-gray-500'}`} />
                <span>{item.label}</span>
              </Link>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <>
      {/* Backdrop */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 bg-black/50 z-40"
          onClick={close}
        />
      )}

      {/* Sidebar */}
      <motion.aside
        initial={false}
        animate={{ x: isOpen ? 0 : -280 }}
        transition={{ type: 'spring', damping: 25, stiffness: 250 }}
        className="fixed left-0 top-0 bottom-0 w-64 bg-gradient-to-b from-gray-900 via-gray-900 to-gray-800 flex flex-col z-50 shadow-2xl"
      >
        {/* Logo + Close */}
        <div className="p-5 border-b border-white/5 flex items-center justify-between">
          <Link href="/adisyon-pro" onClick={close} className="flex items-center space-x-3">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-emerald-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <h1 className="font-bold text-white text-sm leading-tight">Adisyon Pro</h1>
              <p className="text-[10px] text-gray-500 font-medium">Restoran Yönetimi</p>
            </div>
          </Link>
          <button
            onClick={close}
            className="p-1.5 text-gray-500 hover:text-white hover:bg-white/5 rounded-lg transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Role badge */}
        <div className="px-5 py-3 border-b border-white/5">
          <div className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${
            isOwner ? 'bg-amber-500/10 text-amber-400' : 'bg-emerald-500/10 text-emerald-400'
          }`}>
            <div className={`w-1.5 h-1.5 rounded-full ${isOwner ? 'bg-amber-400' : 'bg-emerald-400'}`} />
            <span>{roleName}</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-grow py-4 space-y-4 overflow-y-auto">
          {renderSection(primaryItems, 'Genel')}
          {isOwner && renderSection(managementItems, 'Yönetim')}
          {isOwner && renderSection(analyticsItems, 'Analiz')}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-white/5 space-y-1">
          <button
            onClick={handleLogout}
            className="w-full flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs text-gray-500 hover:text-red-400 hover:bg-white/5 font-medium transition-all"
          >
            <LogOut className="h-4 w-4" />
            <span>Uygulamadan Çık</span>
          </button>
          <Link
            href="/"
            onClick={close}
            className="flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs text-gray-500 hover:text-gray-300 hover:bg-white/5 font-medium transition-all"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
            <span>ParasızSepet</span>
          </Link>
        </div>
      </motion.aside>
    </>
  );
}
