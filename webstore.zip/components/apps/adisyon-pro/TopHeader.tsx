'use client';

import { CreditCard, LogOut, Menu, BadgeCheck } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useAdisyonRole } from '@/lib/adisyon-pro/AdisyonRoleContext';
import { useSidebar } from './SidebarContext';
import Link from 'next/link';

export default function TopHeader() {
  const { user, logout } = useAuth();
  const { roleName, isOwner } = useAdisyonRole();
  const { toggle } = useSidebar();

  return (
    <header className="h-14 bg-white border-b border-gray-100 flex items-center justify-between px-4 flex-shrink-0">
      <div className="flex items-center space-x-3">
        <button
          onClick={toggle}
          className="p-1.5 text-gray-500 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
          title="Menü"
        >
          <Menu className="h-5 w-5" />
        </button>
        <span className={`inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-md text-xs font-bold ${
          isOwner ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
        }`}>
          <BadgeCheck className="h-3.5 w-3.5" />
          <span>{roleName || 'Yükleniyor...'}</span>
        </span>
        <span className="text-xs text-gray-400 font-medium hidden sm:inline">rolü</span>
      </div>

      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-1.5 text-sm">
          <CreditCard className="h-4 w-4 text-gray-400" />
          <span className="font-medium text-gray-600">{user?.balance.toLocaleString()} TL</span>
        </div>
        <Link
          href="/profile"
          className="text-xs text-blue-600 hover:text-blue-700 font-bold transition-colors"
        >
          Bakiye Ekle
        </Link>
        <button
          onClick={logout}
          className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
          title="Çıkış Yap"
        >
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </header>
  );
}
