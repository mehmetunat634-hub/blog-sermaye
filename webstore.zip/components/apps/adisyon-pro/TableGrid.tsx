'use client';

import { Table, BillRecord } from '@/lib/adisyon-pro/constants';
import { Clock, Receipt, RotateCcw } from 'lucide-react';

interface Props {
  tables: Table[];
  billHistory: BillRecord[];
  onSelectTable: (id: number) => void;
  onReopen: (record: BillRecord) => void;
  getElapsed: (id: number) => string;
  getTotal: (id: number) => number;
}

export default function TableGrid({ tables, billHistory, onSelectTable, onReopen, getElapsed, getTotal }: Props) {
  return (
    <div className="space-y-12">
      {/* Active Tables */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Aktif Masalar</h2>
          <span className="text-sm font-medium text-gray-500">
            {tables.filter(t => t.isOpen).length} / {tables.length} dolu
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {tables.map((table) => (
            <button
              key={table.id}
              onClick={() => onSelectTable(table.id)}
              className={`relative p-6 rounded-[2rem] border-2 transition-all text-left flex flex-col justify-between aspect-square ${
                table.isOpen
                  ? 'bg-white border-blue-500 shadow-lg shadow-blue-500/10'
                  : 'bg-white border-gray-100 hover:border-gray-200 shadow-sm'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className={`text-lg font-bold ${table.isOpen ? 'text-blue-600' : 'text-gray-900'}`}>
                    {table.name}
                  </span>
                  {table.isOpen && <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />}
                </div>
                {table.isOpen && (
                  <div className="flex items-center space-x-1 text-xs text-gray-400 font-medium">
                    <Clock className="h-3 w-3" />
                    <span>{getElapsed(table.id)}</span>
                  </div>
                )}
              </div>

              {table.isOpen ? (
                <div className="mt-auto">
                  <div className="text-xs text-gray-400 font-bold uppercase tracking-wider">Toplam</div>
                  <div className="text-xl font-black text-gray-900">{getTotal(table.id)} TL</div>
                </div>
              ) : (
                <span className="text-xs font-bold text-gray-300 uppercase tracking-widest mt-auto">Boş</span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Bill History */}
      {billHistory.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">Geçmiş Hesaplar</h2>
            <span className="text-sm font-medium text-gray-500">{billHistory.length} kayıt</span>
          </div>
          <div className="space-y-3">
            {billHistory.slice(0, 10).map((record) => (
              <div
                key={record.id}
                className="bg-white rounded-2xl border border-gray-200 p-5 flex items-center justify-between hover:shadow-sm transition-shadow"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
                    <Receipt className="h-6 w-6 text-gray-500" />
                  </div>
                  <div>
                    <div className="font-bold text-gray-900">{record.tableName}</div>
                    <div className="text-sm text-gray-500">
                      {new Date(record.closedAt).toLocaleString('tr-TR')} • {record.paymentMethod === 'cash' ? 'Nakit' : 'Kart'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="font-black text-gray-900">{record.total} TL</div>
                    <div className="text-xs text-gray-400">{record.items.reduce((s, i) => s + i.quantity, 0)} kalem</div>
                  </div>
                  <button
                    onClick={() => onReopen(record)}
                    className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all"
                    title="Yeniden Aç"
                  >
                    <RotateCcw className="h-5 w-5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
