'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { X, Printer } from 'lucide-react';
import type { CariInvoice } from '@/lib/cari/types';
import { useRef } from 'react';

interface Props {
  invoice: CariInvoice | null;
  onClose: () => void;
}

export default function InvoicePDF({ invoice, onClose }: Props) {
  const printRef = useRef<HTMLDivElement>(null);

  if (!invoice) return null;

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>Fatura ${invoice.invoiceNo}</title>
          <style>
            body { font-family: 'Inter', sans-serif; padding: 40px; color: #111; }
            .header { display: flex; justify-content: space-between; margin-bottom: 40px; }
            .invoice-title { font-size: 32px; font-weight: 900; color: #1e40af; margin: 0; }
            .invoice-no { font-size: 16px; color: #6b7280; }
            .customer { margin-bottom: 32px; }
            .customer h3 { font-size: 14px; color: #9ca3af; text-transform: uppercase; margin-bottom: 4px; }
            .customer p { font-size: 18px; font-weight: 600; margin: 0; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 32px; }
            th { text-align: left; padding: 12px 16px; background: #f3f4f6; font-size: 12px; text-transform: uppercase; color: #6b7280; }
            td { padding: 12px 16px; border-bottom: 1px solid #e5e7eb; font-size: 14px; }
            .totals { margin-left: auto; width: 300px; }
            .totals div { display: flex; justify-content: space-between; padding: 8px 0; }
            .totals .grand-total { font-size: 18px; font-weight: 900; border-top: 2px solid #111; padding-top: 12px; margin-top: 8px; }
            .footer { margin-top: 48px; color: #9ca3af; font-size: 12px; text-align: center; }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h1 class="invoice-title">FATURA</h1>
              <p class="invoice-no">${invoice.invoiceNo}</p>
            </div>
            <div>
              <p style="font-weight:600;margin:0">ParasızSepet</p>
              <p style="color:#6b7280;margin:0;font-size:14px">Cari Uygulaması</p>
            </div>
          </div>
          <div class="customer">
            <h3>Müşteri</h3>
            <p>${invoice.customerName}</p>
            ${invoice.customerPhone ? `<p style="color:#6b7280;font-size:14px">${invoice.customerPhone}</p>` : ''}
            ${invoice.customerAddress ? `<p style="color:#6b7280;font-size:14px">${invoice.customerAddress}</p>` : ''}
          </div>
          <table>
            <thead>
              <tr><th>Ürün / Hizmet</th><th>Adet</th><th>Birim Fiyat</th><th style="text-align:right">Tutar</th></tr>
            </thead>
            <tbody>
              ${invoice.items.map(item => `
                <tr>
                  <td>${item.name}</td>
                  <td>${item.quantity}</td>
                  <td>${item.unitPrice.toLocaleString()} TL</td>
                  <td style="text-align:right">${item.total.toLocaleString()} TL</td>
                </tr>
              `).join('')}
            </tbody>
          </table>
          <div class="totals">
            <div><span>Ara Toplam</span><span>${invoice.subtotal.toLocaleString()} TL</span></div>
            <div><span>KDV (%${invoice.taxRate})</span><span>${invoice.taxAmount.toLocaleString()} TL</span></div>
            <div class="grand-total"><span>Genel Toplam</span><span>${invoice.total.toLocaleString()} TL</span></div>
          </div>
          <div class="footer">
            <p>Bu fatura ${new Date(invoice.createdAt).toLocaleDateString('tr-TR')} tarihinde oluşturulmuştur.</p>
            <p>ParasızSepet • Cari Uygulaması</p>
          </div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.print();
  };

  return (
    <AnimatePresence>
      {invoice && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={e => e.stopPropagation()}
            className="bg-white rounded-[2rem] w-full max-w-3xl shadow-2xl max-h-[90vh] overflow-y-auto"
          >
            {/* Action bar */}
            <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between rounded-t-[2rem] z-10">
              <div>
                <h2 className="font-bold text-gray-900">{invoice.invoiceNo}</h2>
                <p className="text-sm text-gray-500">{invoice.customerName}</p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={handlePrint}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl text-sm font-medium transition-all"
                >
                  <Printer className="h-4 w-4" />
                  <span>Yazdır</span>
                </button>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>
            </div>

            {/* Invoice Preview */}
            <div ref={printRef} className="p-8">
              <div className="flex justify-between mb-10">
                <div>
                  <h1 className="text-3xl font-black text-blue-700">FATURA</h1>
                  <p className="text-gray-500 font-medium">{invoice.invoiceNo}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold">ParasızSepet</p>
                  <p className="text-sm text-gray-500">Cari Uygulaması</p>
                </div>
              </div>

              <div className="mb-8">
                <p className="text-xs uppercase tracking-widest text-gray-400 font-semibold mb-1">Müşteri</p>
                <p className="font-bold text-lg">{invoice.customerName}</p>
                {invoice.customerPhone && <p className="text-gray-500 text-sm">{invoice.customerPhone}</p>}
                {invoice.customerAddress && <p className="text-gray-500 text-sm">{invoice.customerAddress}</p>}
              </div>

              <table className="w-full mb-8">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 text-xs uppercase text-gray-400 font-semibold">Ürün / Hizmet</th>
                    <th className="text-left py-3 text-xs uppercase text-gray-400 font-semibold">Adet</th>
                    <th className="text-left py-3 text-xs uppercase text-gray-400 font-semibold">Birim Fiyat</th>
                    <th className="text-right py-3 text-xs uppercase text-gray-400 font-semibold">Tutar</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items.map((item, i) => (
                    <tr key={i} className="border-b border-gray-50">
                      <td className="py-4 font-medium text-gray-900">{item.name}</td>
                      <td className="py-4 text-gray-600">{item.quantity}</td>
                      <td className="py-4 text-gray-600">{item.unitPrice.toLocaleString()} TL</td>
                      <td className="py-4 text-right font-medium">{item.total.toLocaleString()} TL</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              <div className="ml-auto w-72 space-y-2">
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Ara Toplam</span>
                  <span>{invoice.subtotal.toLocaleString()} TL</span>
                </div>
                <div className="flex justify-between text-sm text-gray-500">
                  <span>KDV (%{invoice.taxRate})</span>
                  <span>{invoice.taxAmount.toLocaleString()} TL</span>
                </div>
                <div className="flex justify-between font-black text-lg text-gray-900 border-t-2 border-gray-900 pt-2">
                  <span>Genel Toplam</span>
                  <span>{invoice.total.toLocaleString()} TL</span>
                </div>
              </div>

              <div className="mt-12 text-center text-xs text-gray-400">
                <p>Bu fatura {new Date(invoice.createdAt).toLocaleDateString('tr-TR')} tarihinde oluşturulmuştur.</p>
                <p className="mt-1">ParasızSepet • Cari Uygulaması</p>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
