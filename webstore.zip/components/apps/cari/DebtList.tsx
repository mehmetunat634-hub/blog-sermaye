'use client';

import { motion } from 'framer-motion';
import { CheckCircle2, XCircle, Trash2 } from 'lucide-react';
import type { CariDebt } from '@/lib/cari/types';

interface Props {
  debts: CariDebt[];
  onUpdateStatus: (id: number, status: 'aktif' | 'odendi' | 'iptal') => Promise<void>;
  onDelete: (id: number) => Promise<void>;
}

export default function DebtList({ debts, onUpdateStatus, onDelete }: Props) {
  if (debts.length === 0) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400 font-medium">Henüz kayıt yok</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {debts.map(debt => (
        <motion.div
          key={debt.id}
          layout
          className={`p-5 rounded-2xl border transition-all ${
            debt.status === 'odendi'
              ? 'bg-emerald-50 border-emerald-200'
              : debt.status === 'iptal'
              ? 'bg-gray-50 border-gray-200 opacity-60'
              : 'bg-white border-gray-100 shadow-sm'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 min-w-0">
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-black flex-shrink-0 ${
                debt.type === 'alacak' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
              }`}>
                {debt.type === 'alacak' ? 'A' : 'B'}
              </div>
              <div className="min-w-0">
                <div className="font-bold text-gray-900">{debt.personName}</div>
                {debt.note && <div className="text-xs text-gray-500">{debt.note}</div>}
                {debt.dueDate && (
                  <div className="text-xs text-gray-400">
                    Vade: {new Date(debt.dueDate).toLocaleDateString('tr-TR')}
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center space-x-3 flex-shrink-0">
              <span className={`font-black text-lg ${debt.type === 'alacak' ? 'text-emerald-600' : 'text-red-600'}`}>
                {debt.amount.toLocaleString()} TL
              </span>

              {debt.status === 'aktif' && (
                <button
                  onClick={() => onUpdateStatus(debt.id, 'odendi')}
                  className="p-2 text-gray-300 hover:text-emerald-500 transition-colors"
                  title="Ödendi olarak işaretle"
                >
                  <CheckCircle2 className="h-5 w-5" />
                </button>
              )}
              {debt.status === 'aktif' && (
                <button
                  onClick={() => onUpdateStatus(debt.id, 'iptal')}
                  className="p-2 text-gray-300 hover:text-red-500 transition-colors"
                  title="İptal et"
                >
                  <XCircle className="h-5 w-5" />
                </button>
              )}
              <button
                onClick={() => onDelete(debt.id)}
                className="p-2 text-gray-300 hover:text-red-500 transition-colors"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>

          {debt.status === 'odendi' && (
            <div className="mt-3 text-xs font-semibold text-emerald-600 bg-emerald-100 inline-block px-3 py-1 rounded-full">
              Ödendi
            </div>
          )}
          {debt.status === 'iptal' && (
            <div className="mt-3 text-xs font-semibold text-gray-500 bg-gray-200 inline-block px-3 py-1 rounded-full">
              İptal
            </div>
          )}
        </motion.div>
      ))}
    </div>
  );
}
