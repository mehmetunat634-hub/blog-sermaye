'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Trash2 } from 'lucide-react';
import { INVOICE_TAX_RATES } from '@/lib/cari/constants';
import type { InvoiceItem } from '@/lib/cari/types';

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: (data: {
    customerName: string;
    customerPhone?: string;
    customerAddress?: string;
    items: InvoiceItem[];
    taxRate: number;
  }) => Promise<void>;
}

export default function InvoiceForm({ open, onClose, onSave }: Props) {
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [items, setItems] = useState<InvoiceItem[]>([
    { id: '1', name: '', quantity: 1, unitPrice: 0, total: 0 },
  ]);
  const [taxRate, setTaxRate] = useState(20);
  const [saving, setSaving] = useState(false);

  let nextId = 2;

  const updateItem = (id: string, field: keyof InvoiceItem, value: string | number) => {
    setItems(prev => prev.map(item => {
      if (item.id !== id) return item;
      const updated = { ...item, [field]: value };
      if (field === 'quantity' || field === 'unitPrice') {
        updated.total = updated.quantity * updated.unitPrice;
      }
      return updated;
    }));
  };

  const addItem = () => {
    setItems(prev => [...prev, { id: String(nextId++), name: '', quantity: 1, unitPrice: 0, total: 0 }]);
  };

  const removeItem = (id: string) => {
    setItems(prev => prev.filter(item => item.id !== id));
  };

  const subtotal = items.reduce((s, item) => s + item.total, 0);
  const taxAmount = Math.round(subtotal * taxRate * 100) / 10000;
  const total = subtotal + taxAmount;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || items.some(i => !i.name)) return;
    setSaving(true);
    try {
      await onSave({ customerName, customerPhone, customerAddress, items, taxRate });
      setCustomerName('');
      setCustomerPhone('');
      setCustomerAddress('');
      setItems([{ id: '1', name: '', quantity: 1, unitPrice: 0, total: 0 }]);
      onClose();
    } catch {} finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4 overflow-y-auto"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={e => e.stopPropagation()}
            className="bg-white rounded-[2rem] p-8 w-full max-w-2xl shadow-2xl my-8"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">Yeni Fatura</h2>
              <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Customer */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Müşteri Adı</label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={e => setCustomerName(e.target.value)}
                    placeholder="Ad soyad / Firma"
                    required
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Telefon</label>
                  <input
                    type="text"
                    value={customerPhone}
                    onChange={e => setCustomerPhone(e.target.value)}
                    placeholder="05XX XXX XX XX"
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Adres</label>
                  <input
                    type="text"
                    value={customerAddress}
                    onChange={e => setCustomerAddress(e.target.value)}
                    placeholder="Adres bilgisi"
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                  />
                </div>
              </div>

              {/* Items */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <label className="text-sm font-medium text-gray-700">Ürün / Hizmetler</label>
                  <button
                    type="button"
                    onClick={addItem}
                    className="flex items-center space-x-1 text-sm font-bold text-blue-600 hover:text-blue-700"
                  >
                    <Plus className="h-4 w-4" />
                    <span>Kalem Ekle</span>
                  </button>
                </div>

                <div className="space-y-3">
                  {items.map((item) => (
                    <div key={item.id} className="flex items-center space-x-3">
                      <input
                        type="text"
                        value={item.name}
                        onChange={e => updateItem(item.id, 'name', e.target.value)}
                        placeholder="Kalem adı"
                        className="flex-1 px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                      />
                      <input
                        type="number"
                        value={item.quantity}
                        onChange={e => updateItem(item.id, 'quantity', Number(e.target.value))}
                        min="1"
                        className="w-20 px-3 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-center focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                      />
                      <input
                        type="number"
                        step="0.01"
                        value={item.unitPrice}
                        onChange={e => updateItem(item.id, 'unitPrice', Number(e.target.value))}
                        placeholder="0.00"
                        className="w-24 px-3 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm text-right focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                      />
                      <span className="w-24 text-right font-bold text-gray-900 text-sm">
                        {item.total.toLocaleString()} TL
                      </span>
                      {items.length > 1 && (
                        <button type="button" onClick={() => removeItem(item.id)} className="p-2 text-gray-300 hover:text-red-500">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Tax Rate */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">KDV Oranı (%)</label>
                <div className="flex space-x-2">
                  {INVOICE_TAX_RATES.map(rate => (
                    <button
                      key={rate}
                      type="button"
                      onClick={() => setTaxRate(rate)}
                      className={`px-5 py-3 rounded-xl font-bold text-sm transition-all ${
                        taxRate === rate
                          ? 'bg-blue-600 text-white'
                          : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      %{rate}
                    </button>
                  ))}
                </div>
              </div>

              {/* Totals */}
              <div className="p-6 bg-gray-50 rounded-2xl space-y-2">
                <div className="flex justify-between text-sm text-gray-500">
                  <span>Ara Toplam</span>
                  <span className="font-medium">{subtotal.toLocaleString()} TL</span>
                </div>
                <div className="flex justify-between text-sm text-gray-500">
                  <span>KDV (%{taxRate})</span>
                  <span className="font-medium">{taxAmount.toLocaleString()} TL</span>
                </div>
                <div className="flex justify-between text-lg font-black text-gray-900 pt-2 border-t border-gray-200">
                  <span>Genel Toplam</span>
                  <span>{total.toLocaleString()} TL</span>
                </div>
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] disabled:opacity-50"
              >
                {saving ? 'Oluşturuluyor...' : 'Faturayı Oluştur'}
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
