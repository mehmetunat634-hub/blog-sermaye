'use client';

import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { RefreshCw, ArrowRightLeft } from 'lucide-react';
import type { ExchangeRate } from '@/lib/cari/types';

interface Props {
  rates: ExchangeRate[];
  onRefresh: () => Promise<void>;
}

export default function ExchangeRateCalculator({ rates, onRefresh }: Props) {
  const [amount, setAmount] = useState('100');
  const [fromCurrency, setFromCurrency] = useState('USD');
  const [toCurrency, setToCurrency] = useState('TRY');
  const [loading, setLoading] = useState(false);

  const result = useMemo(() => {
    const getRate = (code: string) => {
      if (code === 'TRY') return 1;
      const rate = rates.find(r => r.code === code);
      return rate ? rate.buying : 0;
    };
    const fromRate = getRate(fromCurrency);
    const toRate = getRate(toCurrency);
    const numAmount = Number(amount);
    if (!fromRate || !toRate || !numAmount) return 0;
    return (numAmount / fromRate) * toRate;
  }, [amount, fromCurrency, toCurrency, rates]);

  const handleRefresh = async () => {
    setLoading(true);
    try {
      await onRefresh();
    } catch {} finally {
      setLoading(false);
    }
  };

  const swap = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  const allCurrencies = [
    { code: 'TRY', name: 'Türk Lirası' },
    ...rates.map(r => ({ code: r.code, name: r.name })),
  ];

  return (
    <div className="space-y-8">
      {/* Calculator */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm"
      >
        <h3 className="text-lg font-bold text-gray-900 mb-6">Kur Hesaplayıcı</h3>

        <div className="space-y-5">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Tutar</label>
            <input
              type="number"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-lg font-bold focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
            />
          </div>

          <div className="grid grid-cols-[1fr,auto,1fr] gap-3 items-end">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Dan</label>
              <select
                value={fromCurrency}
                onChange={e => setFromCurrency(e.target.value)}
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
              >
                {allCurrencies.map(c => (
                  <option key={c.code} value={c.code}>{c.code} - {c.name}</option>
                ))}
              </select>
            </div>

            <button
              onClick={swap}
              className="p-3 bg-gray-100 hover:bg-gray-200 rounded-xl transition-colors mb-1"
            >
              <ArrowRightLeft className="h-5 w-5 text-gray-600" />
            </button>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Ye</label>
              <select
                value={toCurrency}
                onChange={e => setToCurrency(e.target.value)}
                className="w-full px-4 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
              >
                {allCurrencies.map(c => (
                  <option key={c.code} value={c.code}>{c.code} - {c.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl text-center">
            <div className="text-sm font-medium text-gray-500">Sonuç</div>
            <div className="text-3xl font-black text-gray-900 mt-1">
              {result.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 4 })}
              <span className="text-lg ml-2 text-gray-500">{toCurrency}</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Live Rates Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm"
      >
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-bold text-gray-900">Canlı Kurlar</h3>
          <button
            onClick={handleRefresh}
            disabled={loading}
            className="flex items-center space-x-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-xl text-sm font-medium transition-all"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            <span>Yenile</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-sm font-medium text-gray-500 border-b border-gray-100">
                <th className="pb-3">Döviz</th>
                <th className="pb-3">Alış</th>
                <th className="pb-3">Satış</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {rates.map(rate => (
                <tr key={rate.code} className="hover:bg-gray-50 transition-colors">
                  <td className="py-4">
                    <span className="font-bold text-gray-900">{rate.code}</span>
                    <span className="text-sm text-gray-500 ml-2">{rate.name}</span>
                  </td>
                  <td className="py-4 font-medium text-gray-900">
                    {rate.buying.toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 4 })}
                  </td>
                  <td className="py-4 font-medium text-gray-900">
                    {rate.selling.toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 4 })}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
