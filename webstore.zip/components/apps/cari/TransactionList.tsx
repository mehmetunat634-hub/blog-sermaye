'use client';

import { Trash2 } from 'lucide-react';
import type { CariTransaction } from '@/lib/cari/types';

interface Props {
  transactions: CariTransaction[];
  onDelete: (id: number) => Promise<void>;
}

export default function TransactionList({ transactions, onDelete }: Props) {
  if (transactions.length === 0) {
    return (
      <div className="text-center py-16">
        <p className="text-gray-400 font-medium">Henüz işlem kaydı yok</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      {transactions.map(tx => (
        <div
          key={tx.id}
          className="flex items-center justify-between p-4 rounded-2xl hover:bg-gray-50 transition-colors group"
        >
          <div className="flex items-center space-x-4 min-w-0">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm flex-shrink-0 ${
              tx.type === 'gelir' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
            }`}>
              {tx.type === 'gelir' ? 'G' : 'Gd'}
            </div>
            <div className="min-w-0">
              <div className="font-bold text-gray-900 text-sm truncate">{tx.category}</div>
              <div className="text-xs text-gray-500 truncate">{tx.description || '—'}</div>
              <div className="text-xs text-gray-400">{new Date(tx.transactionDate).toLocaleDateString('tr-TR')}</div>
            </div>
          </div>
          <div className="flex items-center space-x-3 flex-shrink-0">
            <span className={`font-black ${tx.type === 'gelir' ? 'text-emerald-600' : 'text-red-600'}`}>
              {tx.type === 'gelir' ? '+' : '-'}{tx.amount.toLocaleString()} TL
            </span>
            <button
              onClick={() => onDelete(tx.id)}
              className="p-2 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
