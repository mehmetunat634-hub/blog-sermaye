'use client';

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import type { CariTransaction } from '@/lib/cari/types';

interface Props {
  transactions: CariTransaction[];
}

export default function CashFlowChart({ transactions }: Props) {
  const last6Months: { month: string; gelir: number; gider: number }[] = [];

  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const year = d.getFullYear();
    const month = d.getMonth();
    const label = d.toLocaleString('tr-TR', { month: 'short', year: 'numeric' });

    const monthTx = transactions.filter(t => {
      const txDate = new Date(t.transactionDate);
      return txDate.getFullYear() === year && txDate.getMonth() === month;
    });

    last6Months.push({
      month: label,
      gelir: monthTx.filter(t => t.type === 'gelir').reduce((s, t) => s + t.amount, 0),
      gider: monthTx.filter(t => t.type === 'gider').reduce((s, t) => s + t.amount, 0),
    });
  }

  return (
    <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
      <h3 className="text-lg font-bold text-gray-900 mb-6">Aylık Gelir / Gider</h3>
      <div className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={last6Months}>
            <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <Tooltip />
            <Legend />
            <Bar dataKey="gelir" name="Gelir" fill="#10b981" radius={[8, 8, 0, 0]} />
            <Bar dataKey="gider" name="Gider" fill="#f43f5e" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
