'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { GIDER_KATEGORILERI, GELIR_KATEGORILERI } from '@/lib/cari/constants';

interface Props {
  open: boolean;
  onClose: () => void;
  onSave: (data: {
    type: 'gelir' | 'gider';
    amount: number;
    category: string;
    description: string;
    transactionDate: string;
  }) => Promise<void>;
}

export default function TransactionForm({ open, onClose, onSave }: Props) {
  const [type, setType] = useState<'gelir' | 'gider'>('gelir');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<string>(GELIR_KATEGORILERI[0]);
  const [description, setDescription] = useState('');
  const [transactionDate, setTransactionDate] = useState(new Date().toISOString().split('T')[0]);
  const [saving, setSaving] = useState(false);

  const categories = type === 'gelir' ? GELIR_KATEGORILERI : GIDER_KATEGORILERI;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!amount || !category || !transactionDate) return;
    setSaving(true);
    try {
      await onSave({ type, amount: Number(amount), category, description, transactionDate });
      setAmount('');
      setDescription('');
      onClose();
    } catch {} finally {
      setSaving(false);
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={e => e.stopPropagation()}
            className="bg-white rounded-[2rem] p-8 w-full max-w-lg shadow-2xl"
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-gray-900">İşlem Ekle</h2>
              <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-xl transition-colors">
                <X className="h-5 w-5 text-gray-500" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="flex rounded-2xl overflow-hidden border border-gray-200">
                <button
                  type="button"
                  onClick={() => { setType('gelir'); setCategory(GELIR_KATEGORILERI[0]); }}
                  className={`flex-1 py-3 font-bold text-sm transition-all ${
                    type === 'gelir' ? 'bg-emerald-500 text-white' : 'bg-gray-50 text-gray-500'
                  }`}
                >
                  Gelir
                </button>
                <button
                  type="button"
                  onClick={() => { setType('gider'); setCategory(GIDER_KATEGORILERI[0]); }}
                  className={`flex-1 py-3 font-bold text-sm transition-all ${
                    type === 'gider' ? 'bg-red-500 text-white' : 'bg-gray-50 text-gray-500'
                  }`}
                >
                  Gider
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tutar</label>
                <input
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  placeholder="0.00"
                  required
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Kategori</label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tarih</label>
                <input
                  type="date"
                  value={transactionDate}
                  onChange={e => setTransactionDate(e.target.value)}
                  required
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Açıklama</label>
                <input
                  type="text"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="İşlem açıklaması..."
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                />
              </div>

              <button
                type="submit"
                disabled={saving}
                className="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] disabled:opacity-50"
              >
                {saving ? 'Kaydediliyor...' : 'Kaydet'}
              </button>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
