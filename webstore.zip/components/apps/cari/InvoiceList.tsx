'use client';

import { FileText, Send, CheckCircle2, Trash2 } from 'lucide-react';
import type { CariInvoice } from '@/lib/cari/types';

interface Props {
  invoices: CariInvoice[];
  onUpdateStatus: (id: number, status: 'taslak' | 'gonderildi' | 'odendi') => Promise<void>;
  onDelete: (id: number) => Promise<void>;
  onView: (invoice: CariInvoice) => void;
}

const STATUS_LABELS: Record<string, string> = {
  taslak: 'Taslak',
  gonderildi: 'Gönderildi',
  odendi: 'Ödendi',
};

const STATUS_COLORS: Record<string, string> = {
  taslak: 'bg-gray-100 text-gray-600',
  gonderildi: 'bg-blue-100 text-blue-700',
  odendi: 'bg-emerald-100 text-emerald-700',
};

export default function InvoiceList({ invoices, onUpdateStatus, onDelete, onView }: Props) {
  if (invoices.length === 0) {
    return (
      <div className="text-center py-16">
        <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-400 font-medium">Henüz fatura yok</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {invoices.map(inv => (
        <div
          key={inv.id}
          className="bg-white rounded-2xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-all cursor-pointer"
          onClick={() => onView(inv)}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4 min-w-0">
              <div className="w-12 h-12 bg-indigo-50 rounded-xl flex items-center justify-center flex-shrink-0">
                <FileText className="h-6 w-6 text-indigo-600" />
              </div>
              <div className="min-w-0">
                <div className="font-bold text-gray-900">{inv.invoiceNo}</div>
                <div className="text-sm text-gray-500 truncate">{inv.customerName}</div>
                <div className="text-xs text-gray-400">
                  {new Date(inv.createdAt).toLocaleDateString('tr-TR')}
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3 flex-shrink-0">
              <span className="font-black text-gray-900">{inv.total.toLocaleString()} TL</span>
              <span className={`text-xs font-bold px-3 py-1 rounded-full ${STATUS_COLORS[inv.status]}`}>
                {STATUS_LABELS[inv.status]}
              </span>

              {inv.status === 'taslak' && (
                <button
                  onClick={e => { e.stopPropagation(); onUpdateStatus(inv.id, 'gonderildi'); }}
                  className="p-2 text-gray-300 hover:text-blue-500 transition-colors"
                  title="Gönderildi olarak işaretle"
                >
                  <Send className="h-4 w-4" />
                </button>
              )}
              {inv.status === 'gonderildi' && (
                <button
                  onClick={e => { e.stopPropagation(); onUpdateStatus(inv.id, 'odendi'); }}
                  className="p-2 text-gray-300 hover:text-emerald-500 transition-colors"
                  title="Ödendi olarak işaretle"
                >
                  <CheckCircle2 className="h-4 w-4" />
                </button>
              )}
              <button
                onClick={e => { e.stopPropagation(); onDelete(inv.id); }}
                className="p-2 text-gray-300 hover:text-red-500 transition-colors"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
