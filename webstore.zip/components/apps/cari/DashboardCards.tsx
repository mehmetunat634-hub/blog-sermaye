'use client';

import { motion } from 'framer-motion';
import { Wallet, Handshake, TrendingUp, CreditCard } from 'lucide-react';
import type { DashboardStats } from '@/lib/cari/types';

interface Props {
  stats: DashboardStats | null;
}

export default function DashboardCards({ stats }: Props) {
  if (!stats) return null;

  const cards = [
    {
      icon: <Wallet className="h-6 w-6 text-emerald-600" />,
      label: 'Toplam Bakiye',
      value: `${stats.balance.toLocaleString()} TL`,
      bg: 'bg-emerald-50',
      positive: stats.balance >= 0,
    },
    {
      icon: <Handshake className="h-6 w-6 text-blue-600" />,
      label: 'Alacak / Borç',
      value: `${stats.activeReceivable.toLocaleString()} TL / ${stats.activeDebt.toLocaleString()} TL`,
      bg: 'bg-blue-50',
    },
    {
      icon: <TrendingUp className="h-6 w-6 text-violet-600" />,
      label: 'Bu Ay Gelir / Gider',
      value: `${stats.monthlyIncome.toLocaleString()} TL / ${stats.monthlyExpense.toLocaleString()} TL`,
      bg: 'bg-violet-50',
    },
    {
      icon: <CreditCard className="h-6 w-6 text-amber-600" />,
      label: 'Toplam Gider',
      value: `${stats.totalExpense.toLocaleString()} TL`,
      bg: 'bg-amber-50',
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, i) => (
        <motion.div
          key={card.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.08 }}
          className={`${card.bg} rounded-[2rem] p-6 flex items-center space-x-4`}
        >
          <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm flex-shrink-0">
            {card.icon}
          </div>
          <div className="min-w-0">
            <div className={`text-xl font-black text-gray-900 truncate ${card.positive !== undefined ? (card.positive ? '' : 'text-red-600') : ''}`}>
              {card.value}
            </div>
            <div className="text-sm font-medium text-gray-500">{card.label}</div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
