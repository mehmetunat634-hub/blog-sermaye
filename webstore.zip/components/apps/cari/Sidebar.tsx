'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  ArrowRightLeft,
  Handshake,
  TrendingDown,
  RefreshCw,
  FileText,
} from 'lucide-react';

const NAV_ITEMS = [
  { href: '/cari', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/cari/nakit-akisi', label: 'Nakit Akışı', icon: ArrowRightLeft },
  { href: '/cari/borc-alacak', label: 'Borç / Alacak', icon: Handshake },
  { href: '/cari/giderler', label: 'Giderler', icon: TrendingDown },
  { href: '/cari/kur-hesapla', label: 'Kur Hesapla', icon: RefreshCw },
  { href: '/cari/faturalar', label: 'Faturalar', icon: FileText },
];

export default function CariSidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-64 flex-shrink-0 bg-white border-r border-gray-100 min-h-[calc(100vh-4rem)] py-6 px-3 hidden lg:block">
      <nav className="space-y-1">
        {NAV_ITEMS.map(item => {
          const isActive = pathname === item.href || (item.href !== '/cari' && pathname.startsWith(item.href));
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center space-x-3 px-4 py-3 rounded-2xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-blue-50 text-blue-700'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <Icon className={`h-5 w-5 ${isActive ? 'text-blue-600' : 'text-gray-400'}`} />
              <span>{item.label}</span>
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}
