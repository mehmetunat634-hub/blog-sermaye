'use client';

import { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, LogOut, Eye, EyeOff } from 'lucide-react';

export default function StoreGate({ children }: { children: React.ReactNode }) {
  const { user, loading, isStoreUnlocked, unlockStore, logout } = useAuth();
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [unlocking, setUnlocking] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  if (loading) return <>{children}</>;

  const handleUnlock = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setUnlocking(true);
    try {
      await unlockStore(password);
      setPassword('');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUnlocking(false);
    }
  };

  return (
    <>
      <AnimatePresence>
        {!isStoreUnlocked && user && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-white flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              className="w-full max-w-sm text-center space-y-8"
            >
              <div className="space-y-4">
                <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto">
                  <Lock className="h-10 w-10 text-gray-900" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Mağaza Kilitli</h1>
                  <p className="text-gray-500 mt-2">
                    Devam etmek için şifrenizi girin, <strong className="text-gray-900">{user?.name}</strong>
                  </p>
                </div>
              </div>

              <form onSubmit={handleUnlock} className="space-y-4">
                {error && (
                  <div className="p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium">{error}</div>
                )}

                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder="Şifre"
                    autoFocus
                    className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all pr-12"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={!password || unlocking}
                  className="w-full py-4 bg-gray-900 text-white font-bold rounded-2xl hover:bg-gray-800 transition-all active:scale-[0.98] disabled:opacity-50"
                >
                  {unlocking ? (
                    <div className="flex items-center justify-center space-x-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Doğrulanıyor...</span>
                    </div>
                  ) : (
                    'Mağazayı Aç'
                  )}
                </button>
              </form>

              <button
                onClick={logout}
                className="flex items-center justify-center space-x-2 text-sm text-gray-500 hover:text-gray-900 font-medium mx-auto transition-colors"
              >
                <LogOut className="h-4 w-4" />
                <span>Farklı hesap kullan</span>
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {children}
    </>
  );
}
