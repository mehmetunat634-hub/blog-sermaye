import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-gray-100 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col sm:flex-row items-center justify-between space-y-4 sm:space-y-0">
          <div className="flex items-center space-x-2 text-sm text-gray-500">
            <div className="w-7 h-7 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-xs">P</div>
            <span className="font-medium">ParasızSepet</span>
            <span className="text-gray-300">•</span>
            <span>2026 Tüm hakları saklıdır</span>
          </div>
          <div className="flex items-center space-x-6 text-sm">
            <a href="/about" className="text-gray-500 hover:text-gray-900 font-medium transition-colors">Hakkımızda</a>
            <a href="/" className="text-gray-500 hover:text-gray-900 font-medium transition-colors">Uygulamalar</a>
            <span className="flex items-center space-x-1 text-gray-400 text-xs">
              <Heart className="h-3 w-3" />
              <span>sonsuz</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
