'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, Code2, Globe, Wallet, Users, Shield, Zap } from 'lucide-react';

const items = [
  { icon: Code2, title: 'API Dokümantasyonu', desc: 'RESTful API\'miz ile uygulamalarınızı ParasızSepet ekosistemine entegre edin.' },
  { icon: Globe, title: 'Küresel Dağıtım', desc: 'Uygulamalarınızı dünya çapında milyonlarca kullanıcıya anında ulaştırın.' },
  { icon: Wallet, title: 'Gelir Paylaşımı', desc: 'Şeffaf ve adil gelir modeli ile emeğinizin karşılığını alın.' },
  { icon: Users, title: 'Geliştirici Topluluğu', desc: 'Binlerce geliştiricinin katıldığı topluluğumuza katılın, deneyim paylaşın.' },
  { icon: Shield, title: 'Güvenlik Altyapısı', desc: 'SSL, DDoS koruması ve düzenli güvenlik taramaları ile verileriniz güvende.' },
  { icon: Zap, title: 'Otomatik Ölçeklenme', desc: 'Trafiğinize göre otomatik ölçeklenen altyapı ile kesintisiz hizmet.' },
];

export default function DahaFazlaBilgi() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="px-8 py-4 bg-gray-800 text-white font-bold rounded-2xl hover:bg-gray-700 transition-all flex items-center space-x-2 mx-auto"
      >
        <span>Daha Fazla Bilgi</span>
        <motion.div
          animate={{ rotate: isOpen ? 180 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <ChevronDown className="h-5 w-5" />
        </motion.div>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ type: 'spring', damping: 20, stiffness: 100 }}
            className="overflow-hidden"
          >
            <motion.div
              initial={{ y: -20 }}
              animate={{ y: 0 }}
              transition={{ delay: 0.1 }}
              className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-left"
            >
              {items.map((item, i) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.title}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + i * 0.08 }}
                    className="bg-gray-800/80 rounded-2xl p-6 border border-gray-700/50 hover:bg-gray-800 hover:border-gray-600 transition-all"
                  >
                    <div className="w-10 h-10 rounded-xl bg-blue-600/20 flex items-center justify-center mb-4">
                      <Icon className="h-5 w-5 text-blue-400" />
                    </div>
                    <h3 className="font-bold text-white text-sm mb-1">{item.title}</h3>
                    <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                  </motion.div>
                );
              })}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
