'use client';

import { motion } from 'framer-motion';
import { Users, Globe, Zap, ShieldCheck } from 'lucide-react';

const stats = [
  {
    label: 'Aktif Kullanıcı',
    value: '1.2M+',
    icon: <Users className="h-6 w-6 text-blue-600" />,
    className: 'md:col-span-2 md:row-span-1 bg-blue-50/50',
  },
  {
    label: 'Uygulama Sayısı',
    value: '500+',
    icon: <Globe className="h-6 w-6 text-purple-600" />,
    className: 'md:col-span-1 md:row-span-1 bg-purple-50/50',
  },
  {
    label: 'Ortalama Hız',
    value: '0.2s',
    icon: <Zap className="h-6 w-6 text-amber-600" />,
    className: 'md:col-span-1 md:row-span-1 bg-amber-50/50',
  },
  {
    label: 'Güvenlik Puanı',
    value: '%100',
    icon: <ShieldCheck className="h-6 w-6 text-emerald-600" />,
    className: 'md:col-span-2 md:row-span-1 bg-emerald-50/50',
  },
];

export default function StatsGrid() {
  return (
    <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-16">
        <h2 className="text-3xl font-bold text-gray-900 tracking-tight">Rakamlarla ParasızSepet</h2>
        <p className="text-gray-500 mt-4">Güvenilir, hızlı ve her geçen gün büyüyen bir ekosistem.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-[180px]">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className={`p-8 rounded-[2.5rem] border border-gray-100 flex flex-col justify-between ${stat.className}`}
          >
            <div className="p-3 bg-white w-fit rounded-2xl shadow-sm">
              {stat.icon}
            </div>
            <div>
              <div className="text-4xl font-black text-gray-900 tracking-tighter mb-1">
                {stat.value}
              </div>
              <div className="text-sm font-bold text-gray-500 uppercase tracking-widest">
                {stat.label}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
