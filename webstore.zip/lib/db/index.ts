import mysql from 'mysql2/promise';

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  charset: 'utf8mb4',
});

const db = {
  async get(sql: string, params: any[] = []): Promise<any> {
    const [rows] = await pool.execute(sql, params);
    return (rows as any[])[0] ?? undefined;
  },
  async all(sql: string, params: any[] = []): Promise<any[]> {
    const [rows] = await pool.execute(sql, params);
    return rows as any[];
  },
  async run(sql: string, params: any[] = []) {
    const [result] = await pool.execute(sql, params);
    return result as { insertId: number; affectedRows: number };
  },
  async exec(sql: string): Promise<void> {
    await pool.query(sql);
  },
};

async function init() {
  try {
    await db.exec(`CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      email VARCHAR(255) UNIQUE NOT NULL,
      name VARCHAR(255) NOT NULL,
      password VARCHAR(255) NOT NULL,
      role VARCHAR(50) NOT NULL DEFAULT 'user',
      balance DECIMAL(10,2) NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT NOW()
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS purchases (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      app_slug VARCHAR(255) NOT NULL,
      amount DECIMAL(10,2) NOT NULL,
      purchased_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_state (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL UNIQUE,
      tables LONGTEXT NOT NULL,
      updated_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_bills (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      table_name VARCHAR(255) NOT NULL,
      items LONGTEXT NOT NULL,
      total DECIMAL(10,2) NOT NULL,
      discount DECIMAL(10,2) NOT NULL DEFAULT 0,
      service_charge DECIMAL(10,2) NOT NULL DEFAULT 0,
      payment_method VARCHAR(50) NOT NULL DEFAULT 'cash',
      closed_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_kitchen_orders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      table_id INT NOT NULL,
      table_name VARCHAR(255) NOT NULL,
      items LONGTEXT NOT NULL,
      status VARCHAR(50) NOT NULL DEFAULT 'pending',
      sent_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_reservations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      table_name VARCHAR(255) NOT NULL,
      guest_name VARCHAR(255) NOT NULL,
      guest_count INT NOT NULL,
      date VARCHAR(50) NOT NULL,
      time VARCHAR(50) NOT NULL,
      phone VARCHAR(50) NOT NULL DEFAULT '',
      status VARCHAR(50) NOT NULL DEFAULT 'pending',
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_roles (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      name VARCHAR(255) NOT NULL,
      password VARCHAR(255) NOT NULL,
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_pro_state (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL UNIQUE,
      tables LONGTEXT NOT NULL,
      updated_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_pro_bills (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      table_name VARCHAR(255) NOT NULL,
      items LONGTEXT NOT NULL,
      total DECIMAL(10,2) NOT NULL,
      discount DECIMAL(10,2) NOT NULL DEFAULT 0,
      service_charge DECIMAL(10,2) NOT NULL DEFAULT 0,
      payment_method VARCHAR(50) NOT NULL DEFAULT 'cash',
      closed_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_pro_kitchen_orders (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      table_id INT NOT NULL,
      table_name VARCHAR(255) NOT NULL,
      items LONGTEXT NOT NULL,
      status VARCHAR(50) NOT NULL DEFAULT 'pending',
      sent_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_pro_reservations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      table_name VARCHAR(255) NOT NULL,
      guest_name VARCHAR(255) NOT NULL,
      guest_count INT NOT NULL,
      date VARCHAR(50) NOT NULL,
      time VARCHAR(50) NOT NULL,
      phone VARCHAR(50) NOT NULL DEFAULT '',
      status VARCHAR(50) NOT NULL DEFAULT 'pending',
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS adisyon_pro_roles (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      name VARCHAR(255) NOT NULL,
      password VARCHAR(255) NOT NULL,
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS cari_transactions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      type ENUM('gelir','gider') NOT NULL,
      amount DECIMAL(10,2) NOT NULL,
      category VARCHAR(255) NOT NULL,
      description TEXT,
      transaction_date DATE NOT NULL,
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS cari_debts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      person_name VARCHAR(255) NOT NULL,
      type ENUM('borc','alacak') NOT NULL,
      amount DECIMAL(10,2) NOT NULL,
      due_date DATE DEFAULT NULL,
      note TEXT,
      status ENUM('aktif','odendi','iptal') NOT NULL DEFAULT 'aktif',
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS cari_invoices (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      invoice_no VARCHAR(50) NOT NULL,
      customer_name VARCHAR(255) NOT NULL,
      customer_phone VARCHAR(50) DEFAULT '',
      customer_address TEXT,
      items LONGTEXT NOT NULL,
      subtotal DECIMAL(10,2) NOT NULL,
      tax_rate DECIMAL(5,2) NOT NULL DEFAULT 20,
      tax_amount DECIMAL(10,2) NOT NULL,
      total DECIMAL(10,2) NOT NULL,
      status ENUM('taslak','gonderildi','odendi') NOT NULL DEFAULT 'taslak',
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS cari_contacts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      name VARCHAR(255) NOT NULL,
      phone VARCHAR(50) DEFAULT '',
      email VARCHAR(255) DEFAULT '',
      address TEXT,
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS registration_requests (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      email VARCHAR(255) NOT NULL,
      password VARCHAR(255) NOT NULL,
      status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
      created_at DATETIME NOT NULL DEFAULT NOW()
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS balance_requests (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      email VARCHAR(255) NOT NULL,
      amount DECIMAL(10,2) NOT NULL,
      status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS golet_listings (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NOT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      price DECIMAL(10,2) NOT NULL,
      category VARCHAR(100) NOT NULL,
      condition VARCHAR(50) NOT NULL DEFAULT 'ikinci-el',
      location VARCHAR(255) DEFAULT '',
      phone VARCHAR(50) DEFAULT '',
      whatsapp VARCHAR(50) DEFAULT '',
      photos JSON DEFAULT NULL,
      status ENUM('active','sold','expired') NOT NULL DEFAULT 'active',
      views INT NOT NULL DEFAULT 0,
      created_at DATETIME NOT NULL DEFAULT NOW(),
      updated_at DATETIME NOT NULL DEFAULT NOW() ON UPDATE NOW(),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )`);

    await db.exec(`CREATE TABLE IF NOT EXISTS golet_inquiries (
      id INT AUTO_INCREMENT PRIMARY KEY,
      listing_id INT NOT NULL,
      seller_id INT NOT NULL,
      buyer_name VARCHAR(255) NOT NULL,
      buyer_phone VARCHAR(50) NOT NULL,
      buyer_message TEXT,
      status ENUM('new','contacted','closed') NOT NULL DEFAULT 'new',
      created_at DATETIME NOT NULL DEFAULT NOW(),
      FOREIGN KEY (listing_id) REFERENCES golet_listings(id) ON DELETE CASCADE,
      FOREIGN KEY (seller_id) REFERENCES users(id)
    )`);

    console.log('MySQL tables initialized');
  } catch (e) {
    console.warn('DB init error:', (e as Error).message);
  }
}

init();

export default db;
