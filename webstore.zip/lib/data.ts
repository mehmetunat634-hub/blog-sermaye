export interface WebApp {
  id: string;
  slug: string;
  name: string;
  description: string;
  category: string;
  price: number;
  icon: string;
  rating: number;
  developer: string;
  isPaid: boolean;
}

// Mock veriler temizlendi, gerçek uygulamalar eklenecek.
export const mockApps: WebApp[] = [
  {
    id: 'adisyon-basic',
    slug: 'adisyon',
    name: 'Adisyon',
    description: 'Küçük işletmeler için hızlı ve kolay adisyon yönetim sistemi. Masaları yönetin, sipariş alın ve hesapları kolayca kapatın.',
    category: 'İşletme',
    price: 0,
    icon: '🧾',
    rating: 5.0,
    developer: 'ParasızSepet',
    isPaid: false,
  },
  {
    id: 'adisyon-pro',
    slug: 'adisyon-pro',
    name: 'Adisyon Pro',
    description: 'Tam fonksiyonel restoran yönetim sistemi. Masalar, mutfak yönetimi, stok takibi, personel yönetimi ve detaylı finansal raporlama özellikleriyle işletmenizi tam kapasite yönetin.',
    category: 'İşletme',
    price: 500,
    icon: '💎',
    rating: 5.0,
    developer: 'ParasızSepet',
    isPaid: true,
  },
  {
    id: 'saksek-soru-cevap',
    slug: 'saksek-soru-cevap',
    name: 'SakSek: Soru Cevap',
    description: 'Genel kültür bilgini test et! 20 soruluk eğlenceli yarışma ile keyifli dakikalar geçirin.',
    category: 'Eğlence',
    price: 0,
    icon: '❓',
    rating: 4.5,
    developer: 'ParasızSepet',
    isPaid: false,
  },
  {
    id: 'cari',
    slug: 'cari',
    name: 'Cari Basic',
    description: 'Kişisel finans yönetiminde yanı başınızdaki uygulama. Nakit akışı, borç-alacak, gider takibi, kur hesaplayıcı ve fatura hazırlayıcı ile tüm finansal işlemlerinizi tek bir yerden yönetin.',
    category: 'Finans',
    price: 0,
    icon: '💹',
    rating: 4.9,
    developer: 'ParasızSepet',
    isPaid: false,
  },
  {
    id: 'golet',
    slug: 'golet',
    name: 'GoLet',
    description: 'Alışverişin yeni adresi. İkinci el ve sıfır ürünleri keşfedin, ilan verin, satışa çıkarın. Her şey bir tık uzağınızda.',
    category: 'Alışveriş',
    price: 100,
    icon: '📢',
    rating: 5.0,
    developer: 'ParasızSepet',
    isPaid: true,
  }
];
