export const ILAN_KATEGORILERI = [
  'Elektronik',
  'Araba',
  'Emlak',
  'Giysi & Aksesuar',
  'Ev & Bahçe',
  'Spor & Outdoor',
  'Hobi & Oyuncak',
  'Kitap & Dergi',
  'Bebek & Çocuk',
  'Diğer',
] as const;

export const URUN_DURUMLARI = [
  { value: 'sifir', label: 'Sıfır' },
  { value: 'ikinci-el', label: 'İkinci El' },
  { value: 'arizali', label: 'Arızalı / Tamir Gerekli' },
] as const;

export const ILAN_DURUMLARI: { value: string; label: string; color: string }[] = [
  { value: 'active', label: 'Aktif', color: 'bg-emerald-100 text-emerald-700' },
  { value: 'sold', label: 'Satıldı', color: 'bg-blue-100 text-blue-700' },
  { value: 'expired', label: 'Süresi Doldu', color: 'bg-gray-100 text-gray-500' },
];

export const ALICI_DURUMLARI: { value: string; label: string; color: string }[] = [
  { value: 'new', label: 'Yeni', color: 'bg-amber-100 text-amber-700' },
  { value: 'contacted', label: 'İletişime Geçildi', color: 'bg-blue-100 text-blue-700' },
  { value: 'closed', label: 'Kapandı', color: 'bg-gray-100 text-gray-500' },
];
