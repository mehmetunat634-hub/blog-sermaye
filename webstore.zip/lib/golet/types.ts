export type ListingStatus = 'active' | 'sold' | 'expired';
export type ProductCondition = 'sifir' | 'ikinci-el' | 'arizali';
export type InquiryStatus = 'new' | 'contacted' | 'closed';

export interface GoletListing {
  id: number;
  userId: number;
  title: string;
  description: string;
  price: number;
  category: string;
  condition: string;
  location: string;
  phone: string;
  whatsapp: string;
  photos: string[];
  status: ListingStatus;
  views: number;
  createdAt: string;
  updatedAt: string;
}

export interface GoletInquiry {
  id: number;
  listingId: number;
  sellerId: number;
  listingTitle?: string;
  buyerName: string;
  buyerPhone: string;
  buyerMessage: string;
  status: InquiryStatus;
  createdAt: string;
}

export interface GoletStats {
  totalListings: number;
  activeListings: number;
  soldListings: number;
  totalViews: number;
  totalInquiries: number;
  categoryDistribution: { category: string; count: number }[];
  statusDistribution: { status: string; count: number }[];
}
