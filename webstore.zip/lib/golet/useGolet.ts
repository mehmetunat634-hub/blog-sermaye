'use client';

import { useState, useEffect, useCallback } from 'react';
import type { GoletListing, GoletInquiry, GoletStats } from './types';

function token() {
  if (typeof window !== 'undefined') return localStorage.getItem('token');
  return null;
}

async function api(path: string, options?: RequestInit) {
  const t = token();
  const res = await fetch(path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(t ? { Authorization: `Bearer ${t}` } : {}),
      ...options?.headers,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'İstek başarısız' }));
    throw new Error(err.error);
  }
  return res.json();
}

export function useGolet() {
  const [listings, setListings] = useState<GoletListing[]>([]);
  const [publicListings, setPublicListings] = useState<GoletListing[]>([]);
  const [inquiries, setInquiries] = useState<GoletInquiry[]>([]);
  const [stats, setStats] = useState<GoletStats | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  const loadMyListings = useCallback(async () => {
    try {
      const data = await api('/api/golet/listings?mine=true');
      setListings(data.listings ?? []);
    } catch { }
  }, []);

  const loadPublicListings = useCallback(async (params?: string) => {
    try {
      const data = await api(`/api/golet/listings${params || ''}`);
      setPublicListings(data.listings ?? []);
    } catch { }
  }, []);

  const loadInquiries = useCallback(async () => {
    try {
      const data = await api('/api/golet/inquiries');
      setInquiries(data.inquiries ?? []);
    } catch { }
  }, []);

  const loadStats = useCallback(async () => {
    try {
      const data = await api('/api/golet/stats');
      setStats(data.stats ?? null);
    } catch { }
  }, []);

  const loadAll = useCallback(async () => {
    await Promise.all([loadMyListings(), loadInquiries(), loadStats()]);
    setIsLoaded(true);
  }, [loadMyListings, loadInquiries, loadStats]);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const createListing = async (data: Partial<GoletListing>) => {
    const res = await api('/api/golet/listings', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    await loadMyListings();
    return res;
  };

  const updateListing = async (id: number, data: Partial<GoletListing>) => {
    const res = await api(`/api/golet/listings/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
    await loadMyListings();
    return res;
  };

  const deleteListing = async (id: number) => {
    await api(`/api/golet/listings/${id}`, { method: 'DELETE' });
    await loadMyListings();
  };

  const updateListingStatus = async (id: number, status: string) => {
    const res = await api(`/api/golet/listings/${id}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
    await loadMyListings();
    return res;
  };

  const submitInquiry = async (listingId: number, data: { buyerName: string; buyerPhone: string; buyerMessage: string }) => {
    return api('/api/golet/inquiries', {
      method: 'POST',
      body: JSON.stringify({ listingId, ...data }),
    });
  };

  const updateInquiryStatus = async (id: number, status: string) => {
    const res = await api(`/api/golet/inquiries/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ status }),
    });
    await loadInquiries();
    return res;
  };

  const getPriceEstimate = async (data: { category: string; condition: string; age?: number }) => {
    return api('/api/golet/price-estimate', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  };

  return {
    listings,
    publicListings,
    inquiries,
    stats,
    isLoaded,
    loadPublicListings,
    loadMyListings,
    loadStats,
    createListing,
    updateListing,
    deleteListing,
    updateListingStatus,
    submitInquiry,
    updateInquiryStatus,
    getPriceEstimate,
  };
}
