export const GIDER_KATEGORILERI = [
  'Kira / Aidat',
  'Faturalar',
  'Market / Gıda',
  'Ulaşım / Akaryakıt',
  'Eğitim / Sağlık',
  'Eğlence / Sosyal',
  'Teknoloji / Abonelik',
  'Giyim / Kişisel Bakım',
] as const;

export const GELIR_KATEGORILERI = [
  'Maaş',
  'Freelance / Proje',
  'Kira Geliri',
  'Faiz / Temettü',
  'Diğer',
] as const;

export const DEFAULT_CURRENCIES = [
  { code: 'USD', name: 'Amerikan Doları' },
  { code: 'EUR', name: 'Euro' },
  { code: 'GBP', name: 'İngiliz Sterlini' },
  { code: 'CHF', name: 'İsviçre Frangı' },
  { code: 'JPY', name: 'Japon Yeni' },
  { code: 'XAU', name: 'Altın (ONS)' },
  { code: 'CAD', name: 'Kanada Doları' },
  { code: 'AUD', name: 'Avustralya Doları' },
  { code: 'SEK', name: 'İsveç Kronu' },
  { code: 'NOK', name: 'Norveç Kronu' },
  { code: 'DKK', name: 'Danimarka Kronu' },
  { code: 'SAR', name: 'Suudi Arabistan Riyali' },
];

export const INVOICE_TAX_RATES = [0, 1, 8, 10, 18, 20] as const;

export function generateInvoiceNo(year?: number): string {
  const y = year || new Date().getFullYear();
  const prefix = `FTR-${y}-`;
  // In a real app, fetch the last number from DB. For now return a placeholder.
  return `${prefix}001`;
}
