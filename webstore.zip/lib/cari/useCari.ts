'use client';

import { useState, useEffect, useCallback } from 'react';
import type {
  CariTransaction,
  CariDebt,
  CariInvoice,
  InvoiceItem,
  CariContact,
  ExchangeRate,
  DashboardStats,
} from './types';

const token = () => localStorage.getItem('token');

async function api(path: string, options?: RequestInit) {
  const res = await fetch(path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token() ? { Authorization: `Bearer ${token()}` } : {}),
      ...options?.headers,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'İstek başarısız' }));
    throw new Error(err.error);
  }
  return res.json();
}

export function useCari() {
  const [transactions, setTransactions] = useState<CariTransaction[]>([]);
  const [debts, setDebts] = useState<CariDebt[]>([]);
  const [invoices, setInvoices] = useState<CariInvoice[]>([]);
  const [contacts, setContacts] = useState<CariContact[]>([]);
  const [rates, setRates] = useState<ExchangeRate[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  const loadAll = useCallback(async () => {
    try {
      if (!token()) { setIsLoaded(true); return; }
      const [txData, debtData, invData, cData, rData] = await Promise.all([
        api('/api/cari/transactions'),
        api('/api/cari/debts'),
        api('/api/cari/invoices'),
        api('/api/cari/contacts'),
        api('/api/cari/exchange-rates').catch(() => []),
      ]);
      setTransactions(txData);
      setDebts(debtData);
      setInvoices(invData);
      setContacts(cData);
      setRates(rData);
    } catch {
      // silent
    } finally {
      setIsLoaded(true);
    }
  }, []);

  const loadStats = useCallback(async () => {
    try {
      if (!token()) return;
      const s = await api('/api/cari/transactions/stats');
      setStats(s);
    } catch {}
  }, []);

  useEffect(() => { loadAll(); }, [loadAll]);
  useEffect(() => { if (isLoaded) loadStats(); }, [isLoaded, loadStats]);

  const addTransaction = async (data: {
    type: 'gelir' | 'gider';
    amount: number;
    category: string;
    description?: string;
    transactionDate: string;
  }) => {
    const result = await api('/api/cari/transactions', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    setTransactions(prev => [result, ...prev]);
    await loadStats();
    return result;
  };

  const deleteTransaction = async (id: number) => {
    await api(`/api/cari/transactions?id=${id}`, { method: 'DELETE' });
    setTransactions(prev => prev.filter(t => t.id !== id));
    await loadStats();
  };

  const addDebt = async (data: {
    personName: string;
    type: 'borc' | 'alacak';
    amount: number;
    dueDate?: string;
    note?: string;
  }) => {
    const result = await api('/api/cari/debts', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    setDebts(prev => [result, ...prev]);
    return result;
  };

  const updateDebtStatus = async (id: number, status: 'aktif' | 'odendi' | 'iptal') => {
    await api(`/api/cari/debts`, {
      method: 'PATCH',
      body: JSON.stringify({ id, status }),
    });
    setDebts(prev => prev.map(d => d.id === id ? { ...d, status } : d));
  };

  const deleteDebt = async (id: number) => {
    await api(`/api/cari/debts?id=${id}`, { method: 'DELETE' });
    setDebts(prev => prev.filter(d => d.id !== id));
  };

  const addInvoice = async (data: {
    customerName: string;
    customerPhone?: string;
    customerAddress?: string;
    items: InvoiceItem[];
    taxRate: number;
  }) => {
    const result = await api('/api/cari/invoices', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    setInvoices(prev => [result, ...prev]);
    return result;
  };

  const updateInvoiceStatus = async (id: number, status: 'taslak' | 'gonderildi' | 'odendi') => {
    await api(`/api/cari/invoices`, {
      method: 'PATCH',
      body: JSON.stringify({ id, status }),
    });
    setInvoices(prev => prev.map(inv => inv.id === id ? { ...inv, status } : inv));
  };

  const deleteInvoice = async (id: number) => {
    await api(`/api/cari/invoices?id=${id}`, { method: 'DELETE' });
    setInvoices(prev => prev.filter(inv => inv.id !== id));
  };

  const addContact = async (data: { name: string; phone?: string; email?: string; address?: string }) => {
    const result = await api('/api/cari/contacts', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    setContacts(prev => [result, ...prev]);
    return result;
  };

  const refreshRates = async () => {
    try {
      const data = await api('/api/cari/exchange-rates');
      setRates(data);
    } catch {}
  };

  return {
    transactions,
    debts,
    invoices,
    contacts,
    rates,
    stats,
    isLoaded,
    addTransaction,
    deleteTransaction,
    addDebt,
    updateDebtStatus,
    deleteDebt,
    addInvoice,
    updateInvoiceStatus,
    deleteInvoice,
    addContact,
    refreshRates,
    loadStats,
  };
}
