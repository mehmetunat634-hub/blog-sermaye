export interface CariTransaction {
  id: number;
  userId: number;
  type: 'gelir' | 'gider';
  amount: number;
  category: string;
  description: string;
  transactionDate: string;
  createdAt: string;
}

export interface CariDebt {
  id: number;
  userId: number;
  personName: string;
  type: 'borc' | 'alacak';
  amount: number;
  dueDate: string | null;
  note: string;
  status: 'aktif' | 'odendi' | 'iptal';
  createdAt: string;
}

export interface InvoiceItem {
  id: string;
  name: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface CariInvoice {
  id: number;
  userId: number;
  invoiceNo: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  status: 'taslak' | 'gonderildi' | 'odendi';
  createdAt: string;
}

export interface CariContact {
  id: number;
  userId: number;
  name: string;
  phone: string;
  email: string;
  address: string;
  createdAt: string;
}

export interface ExchangeRate {
  code: string;
  name: string;
  buying: number;
  selling: number;
}

export interface DashboardStats {
  totalIncome: number;
  totalExpense: number;
  balance: number;
  activeDebt: number;
  activeReceivable: number;
  monthlyIncome: number;
  monthlyExpense: number;
  recentTransactions: CariTransaction[];
  expenseByCategory: { category: string; total: number }[];
}
