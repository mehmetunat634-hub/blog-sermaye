'use client';

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export type CariRole = { type: 'owner'; name: string } | { type: 'staff'; name: string } | null;

interface CariRoleContextType {
  role: CariRole;
  setRole: (role: CariRole) => void;
  isOwner: boolean;
  roleName: string;
}

const CariRoleContext = createContext<CariRoleContextType | null>(null);

export function CariRoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<CariRole>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const stored = sessionStorage.getItem('cari_role');
      if (stored === 'owner') {
        setRole({ type: 'owner', name: 'Sahip' });
      } else if (stored) {
        setRole({ type: 'staff', name: stored });
      }
    }
  }, []);

  const isOwner = role?.type === 'owner';
  const roleName = role?.name ?? '';

  return (
    <CariRoleContext.Provider value={{ role, setRole, isOwner, roleName }}>
      {children}
    </CariRoleContext.Provider>
  );
}

export function useCariRole() {
  const ctx = useContext(CariRoleContext);
  if (!ctx) throw new Error('useCariRole must be used within CariRoleProvider');
  return ctx;
}
