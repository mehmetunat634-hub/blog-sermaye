'use client';

import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';

interface User {
  id: number;
  email: string;
  name: string;
  balance: number;
  role: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  isStoreUnlocked: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, name: string, password: string) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
  lockStore: () => void;
  unlockStore: (password: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

function getStoreLocked(): boolean {
  if (typeof window === 'undefined') return true;
  return sessionStorage.getItem('store_locked') === 'true';
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isStoreUnlocked, setIsStoreUnlocked] = useState(!getStoreLocked());

  const fetchUser = useCallback(async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data.user);
      } else {
        localStorage.removeItem('token');
        setUser(null);
      }
    } catch {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  const login = async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    localStorage.setItem('token', data.token);
    sessionStorage.removeItem('store_locked');
    setIsStoreUnlocked(true);
    setUser(data.user);
  };

  const register = async (email: string, name: string, password: string) => {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, name, password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    localStorage.setItem('token', data.token);
    sessionStorage.removeItem('store_locked');
    setIsStoreUnlocked(true);
    setUser(data.user);
  };

  const logout = () => {
    localStorage.removeItem('token');
    sessionStorage.removeItem('store_locked');
    setUser(null);
    setIsStoreUnlocked(false);
  };

  const refreshUser = async () => {
    await fetchUser();
  };

  const lockStore = () => {
    sessionStorage.setItem('store_locked', 'true');
    setIsStoreUnlocked(false);
  };

  const unlockStore = async (password: string) => {
    const token = localStorage.getItem('token');
    if (!token) throw new Error('Oturum bulunamadı');

    const res = await fetch('/api/auth/verify-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ password })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    sessionStorage.removeItem('store_locked');
    setIsStoreUnlocked(true);
  };

  return (
    <AuthContext.Provider value={{
      user, loading, isAdmin: user?.role === 'admin',
      isStoreUnlocked,
      login, register, logout, refreshUser,
      lockStore, unlockStore
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
