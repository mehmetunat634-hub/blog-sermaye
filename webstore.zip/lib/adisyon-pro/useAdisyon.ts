'use client';

import { useState, useEffect, useCallback } from 'react';
import { Table, MenuItem, OrderItem, BillRecord, PaymentMethod, ServiceChargeRate } from './constants';

const token = () => localStorage.getItem('token');

async function api(path: string, options?: RequestInit) {
  const res = await fetch(path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token() ? { Authorization: `Bearer ${token()}` } : {}),
      ...options?.headers,
    },
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'İstek başarısız' }));
    throw new Error(err.error);
  }
  return res.json();
}

export function useAdisyon() {
  const [tables, setTables] = useState<Table[]>([]);
  const [billHistory, setBillHistory] = useState<BillRecord[]>([]);
  const [kitchenOrders, setKitchenOrders] = useState<any[]>([]);
  const [isLoaded, setIsLoaded] = useState(false);

  const loadState = useCallback(async () => {
    try {
      if (!token()) { setIsLoaded(true); return; }
      const data = await api('/api/adisyon-pro/state');
      if (data.tables?.length > 0) {
        setTables(data.tables);
      } else {
        const initial: Table[] = Array.from({ length: 12 }, (_, i) => ({
          id: i + 1,
          name: `Masa ${i + 1}`,
          orders: [],
          isOpen: false,
          note: '',
          openedAt: null,
        }));
        setTables(initial);
      }
      if (data.bills) setBillHistory(data.bills);
      if (data.kitchenOrders) setKitchenOrders(data.kitchenOrders);
    } catch {
      const initial: Table[] = Array.from({ length: 12 }, (_, i) => ({
        id: i + 1,
        name: `Masa ${i + 1}`,
        orders: [],
        isOpen: false,
        note: '',
        openedAt: null,
      }));
      setTables(initial);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  const saveTables = useCallback(async (newTables: Table[]) => {
    try {
      await api('/api/adisyon-pro/state', {
        method: 'POST',
        body: JSON.stringify({ tables: newTables }),
      });
    } catch {} // silent fail
  }, []);

  useEffect(() => { loadState(); }, [loadState]);

  useEffect(() => {
    if (isLoaded && token()) {
      saveTables(tables);
    }
  }, [tables, isLoaded, saveTables]);

  const addOrder = (tableId: number, item: MenuItem) => {
    setTables(prev => prev.map(table => {
      if (table.id !== tableId) return table;
      const existing = table.orders.find(o => o.id === item.id);
      let newOrders: OrderItem[];
      if (existing) {
        newOrders = table.orders.map(o =>
          o.id === item.id ? { ...o, quantity: o.quantity + 1 } : o
        );
      } else {
        newOrders = [...table.orders, { ...item, quantity: 1, note: '' }];
      }
      return { ...table, orders: newOrders, isOpen: true, openedAt: table.openedAt || new Date().toISOString() };
    }));
  };

  const addOrderWithQty = (tableId: number, item: MenuItem, qty: number) => {
    if (qty <= 0) return;
    setTables(prev => prev.map(table => {
      if (table.id !== tableId) return table;
      const existing = table.orders.find(o => o.id === item.id);
      let newOrders: OrderItem[];
      if (existing) {
        newOrders = table.orders.map(o =>
          o.id === item.id ? { ...o, quantity: o.quantity + qty } : o
        );
      } else {
        newOrders = [...table.orders, { ...item, quantity: qty, note: '' }];
      }
      return { ...table, orders: newOrders, isOpen: true, openedAt: table.openedAt || new Date().toISOString() };
    }));
  };

  const removeOrder = (tableId: number, itemId: string) => {
    setTables(prev => prev.map(table => {
      if (table.id !== tableId) return table;
      const newOrders = table.orders.map(o =>
        o.id === itemId ? { ...o, quantity: Math.max(0, o.quantity - 1) } : o
      ).filter(o => o.quantity > 0);
      return { ...table, orders: newOrders, isOpen: newOrders.length > 0 };
    }));
  };

  const setOrderNote = (tableId: number, itemId: string, note: string) => {
    setTables(prev => prev.map(table => {
      if (table.id !== tableId) return table;
      return { ...table, orders: table.orders.map(o => o.id === itemId ? { ...o, note } : o) };
    }));
  };

  const setTableNote = (tableId: number, note: string) => {
    setTables(prev => prev.map(t => t.id === tableId ? { ...t, note } : t));
  };

  const closeTable = async (tableId: number, paymentMethod: PaymentMethod = 'cash', discount: number = 0) => {
    const table = tables.find(t => t.id === tableId);
    if (!table) return;

    const subtotal = table.orders.reduce((s, item) => s + item.price * item.quantity, 0);
    const serviceCharge = Math.round(subtotal * ServiceChargeRate);
    const total = subtotal + serviceCharge - discount;

    try {
      await api('/api/adisyon-pro/bill', {
        method: 'POST',
        body: JSON.stringify({
          tableName: table.name,
          items: table.orders,
          total,
          discount,
          serviceCharge,
          paymentMethod,
        }),
      });

      setBillHistory(prev => [{
        id: Date.now(),
        tableName: table.name,
        items: [...table.orders],
        total,
        discount,
        serviceCharge,
        paymentMethod,
        closedAt: new Date().toISOString(),
      }, ...prev]);
    } catch {}

    setTables(prev => prev.map(t =>
      t.id === tableId ? { ...t, orders: [], isOpen: false, note: '', openedAt: null } : t
    ));
  };

  const reopenTable = async (record: BillRecord) => {
    const match = tables.find(t => t.name === record.tableName);
    if (!match) return;

    setTables(prev => prev.map(t =>
      t.id === match.id ? { ...t, orders: record.items.map(i => ({ ...i, note: i.note || '' })), isOpen: true, openedAt: new Date().toISOString(), note: '' } : t
    ));

    setBillHistory(prev => prev.filter(r => r.id !== record.id));

    try {
      await api(`/api/adisyon-pro/bill`, {
        method: 'DELETE',
        body: JSON.stringify({ billId: record.id }),
      });
    } catch {}
  };

  const sendToKitchen = async (tableId: number) => {
    const table = tables.find(t => t.id === tableId);
    if (!table || table.orders.length === 0) return;

    try {
      const result = await api('/api/adisyon-pro/kitchen', {
        method: 'POST',
        body: JSON.stringify({ tableId: table.id, tableName: table.name, items: table.orders }),
      });
      setKitchenOrders(prev => [...prev, { id: result.id, tableId: table.id, tableName: table.name, items: table.orders, status: 'pending', sentAt: new Date().toISOString() }]);
    } catch {}
  };

  const updateKitchenStatus = async (orderId: number, status: string) => {
    setKitchenOrders(prev => prev.map(o => o.id === orderId ? { ...o, status } : o));
    try {
      await api('/api/adisyon-pro/kitchen', { method: 'PATCH', body: JSON.stringify({ orderId, status }) });
    } catch {}
  };

  const getTableTotal = (tableId: number) => {
    const table = tables.find(t => t.id === tableId);
    if (!table) return 0;
    return table.orders.reduce((s, item) => s + item.price * item.quantity, 0);
  };

  const getElapsed = (tableId: number) => {
    const table = tables.find(t => t.id === tableId);
    if (!table?.openedAt) return '—';
    const diff = Date.now() - new Date(table.openedAt).getTime();
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    return h > 0 ? `${h}s ${m}d` : `${m}d`;
  };

  return {
    tables,
    billHistory,
    kitchenOrders,
    isLoaded,
    addOrder,
    addOrderWithQty,
    removeOrder,
    setOrderNote,
    setTableNote,
    closeTable,
    reopenTable,
    sendToKitchen,
    updateKitchenStatus,
    getTableTotal,
    getElapsed,
  };
}
