export interface MenuItem {
  id: string;
  name: string;
  price: number;
  category: string;
}

export interface OrderItem extends MenuItem {
  quantity: number;
  note: string;
}

export interface Table {
  id: number;
  name: string;
  orders: OrderItem[];
  isOpen: boolean;
  note: string;
  openedAt: string | null;
}

export interface BillRecord {
  id: number;
  tableName: string;
  items: OrderItem[];
  total: number;
  discount: number;
  serviceCharge: number;
  paymentMethod: 'cash' | 'card';
  closedAt: string;
}

export type PaymentMethod = 'cash' | 'card';

export const INITIAL_TABLES_COUNT = 12;
export const ServiceChargeRate = 0.1;

export const MENU_ITEMS: MenuItem[] = [
  // İçecekler
  { id: '1', name: 'Çay', price: 20, category: 'İçecekler' },
  { id: '2', name: 'Türk Kahvesi', price: 60, category: 'İçecekler' },
  { id: '3', name: 'Filtre Kahve', price: 85, category: 'İçecekler' },
  { id: '4', name: 'Su', price: 15, category: 'İçecekler' },
  { id: '5', name: 'Maden Suyu', price: 40, category: 'İçecekler' },
  { id: '6', name: 'Limonata', price: 75, category: 'Soğuk İçecekler' },
  { id: '7', name: 'Soğuk Çay', price: 55, category: 'Soğuk İçecekler' },
  { id: '8', name: 'Ayran', price: 35, category: 'Soğuk İçecekler' },
  { id: '9', name: 'Meyve Suyu', price: 60, category: 'Soğuk İçecekler' },
  // Çorbalar
  { id: '10', name: 'Mercimek Çorbası', price: 90, category: 'Çorbalar' },
  { id: '11', name: 'Ezogelin Çorbası', price: 95, category: 'Çorbalar' },
  { id: '12', name: 'Domates Çorbası', price: 85, category: 'Çorbalar' },
  // Yiyecekler
  { id: '13', name: 'Tost', price: 120, category: 'Yiyecekler' },
  { id: '14', name: 'Simit', price: 40, category: 'Yiyecekler' },
  { id: '15', name: 'Poğaça', price: 45, category: 'Yiyecekler' },
  { id: '16', name: 'Börek (Porsiyon)', price: 110, category: 'Yiyecekler' },
  { id: '17', name: 'Sandviç', price: 150, category: 'Yiyecekler' },
  // Kahvaltı
  { id: '18', name: 'Serpme Kahvaltı (Kişi)', price: 250, category: 'Kahvaltı' },
  { id: '19', name: 'Sahanda Yumurta', price: 100, category: 'Kahvaltı' },
  { id: '20', name: 'Menemen', price: 110, category: 'Kahvaltı' },
  // Tatlılar
  { id: '21', name: 'Kuru Pasta', price: 95, category: 'Tatlılar' },
  { id: '22', name: 'Sütlaç', price: 120, category: 'Tatlılar' },
  { id: '23', name: 'Baklava (Porsiyon)', price: 150, category: 'Tatlılar' },
  { id: '24', name: 'Cheesecake', price: 180, category: 'Tatlılar' },
  { id: '25', name: 'Profiterol', price: 165, category: 'Tatlılar' },
];
