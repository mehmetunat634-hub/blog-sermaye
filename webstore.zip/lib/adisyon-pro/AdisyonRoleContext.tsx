'use client';

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

export type AdisyonRole = { type: 'owner'; name: string } | { type: 'staff'; name: string } | null;

interface AdisyonRoleContextType {
  role: AdisyonRole;
  setRole: (role: AdisyonRole) => void;
  isOwner: boolean;
  roleName: string;
}

const AdisyonRoleContext = createContext<AdisyonRoleContextType | null>(null);

export function AdisyonRoleProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<AdisyonRole>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const stored = sessionStorage.getItem('in_app_role');
      if (stored === 'owner') {
        setRole({ type: 'owner', name: 'Sahip' });
      } else if (stored) {
        setRole({ type: 'staff', name: stored });
      }
    }
  }, []);

  const isOwner = role?.type === 'owner';
  const roleName = role?.name ?? '';

  return (
    <AdisyonRoleContext.Provider value={{ role, setRole, isOwner, roleName }}>
      {children}
    </AdisyonRoleContext.Provider>
  );
}

export function useAdisyonRole() {
  const ctx = useContext(AdisyonRoleContext);
  if (!ctx) throw new Error('useAdisyonRole must be used within AdisyonRoleProvider');
  return ctx;
}
