'use client';

import { use, useState, useEffect } from 'react';
import { mockApps, WebApp } from '@/lib/data';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Save, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

interface PageProps {
  params: Promise<{ slug: string }>;
}

export default function EditAppPage({ params }: PageProps) {
  const { slug } = use(params);
  const router = useRouter();
  const [app, setApp] = useState<WebApp | null>(null);
  const [price, setPrice] = useState<string>('');
  const [isSaving, setIsSaving] = useState(false);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const foundApp = mockApps.find((a) => a.slug === slug);
    if (foundApp) {
      setApp(foundApp);
      setPrice(foundApp.price.toString());
    }
  }, [slug]);

  if (!app) {
    return <div className="p-20 text-center text-gray-500 font-medium">Uygulama yükleniyor veya bulunamadı...</div>;
  }

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        router.push('/admin');
      }, 1500);
    }, 1000);
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <Link 
        href="/admin" 
        className="inline-flex items-center space-x-2 text-gray-500 hover:text-gray-900 mb-8 font-medium transition-colors"
      >
        <ArrowLeft className="h-5 w-5" />
        <span>Geri Dön</span>
      </Link>

      <div className="bg-white border border-gray-200 rounded-[2.5rem] p-8 md:p-12 shadow-sm">
        <div className="flex items-center space-x-6 mb-12">
          <div className="w-24 h-24 rounded-3xl bg-gray-100 flex items-center justify-center text-5xl shadow-inner">
            {app.icon}
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">{app.name}</h1>
            <p className="text-gray-500 font-medium">{app.category} • {app.developer}</p>
          </div>
        </div>

        <form onSubmit={handleSave} className="space-y-8">
          <div className="space-y-3">
            <label htmlFor="price" className="block text-sm font-bold text-gray-700 uppercase tracking-wider">
              Uygulama Fiyatı (TL)
            </label>
            <div className="relative">
              <input
                type="number"
                id="price"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                className="block w-full px-6 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-lg font-semibold focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
                placeholder="0.00"
                step="0.01"
                required
              />
              <div className="absolute inset-y-0 right-6 flex items-center pointer-events-none text-gray-400 font-bold">
                TL
              </div>
            </div>
            <p className="flex items-center text-xs text-gray-400 font-medium">
              <AlertCircle className="h-3 w-3 mr-1" />
              0 girilirse uygulama ücretsiz olarak listelenecektir.
            </p>
          </div>

          <div className="space-y-3">
            <label className="block text-sm font-bold text-gray-700 uppercase tracking-wider">
              Açıklama
            </label>
            <textarea
              className="block w-full px-6 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-gray-600 focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all min-h-[150px]"
              defaultValue={app.description}
              disabled
            />
            <p className="text-xs text-gray-400 font-medium italic">
              Açıklama metni şu an için sadece geliştirici tarafından kod üzerinden güncellenebilir.
            </p>
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className={`w-full py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center space-x-2 ${
              success 
                ? 'bg-green-500 text-white shadow-lg shadow-green-500/25' 
                : 'bg-blue-600 text-white hover:bg-blue-700 shadow-lg shadow-blue-500/25 active:scale-95'
            } disabled:opacity-50 disabled:cursor-not-allowed`}
          >
            {isSaving ? (
              <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin" />
            ) : success ? (
              <span>Başarıyla Kaydedildi!</span>
            ) : (
              <>
                <Save className="h-5 w-5" />
                <span>Değişiklikleri Kaydet</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
