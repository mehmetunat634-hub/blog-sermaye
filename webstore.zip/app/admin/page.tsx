'use client';

import { useState, useEffect } from 'react';
import { mockApps } from '@/lib/data';
import Link from 'next/link';
import { useAuth } from '@/lib/AuthContext';
import { useRouter } from 'next/navigation';
import { useToast } from '@/components/Toast';
import { Edit2, ExternalLink, Users, Search, Plus, Loader2, Wallet, Mail, CheckCircle, X, Clock, DollarSign, UserPlus } from 'lucide-react';
import { motion } from 'framer-motion';

interface AppUser {
  id: number;
  name: string;
  email: string;
  balance: number;
  role: string;
  created_at: string;
}

export default function AdminPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const toast = useToast();

  const [tab, setTab] = useState<'apps' | 'users' | 'requests' | 'register'>('apps');

  // User management state
  const [appUsers, setAppUsers] = useState<AppUser[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [searchInput, setSearchInput] = useState('');

  // Balance add state
  const [addingTo, setAddingTo] = useState<AppUser | null>(null);
  const [addAmount, setAddAmount] = useState('');
  const [adding, setAdding] = useState(false);
  const [addSuccess, setAddSuccess] = useState<{ name: string; email: string } | null>(null);

  useEffect(() => {
    if (!loading && (!user || user.role !== 'admin')) {
      router.push('/');
    }
  }, [user, loading, router]);

  // Balance requests state
  interface BalanceRequest {
    id: number;
    user_id: number;
    email: string;
    amount: number;
    status: string;
    created_at: string;
    user_name: string;
    user_email: string;
  }

  const [balanceRequests, setBalanceRequests] = useState<BalanceRequest[]>([]);
  const [requestsLoading, setRequestsLoading] = useState(false);

  // Registration requests state
  interface RegisterRequest {
    id: number;
    name: string;
    email: string;
    status: string;
    created_at: string;
  }

  const [registerRequests, setRegisterRequests] = useState<RegisterRequest[]>([]);
  const [registerLoading, setRegisterLoading] = useState(false);

  useEffect(() => {
    if (tab === 'users') loadUsers();
    if (tab === 'requests') loadBalanceRequests();
    if (tab === 'register') loadRegisterRequests();
  }, [tab]);

  async function loadUsers(query?: string) {
    setUsersLoading(true);
    try {
      const token = localStorage.getItem('token');
      const q = query || search;
      const url = q ? `/api/admin/users?search=${encodeURIComponent(q)}` : '/api/admin/users';
      const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
      if (res.ok) {
        const data = await res.json();
        setAppUsers(data.users || []);
      }
    } catch {} finally {
      setUsersLoading(false);
    }
  }

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    setSearch(searchInput);
    loadUsers(searchInput);
  }

  async function handleAddBalance() {
    if (!addingTo) return;
    const amount = parseInt(addAmount);
    if (isNaN(amount) || amount <= 0) return;

    setAdding(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch(`/api/admin/users/${addingTo.id}/balance`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ amount }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setAppUsers(prev => prev.map(u =>
        u.id === addingTo.id ? { ...u, balance: data.balance } : u
      ));
      setAddSuccess({ name: addingTo.name, email: addingTo.email });
      setAddAmount('');
      toast.show(`${addingTo.email} adresine ${amount} TL bakiye tanımlandı`, 'success');
    } catch (err: any) {
      toast.show(err.message, 'error');
    } finally {
      setAdding(false);
    }
  }

  async function loadBalanceRequests() {
    setRequestsLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/admin/balance-requests?status=pending', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setBalanceRequests(data.requests || []);
      }
    } catch {} finally {
      setRequestsLoading(false);
    }
  }

  async function handleApprove(req: BalanceRequest) {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch(`/api/admin/balance-requests/${req.id}/approve`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setBalanceRequests(prev => prev.filter(r => r.id !== req.id));
      toast.show(`${req.email} adresine ${req.amount} TL bakiye tanımlandı`, 'success');
    } catch (err: any) {
      toast.show(err.message, 'error');
    }
  }

  async function loadRegisterRequests() {
    setRegisterLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/admin/register-requests?status=pending', {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setRegisterRequests(data.requests || []);
      }
    } catch {} finally {
      setRegisterLoading(false);
    }
  }

  async function handleApproveRegister(req: RegisterRequest) {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch(`/api/admin/register-requests/${req.id}/approve`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setRegisterRequests(prev => prev.filter(r => r.id !== req.id));
      toast.show(`${req.email} adresine kayıt onaylandı ve kullanıcı oluşturuldu`, 'success');
    } catch (err: any) {
      toast.show(err.message, 'error');
    }
  }

  async function handleRejectRegister(req: RegisterRequest) {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch(`/api/admin/register-requests/${req.id}/reject`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setRegisterRequests(prev => prev.filter(r => r.id !== req.id));
      toast.show(`${req.email} kayıt talebi reddedildi`, 'error');
    } catch (err: any) {
      toast.show(err.message, 'error');
    }
  }

  async function handleReject(req: BalanceRequest) {
    const token = localStorage.getItem('token');
    try {
      const res = await fetch(`/api/admin/balance-requests/${req.id}/reject`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setBalanceRequests(prev => prev.filter(r => r.id !== req.id));
      toast.show(`${req.email} adresine bakiye talebi reddedildi`, 'error');
    } catch (err: any) {
      toast.show(err.message, 'error');
    }
  }

  if (loading) return <div className="p-20 text-center font-medium text-gray-500">Yükleniyor...</div>;
  if (!user || user.role !== 'admin') return null;

  const formatDate = (d: string) => new Date(d).toLocaleDateString('tr-TR');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Yönetim Paneli</h1>
        <p className="text-gray-500">Uygulamaları ve kullanıcıları yönetin.</p>
      </div>

      {/* Tabs */}
      <div className="flex space-x-2">
        <button
          onClick={() => setTab('apps')}
          className={`flex items-center space-x-2 px-6 py-3 rounded-2xl text-sm font-bold transition-all ${
            tab === 'apps' ? 'bg-gray-900 text-white shadow-lg' : 'bg-white text-gray-500 hover:bg-gray-100 border border-gray-200'
          }`}
        >
          <Edit2 className="h-4 w-4" />
          <span>Uygulamalar</span>
        </button>
        <button
          onClick={() => setTab('users')}
          className={`flex items-center space-x-2 px-6 py-3 rounded-2xl text-sm font-bold transition-all ${
            tab === 'users' ? 'bg-gray-900 text-white shadow-lg' : 'bg-white text-gray-500 hover:bg-gray-100 border border-gray-200'
          }`}
        >
          <Users className="h-4 w-4" />
          <span>Kullanıcılar</span>
        </button>
        <button
          onClick={() => setTab('requests')}
          className={`flex items-center space-x-2 px-6 py-3 rounded-2xl text-sm font-bold transition-all ${
            tab === 'requests' ? 'bg-gray-900 text-white shadow-lg' : 'bg-white text-gray-500 hover:bg-gray-100 border border-gray-200'
          }`}
        >
          <DollarSign className="h-4 w-4" />
          <span>Bakiye İsteyenler</span>
          {balanceRequests.length > 0 && (
            <span className="ml-1 px-2 py-0.5 text-xs bg-amber-500 text-white rounded-full font-bold">
              {balanceRequests.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setTab('register')}
          className={`flex items-center space-x-2 px-6 py-3 rounded-2xl text-sm font-bold transition-all ${
            tab === 'register' ? 'bg-gray-900 text-white shadow-lg' : 'bg-white text-gray-500 hover:bg-gray-100 border border-gray-200'
          }`}
        >
          <UserPlus className="h-4 w-4" />
          <span>Kayıt Olmak İsteyenler</span>
          {registerRequests.length > 0 && (
            <span className="ml-1 px-2 py-0.5 text-xs bg-amber-500 text-white rounded-full font-bold">
              {registerRequests.length}
            </span>
          )}
        </button>
      </div>

      {/* Apps Tab */}
      {tab === 'apps' && (
        <div className="bg-white border border-gray-200 rounded-[2rem] overflow-hidden shadow-sm">
          <table className="w-full text-left">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-8 py-4 text-sm font-semibold text-gray-600">Uygulama</th>
                <th className="px-8 py-4 text-sm font-semibold text-gray-600">Kategori</th>
                <th className="px-8 py-4 text-sm font-semibold text-gray-600">Fiyat</th>
                <th className="px-8 py-4 text-sm font-semibold text-gray-600 text-right">İşlemler</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {mockApps.map((app) => (
                <tr key={app.id} className="hover:bg-gray-50/50 transition-colors">
                  <td className="px-8 py-5">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center text-2xl">{app.icon}</div>
                      <div>
                        <div className="font-bold text-gray-900">{app.name}</div>
                        <div className="text-sm text-gray-500">{app.developer}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-gray-600 font-medium">{app.category}</td>
                  <td className="px-8 py-5">
                    <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                      app.price === 0 ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'
                    }`}>
                      {app.price === 0 ? 'Ücretsiz' : `${app.price} TL`}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <div className="flex items-center justify-end space-x-2">
                      <Link href={`/${app.slug}`} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all" title="Görüntüle">
                        <ExternalLink className="h-5 w-5" />
                      </Link>
                      <Link href={`/admin/edit/${app.slug}`} className="flex items-center space-x-2 px-4 py-2 bg-gray-900 text-white text-sm font-bold rounded-xl hover:bg-gray-800 transition-all active:scale-95">
                        <Edit2 className="h-4 w-4" />
                        <span>Düzenle</span>
                      </Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Balance Requests Tab */}
      {tab === 'requests' && (
        <div className="space-y-6">
          {requestsLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
            </div>
          ) : balanceRequests.length === 0 ? (
            <div className="bg-white rounded-[2rem] p-16 text-center border border-gray-200">
              <Clock className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 font-medium">Bekleyen bakiye talebi bulunmuyor.</p>
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-[2rem] overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Kullanıcı</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">E-posta</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Tutar</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Tarih</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {balanceRequests.map((req, i) => (
                    <motion.tr
                      key={req.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="hover:bg-gray-50/50 transition-colors"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-white text-sm font-bold">
                            {req.user_name.charAt(0).toUpperCase()}
                          </div>
                          <span className="font-medium text-gray-900">{req.user_name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-1.5">
                          <Mail className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600 font-medium">{req.email}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-1">
                          <Wallet className="h-4 w-4 text-gray-400" />
                          <span className="font-bold text-gray-900">{req.amount.toLocaleString('tr-TR')} TL</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 font-medium">{formatDate(req.created_at)}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => handleApprove(req)}
                            className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-bold rounded-xl hover:bg-emerald-700 transition-all active:scale-95"
                          >
                            <CheckCircle className="h-4 w-4" />
                            <span>Onayla</span>
                          </button>
                          <button
                            onClick={() => handleReject(req)}
                            className="flex items-center space-x-1.5 px-4 py-2 bg-red-500 text-white text-sm font-bold rounded-xl hover:bg-red-600 transition-all active:scale-95"
                          >
                            <X className="h-4 w-4" />
                            <span>Reddet</span>
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Register Requests Tab */}
      {tab === 'register' && (
        <div className="space-y-6">
          {registerLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
            </div>
          ) : registerRequests.length === 0 ? (
            <div className="bg-white rounded-[2rem] p-16 text-center border border-gray-200">
              <UserPlus className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 font-medium">Bekleyen kayıt talebi bulunmuyor.</p>
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-[2rem] overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Ad Soyad</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">E-posta</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Tarih</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {registerRequests.map((req, i) => (
                    <motion.tr
                      key={req.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="hover:bg-gray-50/50 transition-colors"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500 to-purple-600 flex items-center justify-center text-white text-sm font-bold">
                            {req.name.charAt(0).toUpperCase()}
                          </div>
                          <span className="font-medium text-gray-900">{req.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-1.5">
                          <Mail className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600 font-medium">{req.email}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 font-medium">{formatDate(req.created_at)}</td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex items-center justify-end space-x-2">
                          <button
                            onClick={() => handleApproveRegister(req)}
                            className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-bold rounded-xl hover:bg-emerald-700 transition-all active:scale-95"
                          >
                            <CheckCircle className="h-4 w-4" />
                            <span>Onayla</span>
                          </button>
                          <button
                            onClick={() => handleRejectRegister(req)}
                            className="flex items-center space-x-1.5 px-4 py-2 bg-red-500 text-white text-sm font-bold rounded-xl hover:bg-red-600 transition-all active:scale-95"
                          >
                            <X className="h-4 w-4" />
                            <span>Reddet</span>
                          </button>
                        </div>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Users Tab */}
      {tab === 'users' && (
        <div className="space-y-6">
          {/* Search */}
          <form onSubmit={handleSearch} className="flex space-x-3">
            <div className="relative flex-grow">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchInput}
                onChange={e => setSearchInput(e.target.value)}
                placeholder="E-posta ile ara..."
                className="w-full pl-12 pr-4 py-3 bg-white border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500"
              />
            </div>
            <button
              type="submit"
              className="px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98]"
            >
              Ara
            </button>
            {search && (
              <button
                type="button"
                onClick={() => { setSearch(''); setSearchInput(''); loadUsers(''); }}
                className="px-6 py-3 bg-gray-100 text-gray-600 font-bold rounded-2xl hover:bg-gray-200 transition-all"
              >
                Temizle
              </button>
            )}
          </form>

          {/* Users List */}
          {usersLoading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="h-8 w-8 text-blue-600 animate-spin" />
            </div>
          ) : appUsers.length === 0 ? (
            <div className="bg-white rounded-[2rem] p-16 text-center border border-gray-200">
              <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 font-medium">
                {search ? 'Aramanızla eşleşen kullanıcı bulunamadı.' : 'Henüz kayıtlı kullanıcı yok.'}
              </p>
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-[2rem] overflow-hidden shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-gray-50 border-b border-gray-200">
                  <tr>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Ad Soyad</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">E-posta</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Bakiye</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Rol</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600">Kayıt</th>
                    <th className="px-6 py-4 text-sm font-semibold text-gray-600 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {appUsers.map((u, i) => (
                    <motion.tr
                      key={u.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.03 }}
                      className="hover:bg-gray-50/50 transition-colors"
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white text-sm font-bold">
                            {u.name.charAt(0).toUpperCase()}
                          </div>
                          <span className="font-medium text-gray-900">{u.name}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-1.5">
                          <Mail className="h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600 font-medium">{u.email}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-1">
                          <Wallet className="h-4 w-4 text-gray-400" />
                          <span className="font-bold text-gray-900">{u.balance.toLocaleString('tr-TR')} TL</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-2.5 py-1 rounded-lg text-xs font-bold ${
                          u.role === 'admin' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-600'
                        }`}>
                          {u.role === 'admin' ? 'Admin' : 'Kullanıcı'}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500 font-medium">{formatDate(u.created_at)}</td>
                      <td className="px-6 py-4 text-right">
                        <button
                          onClick={() => { setAddingTo(u); setAddAmount(''); setAddSuccess(null); }}
                          className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 text-white text-sm font-bold rounded-xl hover:bg-emerald-700 transition-all active:scale-95"
                        >
                          <Plus className="h-4 w-4" />
                          <span>Bakiye Ekle</span>
                        </button>
                      </td>
                    </motion.tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Balance Add Modal */}
          {addingTo && (
            <div className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4" onClick={() => setAddingTo(null)}>
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white rounded-[2.5rem] p-8 max-w-sm w-full shadow-2xl"
                onClick={e => e.stopPropagation()}
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900">Bakiye Ekle</h2>
                  <button onClick={() => setAddingTo(null)} className="p-2 text-gray-400 hover:text-gray-600 rounded-xl hover:bg-gray-100 transition-colors">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-2xl">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold">
                      {addingTo.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="font-bold text-gray-900 text-sm">{addingTo.name}</div>
                      <div className="text-sm text-gray-500">{addingTo.email}</div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1.5">Yüklenecek Tutar (TL)</label>
                    <input
                      type="number"
                      value={addAmount}
                      onChange={e => setAddAmount(e.target.value)}
                      placeholder="0"
                      className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-lg font-bold focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500"
                      autoFocus
                    />
                  </div>

                  <div className="text-xs text-gray-400 font-medium">
                    Mevcut Bakiye: <span className="font-bold text-gray-700">{addingTo.balance.toLocaleString('tr-TR')} TL</span>
                  </div>
                </div>

                {addSuccess ? (
                  <div className="p-4 bg-emerald-50 rounded-2xl flex items-center space-x-3">
                    <CheckCircle className="h-6 w-6 text-emerald-600 flex-shrink-0" />
                    <div>
                      <p className="font-bold text-emerald-800 text-sm">Bakiye Tanımlandı</p>
                      <p className="text-sm text-emerald-700">{addSuccess.email} adresine bakiye tanımlandı.</p>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={handleAddBalance}
                    disabled={!addAmount || parseInt(addAmount) <= 0 || adding}
                    className="w-full py-4 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center space-x-2"
                  >
                    {adding ? (
                      <>
                        <Loader2 className="h-5 w-5 animate-spin" />
                        <span>Ekleniyor...</span>
                      </>
                    ) : (
                      <>
                        <Plus className="h-5 w-5" />
                        <span>Bakiye Ekle</span>
                      </>
                    )}
                  </button>
                )}
              </motion.div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
