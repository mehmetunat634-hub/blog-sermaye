import AdminGuard from '@/components/AdminGuard';
import { ToastProvider } from '@/components/Toast';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <AdminGuard>
      <ToastProvider>
        {children}
      </ToastProvider>
    </AdminGuard>
  );
}
