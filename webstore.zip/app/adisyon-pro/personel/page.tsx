'use client';

import { useState, useEffect } from 'react';
import { useAdisyonRole } from '@/lib/adisyon-pro/AdisyonRoleContext';
import { useRouter } from 'next/navigation';
import { useToast } from '@/components/Toast';
import {
  Users,
  UserCog,
  Plus,
  Trash2,
  Pencil,
  X,
  Check,
  Save,
  Eye,
  EyeOff,
  ShieldCheck,
  CalendarDays,
  Clock,
} from 'lucide-react';

interface Role {
  id: number;
  name: string;
  created_at: string;
}

export default function PersonelPage() {
  const { isOwner } = useAdisyonRole();
  const router = useRouter();
  const toast = useToast();

  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);

  const [showAddForm, setShowAddForm] = useState(false);
  const [newName, setNewName] = useState('');
  const [newPassword, setNewPassword] = useState('');

  const [editingId, setEditingId] = useState<number | null>(null);
  const [editName, setEditName] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [editShowPassword, setEditShowPassword] = useState(false);

  const [showPasswords, setShowPasswords] = useState(false);
  const [error, setError] = useState('');
  const [adding, setAdding] = useState(false);

  const token = () => localStorage.getItem('token');

  useEffect(() => {
    if (!isOwner) { router.push('/adisyon-pro'); return; }
    loadRoles();
  }, [isOwner, router]);

  async function loadRoles() {
    try {
      const res = await fetch('/api/adisyon-pro/roles', {
        headers: { Authorization: `Bearer ${token()}` },
      });
      if (res.ok) {
        const data = await res.json();
        setRoles(data.roles);
      }
    } catch {} finally {
      setLoading(false);
    }
  }

  async function addRole() {
    setError('');
    if (!newName.trim() || !newPassword.trim()) {
      setError('Personel adı ve şifre zorunludur');
      return;
    }
    setAdding(true);
    try {
      const res = await fetch('/api/adisyon-pro/roles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` },
        body: JSON.stringify({ name: newName.trim(), password: newPassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setRoles(prev => [...prev, data.role]);
      setNewName('');
      setNewPassword('');
      setShowAddForm(false);
      toast.show('Personel eklendi', 'success');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setAdding(false);
    }
  }

  async function saveEdit(id: number) {
    setError('');
    if (!editName.trim()) {
      setError('Personel adı zorunludur');
      return;
    }
    try {
      const body: any = { name: editName.trim() };
      if (editPassword) body.password = editPassword;

      const res = await fetch(`/api/adisyon-pro/roles/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setRoles(prev => prev.map(r => r.id === id ? { ...r, name: editName.trim() } : r));
      setEditingId(null);
      setEditPassword('');
      toast.show('Personel güncellendi', 'success');
    } catch (err: any) {
      setError(err.message);
    }
  }

  async function deleteRole(id: number, name: string) {
    if (!confirm(`${name} adlı personeli silmek istediğinize emin misiniz?`)) return;
    try {
      await fetch(`/api/adisyon-pro/roles/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token()}` },
      });
      setRoles(prev => prev.filter(r => r.id !== id));
      toast.show('Personel silindi', 'info');
    } catch {}
  }

  function startEdit(role: Role) {
    setEditingId(role.id);
    setEditName(role.name);
    setEditPassword('');
    setError('');
  }

  function cancelEdit() {
    setEditingId(null);
    setEditPassword('');
    setError('');
  }

  const formatDate = (d: string) => {
    const date = new Date(d);
    return date.toLocaleDateString('tr-TR', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  if (!isOwner) return null;

  if (loading) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Personel Yönetimi</h1>
          <p className="text-gray-500 font-medium">Personel rollerini oluşturun ve yönetin</p>
        </div>
        <button
          onClick={() => { setShowAddForm(true); setError(''); }}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>Personel Ekle</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm flex items-center space-x-4">
          <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center flex-shrink-0">
            <Users className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <div className="text-2xl font-black text-gray-900">{roles.length}</div>
            <div className="text-sm font-medium text-gray-500">Toplam Personel</div>
          </div>
        </div>
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm flex items-center space-x-4">
          <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center flex-shrink-0">
            <ShieldCheck className="h-6 w-6 text-emerald-600" />
          </div>
          <div>
            <div className="text-2xl font-black text-gray-900">{roles.filter(r => r.name.toLowerCase().includes('a')).length > 0 ? roles.length : roles.length}</div>
            <div className="text-sm font-medium text-gray-500">Aktif Personel</div>
          </div>
        </div>
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm flex items-center space-x-4">
          <div className="w-14 h-14 bg-amber-50 rounded-2xl flex items-center justify-center flex-shrink-0">
            <CalendarDays className="h-6 w-6 text-amber-600" />
          </div>
          <div>
            <div className="text-2xl font-black text-gray-900">
              {roles.length > 0 ? formatDate(roles[roles.length - 1].created_at) : '—'}
            </div>
            <div className="text-sm font-medium text-gray-500">Son Eklenen</div>
          </div>
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="p-4 bg-red-50 text-red-600 rounded-2xl text-sm font-medium">{error}</div>
      )}

      {/* Add Form */}
      {showAddForm && (
        <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-gray-900">Yeni Personel Ekle</h2>
            <button
              onClick={() => { setShowAddForm(false); setNewName(''); setNewPassword(''); setError(''); }}
              className="p-2 text-gray-400 hover:text-gray-600 rounded-xl hover:bg-gray-100 transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1.5">Personel Adı</label>
              <input
                type="text"
                value={newName}
                onChange={e => setNewName(e.target.value)}
                placeholder="Örn: Garson, Komi, Aşçıbaşı"
                className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1.5">Personel Şifresi</label>
              <div className="relative">
                <input
                  type={showPasswords ? 'text' : 'password'}
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                  placeholder="Giriş şifresi"
                  className="w-full px-5 py-4 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPasswords(!showPasswords)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPasswords ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>
          </div>
          <button
            onClick={addRole}
            disabled={!newName.trim() || !newPassword.trim() || adding}
            className="flex items-center space-x-2 px-6 py-3 bg-emerald-600 text-white font-bold rounded-2xl hover:bg-emerald-700 transition-all active:scale-[0.98] disabled:opacity-50 shadow-lg shadow-emerald-500/25"
          >
            <Save className="h-5 w-5" />
            <span>{adding ? 'Ekleniyor...' : 'Personel Oluştur'}</span>
          </button>
        </div>
      )}

      {/* Personnel List */}
      <div className="bg-white rounded-[2rem] border border-gray-100 shadow-sm overflow-hidden">
        {roles.length === 0 ? (
          <div className="text-center py-20 space-y-4">
            <div className="w-16 h-16 bg-gray-50 rounded-3xl flex items-center justify-center mx-auto">
              <Users className="h-8 w-8 text-gray-400" />
            </div>
            <div>
              <p className="text-gray-900 font-bold text-lg">Henüz personel yok</p>
              <p className="text-gray-500 text-sm font-medium mt-1">İlk personeli ekleyerek başlayın</p>
            </div>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {roles.map((role, i) => (
              <div
                key={role.id}
                className="p-6 hover:bg-gray-50/50 transition-colors"
              >
                {editingId === role.id ? (
                  /* Edit Mode */
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-gray-500 mb-1">Personel Adı</label>
                        <input
                          type="text"
                          value={editName}
                          onChange={e => setEditName(e.target.value)}
                          className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 mb-1">Yeni Şifre (opsiyonel)</label>
                        <div className="relative">
                          <input
                            type={editShowPassword ? 'text' : 'password'}
                            value={editPassword}
                            onChange={e => setEditPassword(e.target.value)}
                            placeholder="Boş bırakılırsa değişmez"
                            className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500 pr-10"
                          />
                          <button
                            type="button"
                            onClick={() => setEditShowPassword(!editShowPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                          >
                            {editShowPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <button
                        onClick={() => saveEdit(role.id)}
                        className="flex items-center space-x-1.5 px-5 py-2.5 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all text-sm"
                      >
                        <Check className="h-4 w-4" />
                        <span>Kaydet</span>
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="flex items-center space-x-1.5 px-5 py-2.5 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-all text-sm"
                      >
                        <X className="h-4 w-4" />
                        <span>İptal</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  /* View Mode */
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center text-white font-bold shadow-sm">
                        {role.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-bold text-gray-900">{role.name}</div>
                        <div className="flex items-center space-x-3 text-sm text-gray-500 font-medium mt-0.5">
                          <span className="flex items-center space-x-1">
                            <CalendarDays className="h-3.5 w-3.5" />
                            <span>{formatDate(role.created_at)}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <Clock className="h-3.5 w-3.5" />
                            <span>ID: {role.id}</span>
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => startEdit(role)}
                        className="p-2.5 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-colors"
                        title="Düzenle"
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => deleteRole(role.id, role.name)}
                        className="p-2.5 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-colors"
                        title="Sil"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
