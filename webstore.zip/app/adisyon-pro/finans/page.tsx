'use client';

import { useState } from 'react';
import { useCari } from '@/lib/cari/useCari';
import type { CariInvoice } from '@/lib/cari/types';
import {
  LayoutDashboard,
  ArrowRightLeft,
  TrendingDown,
  Handshake,
  FileText,
  RefreshCw,
  Plus,
} from 'lucide-react';

import DashboardCards from '@/components/apps/cari/DashboardCards';
import CashFlowChart from '@/components/apps/cari/CashFlowChart';
import ExpensePieChart from '@/components/apps/cari/ExpensePieChart';
import TransactionList from '@/components/apps/cari/TransactionList';
import TransactionForm from '@/components/apps/cari/TransactionForm';
import DebtList from '@/components/apps/cari/DebtList';
import DebtForm from '@/components/apps/cari/DebtForm';
import InvoiceList from '@/components/apps/cari/InvoiceList';
import InvoiceForm from '@/components/apps/cari/InvoiceForm';
import InvoicePDF from '@/components/apps/cari/InvoicePDF';
import ExchangeRateCalculator from '@/components/apps/cari/ExchangeRateCalculator';

type Tab = 'overview' | 'cashflow' | 'expenses' | 'debts' | 'invoices' | 'exchange';

const TABS: { key: Tab; label: string; icon: typeof LayoutDashboard }[] = [
  { key: 'overview', label: 'Genel Bakış', icon: LayoutDashboard },
  { key: 'cashflow', label: 'Nakit Akışı', icon: ArrowRightLeft },
  { key: 'expenses', label: 'Giderler', icon: TrendingDown },
  { key: 'debts', label: 'Borç / Alacak', icon: Handshake },
  { key: 'invoices', label: 'Faturalar', icon: FileText },
  { key: 'exchange', label: 'Kur Hesapla', icon: RefreshCw },
];

export default function FinansPage() {
  const {
    transactions, debts, invoices, rates, stats, isLoaded,
    addTransaction, deleteTransaction,
    addDebt, updateDebtStatus, deleteDebt,
    addInvoice, updateInvoiceStatus, deleteInvoice,
    refreshRates, loadStats,
  } = useCari();

  const [tab, setTab] = useState<Tab>('overview');
  const [txFormOpen, setTxFormOpen] = useState(false);
  const [debtFormOpen, setDebtFormOpen] = useState(false);
  const [invFormOpen, setInvFormOpen] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState<CariInvoice | null>(null);
  const [invFilter, setInvFilter] = useState<string>('all');
  const [debtFilter, setDebtFilter] = useState<string>('all');

  if (!isLoaded) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  const totalGelir = transactions.filter(t => t.type === 'gelir').reduce((s, t) => s + t.amount, 0);
  const totalGider = transactions.filter(t => t.type === 'gider').reduce((s, t) => s + t.amount, 0);
  const giderler = transactions.filter(t => t.type === 'gider');
  const filteredInvoices = invFilter === 'all' ? invoices : invoices.filter(inv => inv.status === invFilter);
  const filteredDebts = debtFilter === 'all' ? debts : debts.filter(d => d.status === debtFilter);
  const activeAlacak = debts.filter(d => d.type === 'alacak' && d.status === 'aktif').reduce((s, d) => s + d.amount, 0);
  const activeBorc = debts.filter(d => d.type === 'borc' && d.status === 'aktif').reduce((s, d) => s + d.amount, 0);

  const renderTabNav = () => (
    <div className="flex flex-wrap gap-2">
      {TABS.map(t => {
        const Icon = t.icon;
        return (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl text-sm font-bold transition-all ${
              tab === t.key
                ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20'
                : 'bg-white text-gray-500 hover:bg-gray-100 border border-gray-200'
            }`}
          >
            <Icon className="h-4 w-4" />
            <span>{t.label}</span>
          </button>
        );
      })}
    </div>
  );

  const renderOverview = () => (
    <div className="space-y-8">
      <DashboardCards stats={stats} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <CashFlowChart transactions={transactions} />
        <ExpensePieChart data={stats?.expenseByCategory || []} />
      </div>

      <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 mb-6">Son İşlemler</h2>
        <TransactionList
          transactions={transactions.slice(0, 10)}
          onDelete={deleteTransaction}
        />
      </div>
    </div>
  );

  const renderCashFlow = () => (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Nakit Akışı</h1>
          <p className="text-gray-500 font-medium">Tüm gelir ve gider işlemleriniz</p>
        </div>
        <button
          onClick={() => setTxFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>İşlem Ekle</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
          <p className="text-sm font-medium text-gray-500">Toplam Gelir</p>
          <p className="text-2xl font-black text-emerald-600">{totalGelir.toLocaleString()} TL</p>
        </div>
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
          <p className="text-sm font-medium text-gray-500">Toplam Gider</p>
          <p className="text-2xl font-black text-red-600">{totalGider.toLocaleString()} TL</p>
        </div>
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
          <p className="text-sm font-medium text-gray-500">Net Bakiye</p>
          <p className={`text-2xl font-black ${totalGelir - totalGider >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {(totalGelir - totalGider).toLocaleString()} TL
          </p>
        </div>
      </div>

      <CashFlowChart transactions={transactions} />

      <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 mb-6">Tüm İşlemler</h2>
        <TransactionList transactions={transactions} onDelete={deleteTransaction} />
      </div>

      <TransactionForm open={txFormOpen} onClose={() => setTxFormOpen(false)} onSave={addTransaction} />
    </div>
  );

  const renderExpenses = () => (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Gider Takibi</h1>
          <p className="text-gray-500 font-medium">Harcamalarınızı kategorilere göre yönetin</p>
        </div>
        <button
          onClick={() => setTxFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 transition-all active:scale-[0.98] shadow-lg shadow-red-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>Gider Ekle</span>
        </button>
      </div>

      <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
        <p className="text-sm font-medium text-gray-500">Toplam Gider</p>
        <p className="text-3xl font-black text-red-600">{totalGider.toLocaleString()} TL</p>
      </div>

      <ExpensePieChart data={stats?.expenseByCategory || []} />

      <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 mb-6">Tüm Giderler</h2>
        <TransactionList transactions={giderler} onDelete={deleteTransaction} />
      </div>

      <TransactionForm open={txFormOpen} onClose={() => setTxFormOpen(false)} onSave={addTransaction} />
    </div>
  );

  const renderDebts = () => (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Borç / Alacak</h1>
          <p className="text-gray-500 font-medium">Kişisel borç ve alacak takibi</p>
        </div>
        <button
          onClick={() => setDebtFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>Ekle</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-emerald-50 rounded-[2rem] p-6">
          <p className="text-sm font-medium text-emerald-700">Toplam Alacak (Aktif)</p>
          <p className="text-3xl font-black text-emerald-700">{activeAlacak.toLocaleString()} TL</p>
        </div>
        <div className="bg-red-50 rounded-[2rem] p-6">
          <p className="text-sm font-medium text-red-700">Toplam Borç (Aktif)</p>
          <p className="text-3xl font-black text-red-700">{activeBorc.toLocaleString()} TL</p>
        </div>
      </div>

      <div className="flex space-x-2">
        {['all', 'aktif', 'odendi', 'iptal'].map(f => (
          <button
            key={f}
            onClick={() => setDebtFilter(f)}
            className={`px-5 py-2 rounded-xl text-sm font-bold transition-all ${
              debtFilter === f ? 'bg-gray-900 text-white' : 'bg-white text-gray-500 hover:bg-gray-100'
            }`}
          >
            {f === 'all' ? 'Tümü' : f === 'aktif' ? 'Aktif' : f === 'odendi' ? 'Ödenen' : 'İptal'}
          </button>
        ))}
      </div>

      <DebtList debts={filteredDebts} onUpdateStatus={updateDebtStatus} onDelete={deleteDebt} />

      <DebtForm open={debtFormOpen} onClose={() => setDebtFormOpen(false)} onSave={addDebt} />
    </div>
  );

  const renderInvoices = () => (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Faturalar</h1>
          <p className="text-gray-500 font-medium">Fatura oluşturun ve yönetin</p>
        </div>
        <button
          onClick={() => setInvFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>Yeni Fatura</span>
        </button>
      </div>

      <div className="flex space-x-2">
        {[
          { key: 'all', label: 'Tümü' },
          { key: 'taslak', label: 'Taslak' },
          { key: 'gonderildi', label: 'Gönderildi' },
          { key: 'odendi', label: 'Ödendi' },
        ].map(f => (
          <button
            key={f.key}
            onClick={() => setInvFilter(f.key)}
            className={`px-5 py-2 rounded-xl text-sm font-bold transition-all ${
              invFilter === f.key ? 'bg-gray-900 text-white' : 'bg-white text-gray-500 hover:bg-gray-100'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <InvoiceList
        invoices={filteredInvoices}
        onUpdateStatus={updateInvoiceStatus}
        onDelete={deleteInvoice}
        onView={setViewingInvoice}
      />

      <InvoiceForm open={invFormOpen} onClose={() => setInvFormOpen(false)} onSave={addInvoice} />

      <InvoicePDF invoice={viewingInvoice} onClose={() => setViewingInvoice(null)} />
    </div>
  );

  const renderExchange = () => (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Kur Hesaplayıcı</h1>
        <p className="text-gray-500 font-medium">Canlı döviz kurları ile anlık hesaplama</p>
      </div>

      <ExchangeRateCalculator rates={rates} onRefresh={refreshRates} />
    </div>
  );

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Finansal Yönetim</h1>
        <p className="text-gray-500 font-medium">
          {new Date().toLocaleDateString('tr-TR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </div>

      {/* Tab Navigation */}
      {renderTabNav()}

      {/* Tab Content */}
      {tab === 'overview' && renderOverview()}
      {tab === 'cashflow' && renderCashFlow()}
      {tab === 'expenses' && renderExpenses()}
      {tab === 'debts' && renderDebts()}
      {tab === 'invoices' && renderInvoices()}
      {tab === 'exchange' && renderExchange()}
    </div>
  );
}
