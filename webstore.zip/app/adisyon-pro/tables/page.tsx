'use client';

import { useState, useEffect } from 'react';
import { useAdisyon } from '@/lib/adisyon-pro/useAdisyon';
import { MenuItem, OrderItem, PaymentMethod } from '@/lib/adisyon-pro/constants';
import { useToast } from '@/components/Toast';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, History, ArrowLeft } from 'lucide-react';
import TableGrid from '@/components/apps/adisyon-pro/TableGrid';
import MenuPanel from '@/components/apps/adisyon-pro/MenuPanel';
import BillSummary from '@/components/apps/adisyon-pro/BillSummary';

export default function TablesPage() {
  const {
    tables, billHistory, isLoaded, addOrder, addOrderWithQty, removeOrder,
    setOrderNote, setTableNote, closeTable, reopenTable, sendToKitchen, getTableTotal, getElapsed
  } = useAdisyon();
  const toast = useToast();

  const [selectedTableId, setSelectedTableId] = useState<number | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const selectedTable = tables.find(t => t.id === selectedTableId);

  useEffect(() => {
    if (showHistory) setSelectedTableId(null);
  }, [showHistory]);

  const handleSendToKitchen = () => {
    if (selectedTableId === null) return;
    sendToKitchen(selectedTableId);
    toast.show('Mutfağa gönderildi', 'success');
  };

  const handleCloseTable = (method: PaymentMethod, discount: number) => {
    if (selectedTableId === null) return;
    closeTable(selectedTableId, method, discount);
    toast.show('Hesap kapatıldı', 'success');
  };

  const handleReopenTable = (record: any) => {
    reopenTable(record);
    setShowHistory(false);
    toast.show('Masa geri açıldı', 'info');
  };

  if (!isLoaded) return (
    <div className="p-20 flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto" />
        <p className="font-medium text-gray-500">Yükleniyor...</p>
      </div>
    </div>
  );

  return (
    <div className="p-6">
      <AnimatePresence mode="wait">
        {showHistory ? (
          <motion.div key="history" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
            <div className="flex items-center justify-between mb-6">
              <button onClick={() => setShowHistory(false)} className="flex items-center space-x-2 text-gray-500 hover:text-gray-900 font-bold transition-colors">
                <ArrowLeft className="h-5 w-5" />
                <span>Geri</span>
              </button>
              <span className="text-sm font-medium text-gray-500">{billHistory.length} kayıt</span>
            </div>
            {billHistory.length === 0 ? (
              <div className="bg-white rounded-[2rem] p-16 text-center border border-gray-100">
                <History className="h-16 w-16 text-gray-200 mx-auto mb-4" />
                <p className="text-gray-400 font-medium">Henüz kapatılmış hesap yok</p>
              </div>
            ) : (
              <div className="space-y-3 max-w-2xl">
                {billHistory.map((record) => (
                  <div key={record.id} className="bg-white rounded-2xl border border-gray-200 p-5 hover:shadow-sm transition-shadow">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-3">
                          <span className="font-bold text-gray-900">{record.tableName}</span>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${record.paymentMethod === 'cash' ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700'}`}>
                            {record.paymentMethod === 'cash' ? 'Nakit' : 'Kart'}
                          </span>
                        </div>
                        <div className="text-sm text-gray-500">{new Date(record.closedAt).toLocaleString('tr-TR')} • {record.items.reduce((s, i) => s + i.quantity, 0)} kalem</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-black text-gray-900">{record.total} TL</div>
                        <button onClick={() => { handleReopenTable(record); }} className="text-xs text-blue-600 font-bold hover:underline mt-1">Yeniden Aç</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        ) : !selectedTableId ? (
          <motion.div key="grid" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Masalar</h1>
              <button onClick={() => setShowHistory(true)} className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-bold text-gray-600 hover:bg-gray-50 transition-all">
                <History className="h-4 w-4" />
                <span>Geçmiş</span>
              </button>
            </div>
            <TableGrid tables={tables} billHistory={billHistory} onSelectTable={setSelectedTableId} onReopen={(r) => { handleReopenTable(r); }} getElapsed={getElapsed} getTotal={getTableTotal} />
          </motion.div>
        ) : (
          <motion.div key="detail" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="flex flex-col lg:flex-row gap-6">
            <div className="flex-grow space-y-6">
              <button onClick={() => setSelectedTableId(null)} className="flex items-center space-x-2 text-gray-500 hover:text-gray-900 font-bold transition-colors">
                <ChevronLeft className="h-5 w-5" />
                <span>Masalara Dön</span>
              </button>
              <MenuPanel onAddOrder={(item) => addOrder(selectedTableId, item)} onAddOrderWithQty={(item, qty) => addOrderWithQty(selectedTableId, item, qty)} />
            </div>
            <div className="w-full lg:w-[420px] flex-shrink-0">
              {selectedTable && (
                  <BillSummary
                    tableName={selectedTable.name} orders={selectedTable.orders} tableNote={selectedTable.note}
                    isOpen={selectedTable.isOpen || selectedTable.orders.length > 0}
                    onRemoveOrder={(id) => removeOrder(selectedTableId, id)}
                    onAddOrder={(item) => addOrder(selectedTableId, item)}
                    onSetOrderNote={(id, note) => setOrderNote(selectedTableId, id, note)}
                    onSetTableNote={(note) => setTableNote(selectedTableId, note)}
                    onCloseTable={(method, discount) => handleCloseTable(method, discount)}
                    onSendToKitchen={() => handleSendToKitchen()}
                  />
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
