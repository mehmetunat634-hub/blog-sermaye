import Sidebar from '@/components/apps/adisyon-pro/Sidebar';
import AppGuard from '@/components/AppGuard';
import PurchaseGuard from '@/components/PurchaseGuard';
import TopHeader from '@/components/apps/adisyon-pro/TopHeader';
import InAppGuardPro from '@/components/apps/adisyon-pro/InAppGuard';
import { AdisyonRoleProvider } from '@/lib/adisyon-pro/AdisyonRoleContext';
import { SidebarProvider } from '@/components/apps/adisyon-pro/SidebarContext';
import { ToastProvider } from '@/components/Toast';

export default function AdisyonLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppGuard>
      <ToastProvider>
        <PurchaseGuard>
          <AdisyonRoleProvider>
            <SidebarProvider>
              <InAppGuardPro>
                <div className="min-h-[calc(100vh-4rem)] flex flex-col">
                  <TopHeader />
                  <Sidebar />
                  <main className="flex-grow bg-gray-50">
                    {children}
                  </main>
                </div>
              </InAppGuardPro>
            </SidebarProvider>
          </AdisyonRoleProvider>
        </PurchaseGuard>
      </ToastProvider>
    </AppGuard>
  );
}
