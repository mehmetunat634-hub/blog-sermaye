'use client';

import { Package } from 'lucide-react';

export default function StokPage() {
  return (
    <div className="p-8 flex flex-col items-center justify-center min-h-[60vh] space-y-4">
      <div className="w-20 h-20 bg-blue-50 rounded-3xl flex items-center justify-center text-blue-600">
        <Package className="h-10 w-10" />
      </div>
      <h1 className="text-2xl font-bold text-gray-900">Stok Yönetimi</h1>
      <p className="text-gray-500 text-center max-w-md">
        Ürün reçeteleri, hammadde takibi ve kritik stok seviyesi uyarıları yakında burada olacak.
      </p>
    </div>
  );
}
