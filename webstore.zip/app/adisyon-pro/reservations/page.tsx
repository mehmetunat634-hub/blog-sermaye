'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/Toast';
import { CalendarDays, Phone, User, Clock, Plus, X, CheckCircle2, AlertCircle } from 'lucide-react';

interface Reservation {
  id: number;
  tableName: string;
  guestName: string;
  guestCount: number;
  date: string;
  time: string;
  phone: string;
  status: string;
  createdAt: string;
}

const tables = Array.from({ length: 12 }, (_, i) => `Masa ${i + 1}`);

export default function ReservationsPage() {
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ tableName: '', guestName: '', guestCount: 2, date: new Date().toISOString().split('T')[0], time: '19:00', phone: '' });
  const toast = useToast();

  const token = () => localStorage.getItem('token');

  const loadReservations = async () => {
    const t = token();
    if (!t) return;
    const res = await fetch('/api/adisyon-pro/reservation', { headers: { Authorization: `Bearer ${t}` } });
    const data = await res.json();
    setReservations(data.reservations || []);
    setLoading(false);
  };

  useEffect(() => { loadReservations(); }, []);

  const createReservation = async () => {
    const t = token();
    if (!t) return;
    await fetch('/api/adisyon-pro/reservation', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` },
      body: JSON.stringify(form),
    });
    setShowForm(false);
    setForm({ tableName: '', guestName: '', guestCount: 2, date: new Date().toISOString().split('T')[0], time: '19:00', phone: '' });
    toast.show('Rezervasyon oluşturuldu', 'success');
    loadReservations();
  };

  const cancelReservation = async (id: number) => {
    const t = token();
    if (!t) return;
    await fetch('/api/adisyon-pro/reservation', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` },
      body: JSON.stringify({ id }),
    });
    toast.show('Rezervasyon iptal edildi', 'info');
    loadReservations();
  };

  const today = new Date().toISOString().split('T')[0];
  const todayReservations = reservations.filter(r => r.date === today && r.status !== 'cancelled');
  const upcoming = reservations.filter(r => r.date > today && r.status !== 'cancelled');

  if (loading) return <div className="p-20 text-center font-medium text-gray-500">Yükleniyor...</div>;

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Rezervasyonlar</h1>
          <p className="text-gray-500 font-medium">Masa rezervasyon yönetimi</p>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center space-x-2 px-5 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all active:scale-95"
        >
          <Plus className="h-5 w-5" />
          <span>Rezervasyon Ekle</span>
        </button>
      </div>

      {/* Today's Reservations */}
      <section>
        <h2 className="text-lg font-bold text-gray-900 mb-4">Bugünkü Rezervasyonlar</h2>
        {todayReservations.length === 0 ? (
          <div className="bg-white rounded-[2rem] p-12 text-center border border-gray-100">
            <CalendarDays className="h-12 w-12 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-400 font-medium">Bugün için rezervasyon yok</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {todayReservations.map(r => (
              <ReservationCard key={r.id} reservation={r} onCancel={cancelReservation} />
            ))}
          </div>
        )}
      </section>

      {/* Upcoming */}
      {upcoming.length > 0 && (
        <section>
          <h2 className="text-lg font-bold text-gray-900 mb-4">Gelecek Rezervasyonlar</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcoming.map(r => (
              <ReservationCard key={r.id} reservation={r} onCancel={cancelReservation} />
            ))}
          </div>
        </section>
      )}

      {/* Add Reservation Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 z-50 bg-black/30 flex items-center justify-center p-4" onClick={() => setShowForm(false)}>
            <motion.div initial={{ scale: 0.9 }} animate={{ scale: 1 }} exit={{ scale: 0.9 }} className="bg-white rounded-[2.5rem] p-8 w-full max-w-md shadow-2xl" onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-900">Yeni Rezervasyon</h3>
                <button onClick={() => setShowForm(false)} className="p-2 text-gray-400 hover:bg-gray-100 rounded-xl transition-colors">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1 uppercase tracking-wider text-xs">Masa</label>
                  <select value={form.tableName} onChange={e => setForm({ ...form, tableName: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                    <option value="">Seçin</option>
                    {tables.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1 uppercase tracking-wider text-xs">Misafir Adı</label>
                  <input type="text" value={form.guestName} onChange={e => setForm({ ...form, guestName: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20" placeholder="Ad Soyad" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1 uppercase tracking-wider text-xs">Kişi</label>
                    <input type="number" min={1} value={form.guestCount} onChange={e => setForm({ ...form, guestCount: parseInt(e.target.value) || 1 })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-gray-700 mb-1 uppercase tracking-wider text-xs">Saat</label>
                    <input type="time" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-1 uppercase tracking-wider text-xs">Telefon</label>
                  <input type="tel" value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20" placeholder="05XX XXX XX XX" />
                </div>
                <button
                  onClick={createReservation}
                  disabled={!form.tableName || !form.guestName}
                  className="w-full py-4 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all disabled:opacity-50 active:scale-[0.98]"
                >
                  Rezervasyon Oluştur
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function ReservationCard({ reservation, onCancel }: { reservation: Reservation; onCancel: (id: number) => void }) {
  return (
    <motion.div layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center text-blue-600">
            <User className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">{reservation.guestName}</h3>
            <p className="text-sm text-gray-500">{reservation.tableName}</p>
          </div>
        </div>
        <button onClick={() => onCancel(reservation.id)} className="p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all" title="İptal">
          <X className="h-4 w-4" />
        </button>
      </div>
      <div className="space-y-2 text-sm">
        <div className="flex items-center space-x-2 text-gray-600">
          <CalendarDays className="h-4 w-4" />
          <span className="font-medium">{new Date(reservation.date).toLocaleDateString('tr-TR')}</span>
        </div>
        <div className="flex items-center space-x-2 text-gray-600">
          <Clock className="h-4 w-4" />
          <span className="font-medium">{reservation.time}</span>
        </div>
        <div className="flex items-center space-x-2 text-gray-600">
          <User className="h-4 w-4" />
          <span className="font-medium">{reservation.guestCount} kişi</span>
        </div>
        {reservation.phone && (
          <div className="flex items-center space-x-2 text-gray-600">
            <Phone className="h-4 w-4" />
            <span className="font-medium">{reservation.phone}</span>
          </div>
        )}
      </div>
      <div className="mt-4">
        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
          reservation.status === 'confirmed' ? 'bg-green-100 text-green-700' :
          reservation.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-500'
        }`}>
          {reservation.status === 'confirmed' ? 'Onaylandı' : reservation.status === 'pending' ? 'Bekliyor' : 'İptal'}
        </span>
      </div>
    </motion.div>
  );
}
