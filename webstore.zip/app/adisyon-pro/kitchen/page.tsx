'use client';

import { useAdisyon } from '@/lib/adisyon-pro/useAdisyon';
import { useToast } from '@/components/Toast';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, ChefHat, CheckCircle2, CookingPot } from 'lucide-react';

const statusConfig: Record<string, { label: string; color: string; next: string; icon: React.ReactNode; toastMsg: string }> = {
  pending: {
    label: 'Bekliyor',
    color: 'border-l-amber-400 bg-amber-50/50',
    next: 'preparing',
    icon: <Clock className="h-6 w-6 text-amber-500" />,
    toastMsg: 'Hazırlanmaya başlandı',
  },
  preparing: {
    label: 'Hazırlanıyor',
    color: 'border-l-blue-400 bg-blue-50/50',
    next: 'ready',
    icon: <CookingPot className="h-6 w-6 text-blue-500" />,
    toastMsg: 'Sipariş hazırlandı',
  },
  ready: {
    label: 'Hazır',
    color: 'border-l-emerald-400 bg-emerald-50/50',
    next: '',
    icon: <CheckCircle2 className="h-6 w-6 text-emerald-500" />,
    toastMsg: '',
  },
};

export default function KitchenPage() {
  const { kitchenOrders, updateKitchenStatus, isLoaded } = useAdisyon();
  const toast = useToast();

  const handleUpdateStatus = (orderId: number, nextStatus: string, toastMsg: string) => {
    updateKitchenStatus(orderId, nextStatus);
    toast.show(toastMsg, 'success');
  };

  if (!isLoaded) return (
    <div className="p-20 flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto" />
        <p className="font-medium text-gray-500">Yükleniyor...</p>
      </div>
    </div>
  );

  const groups = ['pending', 'preparing'];
  const hasOrders = kitchenOrders.some(o => groups.includes(o.status));

  return (
    <div className="p-6 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Mutfak</h1>
          <p className="text-gray-500 font-medium">Canlı sipariş akışı</p>
        </div>
        <div className="flex items-center space-x-3">
          {groups.map(status => (
            <span key={status} className="flex items-center space-x-2 text-sm font-medium text-gray-500">
              {statusConfig[status].icon}
              <span>{kitchenOrders.filter(o => o.status === status).length} {statusConfig[status].label}</span>
            </span>
          ))}
        </div>
      </div>

      {!hasOrders ? (
        <div className="bg-white rounded-[2rem] p-20 text-center border border-gray-100">
          <ChefHat className="h-20 w-20 text-gray-200 mx-auto mb-6" />
          <h2 className="text-xl font-bold text-gray-400">Sipariş Yok</h2>
          <p className="text-gray-300 font-medium mt-2">Şu an mutfağa iletilen sipariş bulunmuyor</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <AnimatePresence>
            {kitchenOrders
              .filter(o => groups.includes(o.status))
              .sort((a, b) => a.status.localeCompare(b.status))
              .map((order) => {
                const config = statusConfig[order.status];
                const totalQty = order.items.reduce((s: number, i: any) => s + i.quantity, 0);
                const total = order.items.reduce((s: number, i: any) => s + i.price * i.quantity, 0);

                return (
                  <motion.div
                    key={order.id}
                    layout
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.9 }}
                    className={`bg-white rounded-[2rem] border-l-4 border border-gray-100 shadow-sm overflow-hidden ${config.color}`}
                  >
                    {/* Header */}
                    <div className="p-5 border-b border-gray-50 flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {config.icon}
                        <div>
                          <h3 className="font-bold text-gray-900">{order.tableName}</h3>
                          <p className="text-xs text-gray-500 font-medium">
                            {new Date(order.sentAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                        order.status === 'pending' ? 'bg-amber-100 text-amber-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {config.label}
                      </span>
                    </div>

                    {/* Items */}
                    <div className="p-5 space-y-3">
                      {order.items.map((item: any, i: number) => (
                        <div key={i} className="flex items-center justify-between">
                          <div className="flex items-center space-x-2">
                            <span className="w-6 h-6 bg-gray-100 rounded-lg flex items-center justify-center text-xs font-black text-gray-500">
                              {item.quantity}
                            </span>
                            <div>
                              <span className="font-bold text-gray-900 text-sm">{item.name}</span>
                              {item.note && (
                                <span className="text-xs text-gray-400 ml-2">• {item.note}</span>
                              )}
                            </div>
                          </div>
                          <span className="text-xs font-bold text-gray-400">{item.price} TL</span>
                        </div>
                      ))}
                    </div>

                    {/* Footer */}
                    <div className="px-5 pb-5 flex items-center justify-between">
                      <span className="text-xs text-gray-400 font-medium">{totalQty} kalem • {total} TL</span>
                      {order.status !== 'ready' && (
                        <button
                          onClick={() => handleUpdateStatus(order.id, config.next, config.toastMsg)}
                          className="px-5 py-2 bg-gray-900 text-white text-xs font-bold rounded-xl hover:bg-gray-800 transition-all active:scale-95"
                        >
                          {config.next === 'preparing' ? 'Hazırlanıyor' : 'Hazır İşaretle'}
                        </button>
                      )}
                    </div>
                  </motion.div>
                );
              })}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}
