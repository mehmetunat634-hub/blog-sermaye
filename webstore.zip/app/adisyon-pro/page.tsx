'use client';

import { useAdisyon } from '@/lib/adisyon-pro/useAdisyon';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Users, ReceiptText, Clock, ArrowRight, Wallet, ShoppingBag } from 'lucide-react';
import Link from 'next/link';

export default function DashboardPage() {
  const { tables, billHistory, kitchenOrders, isLoaded } = useAdisyon();
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);

  if (!isLoaded) return <Loading />;

  const todayBills = billHistory.filter(b => b.closedAt?.startsWith(date));
  const totalRevenue = todayBills.reduce((s, b) => s + b.total, 0);
  const openTables = tables.filter(t => t.isOpen);
  const pendingKitchen = kitchenOrders.filter(o => o.status === 'pending');
  const totalOrders = todayBills.reduce((s, b) => s + b.items.reduce((s2, i) => s2 + i.quantity, 0), 0);

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Dashboard</h1>
          <p className="text-gray-500 font-medium">
            {new Date().toLocaleDateString('tr-TR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>
        <div className="flex items-center space-x-4">
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
          />
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          icon={<Wallet className="h-6 w-6 text-emerald-600" />}
          label="Bugünkü Ciro"
          value={`${totalRevenue} TL`}
          bg="bg-emerald-50"
          delay={0}
        />
        <StatCard
          icon={<Users className="h-6 w-6 text-blue-600" />}
          label="Açık Masalar"
          value={`${openTables.length} / ${tables.length}`}
          bg="bg-blue-50"
          delay={0.1}
        />
        <StatCard
          icon={<Clock className="h-6 w-6 text-amber-600" />}
          label="Bekleyen Sipariş"
          value={pendingKitchen.length.toString()}
          bg="bg-amber-50"
          delay={0.2}
        />
        <StatCard
          icon={<ShoppingBag className="h-6 w-6 text-purple-600" />}
          label="Toplam Sipariş"
          value={totalOrders.toString()}
          bg="bg-purple-50"
          delay={0.3}
        />
      </div>

      {/* Quick Actions + Recent */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Active Tables Quick View */}
        <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-gray-900">Aktif Masalar</h2>
            <Link href="/adisyon-pro/tables" className="text-sm font-bold text-blue-600 flex items-center hover:underline">
              Tümünü Gör <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
          <div className="space-y-3">
            {openTables.length === 0 ? (
              <p className="text-gray-400 font-medium text-sm py-8 text-center">Aktif masa yok</p>
            ) : (
              openTables.slice(0, 6).map(table => (
                <Link
                  key={table.id}
                  href={`/adisyon-pro/tables`}
                  className="flex items-center justify-between py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center text-blue-600 font-bold text-sm">
                      {table.id}
                    </div>
                    <div>
                      <div className="font-bold text-gray-900 text-sm">{table.name}</div>
                      <div className="text-xs text-gray-500">{table.orders.length} kalem</div>
                    </div>
                  </div>
                  <div className="font-black text-gray-900">
                    {table.orders.reduce((s, i) => s + i.price * i.quantity, 0)} TL
                  </div>
                </Link>
              ))
            )}
          </div>
        </div>

        {/* Recent Bills */}
        <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-bold text-gray-900">Son Hesaplar</h2>
            <Link href="/adisyon-pro/reports" className="text-sm font-bold text-blue-600 flex items-center hover:underline">
              Raporlar <ArrowRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
          <div className="space-y-3">
            {todayBills.length === 0 ? (
              <p className="text-gray-400 font-medium text-sm py-8 text-center">Bugün kapatılan hesap yok</p>
            ) : (
              todayBills.slice(0, 6).map(bill => (
                <div key={bill.id} className="flex items-center justify-between py-3 px-4 rounded-xl hover:bg-gray-50 transition-colors">
                  <div className="flex items-center space-x-3">
                    <ReceiptText className="h-5 w-5 text-gray-400" />
                    <div>
                      <div className="font-bold text-gray-900 text-sm">{bill.tableName}</div>
                      <div className="text-xs text-gray-500">
                        {new Date(bill.closedAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })} • {bill.items.reduce((s, i) => s + i.quantity, 0)} kalem
                      </div>
                    </div>
                  </div>
                  <span className="font-black text-gray-900">{bill.total} TL</span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Kitchen Status */}
      {pendingKitchen.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-[2rem] p-6 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-amber-200 rounded-2xl flex items-center justify-center text-amber-700 font-black text-lg animate-pulse">
              {pendingKitchen.length}
            </div>
            <div>
              <h3 className="font-bold text-amber-900">Mutfağa Bekleyen Sipariş</h3>
              <p className="text-sm text-amber-700 font-medium">Hazırlanmayı bekleyen {pendingKitchen.length} sipariş var</p>
            </div>
          </div>
          <Link
            href="/adisyon-pro/kitchen"
            className="px-6 py-3 bg-amber-600 text-white font-bold rounded-xl hover:bg-amber-700 transition-all text-sm"
          >
            Mutfağa Git
          </Link>
        </div>
      )}
    </div>
  );
}

function Loading() {
  return (
    <div className="p-20 flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto" />
        <p className="font-medium text-gray-500">Yükleniyor...</p>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, bg, delay }: { icon: React.ReactNode; label: string; value: string; bg: string; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className={`${bg} rounded-[2rem] p-6 flex items-center space-x-4`}
    >
      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm">
        {icon}
      </div>
      <div>
        <div className="text-2xl font-black text-gray-900">{value}</div>
        <div className="text-sm font-medium text-gray-500">{label}</div>
      </div>
    </motion.div>
  );
}
