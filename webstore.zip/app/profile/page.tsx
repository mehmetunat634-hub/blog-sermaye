'use client';

import { useAuth } from '@/lib/AuthContext';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { User, Wallet, Package, LogOut, ExternalLink, Plus, Mail, CheckCircle } from 'lucide-react';

interface Purchase {
  app_slug: string;
  amount: number;
  purchased_at: string;
  appName: string;
  appIcon: string;
}

export default function ProfilePage() {
  const { user, loading, logout } = useAuth();
  const router = useRouter();
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [addAmount, setAddAmount] = useState('');
  const [addEmail, setAddEmail] = useState('');
  const [addSuccess, setAddSuccess] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [purchasesLoading, setPurchasesLoading] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      router.push('/login');
    }
  }, [user, loading, router]);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (token) {
      fetch('/api/apps/purchases', {
        headers: { Authorization: `Bearer ${token}` }
      })
        .then(r => r.json())
        .then(d => setPurchases(d.purchases || []))
        .finally(() => setPurchasesLoading(false));
    }
  }, [user]);

  const handleAddBalance = async () => {
    const amount = parseInt(addAmount);
    if (isNaN(amount) || amount <= 0) return;
    const email = addEmail.trim() || user?.email || '';
    if (!email) return;
    setAdding(true);
    setAddSuccess(null);
    const token = localStorage.getItem('token');
    try {
      const res = await fetch('/api/balance/requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ amount, email })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setAddSuccess(data.email || email);
      setAddAmount('');
    } catch (err: any) {
      alert(err.message);
    } finally {
      setAdding(false);
    }
  };

  const handleLogout = () => {
    logout();
    router.push('/');
  };

  if (loading) return <div className="p-20 text-center font-medium text-gray-500">Yükleniyor...</div>;
  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 space-y-12">
      {/* User Info Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white border border-gray-200 rounded-[2.5rem] p-8 md:p-12 shadow-sm"
      >
        <div className="flex items-center space-x-6 mb-8">
          <div className="w-20 h-20 rounded-[2rem] bg-blue-600 flex items-center justify-center text-white text-3xl font-bold">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
            <p className="text-gray-500 font-medium">{user.email}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Balance */}
          <div className="p-6 rounded-[2rem] bg-gray-50 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold uppercase tracking-wider text-gray-500">Bakiye</span>
              <Wallet className="h-5 w-5 text-gray-400" />
            </div>
            <div className="text-4xl font-black text-gray-900 mb-4">{user.balance.toLocaleString('tr-TR')} TL</div>

            <div className="space-y-2">
              <div className="relative">
                <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="email"
                  value={addEmail}
                  onChange={e => setAddEmail(e.target.value)}
                  placeholder={user.email || 'E-posta adresi'}
                  className="w-full pl-10 pr-4 py-3 bg-white border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500"
                />
              </div>
              <div className="flex space-x-2">
                <input
                  type="number"
                  value={addAmount}
                  onChange={e => setAddAmount(e.target.value)}
                  placeholder="Tutar"
                  className="flex-grow px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500"
                />
                <button
                  onClick={handleAddBalance}
                  disabled={adding}
                  className="px-5 py-3 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 transition-all active:scale-95 flex items-center space-x-1 disabled:opacity-50"
                >
                  <Plus className="h-4 w-4" />
                  <span>Talep Gönder</span>
                </button>
              </div>
            </div>

            {addSuccess && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-3 p-3 bg-emerald-50 rounded-xl flex items-center space-x-2"
              >
                <CheckCircle className="h-4 w-4 text-emerald-600 flex-shrink-0" />
                <span className="text-sm font-medium text-emerald-700">
                  {addSuccess} adresine bakiye talebi alınmıştır. Admin onayından sonra bakiyenize yansıyacaktır.
                </span>
              </motion.div>
            )}
          </div>

          {/* Quick Stats */}
          <div className="p-6 rounded-[2rem] bg-gray-50 flex flex-col justify-between">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-bold uppercase tracking-wider text-gray-500">İstatistik</span>
              <Package className="h-5 w-5 text-gray-400" />
            </div>
            <div className="text-4xl font-black text-gray-900 mb-1">{purchases.length}</div>
            <div className="text-sm font-medium text-gray-500">Satın alınan uygulama</div>
          </div>
        </div>
      </motion.div>

      {/* Purchased Apps */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <h2 className="text-2xl font-bold text-gray-900 tracking-tight mb-6">Satın Alınan Uygulamalar</h2>

        {purchasesLoading ? (
          <p className="text-gray-500 font-medium">Yükleniyor...</p>
        ) : purchases.length === 0 ? (
          <div className="bg-gray-50 rounded-[2rem] p-12 text-center">
            <Package className="h-12 w-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 font-medium">Henüz bir uygulama satın almadınız.</p>
            <Link href="/" className="inline-block mt-4 px-6 py-3 bg-blue-600 text-white font-bold rounded-xl text-sm hover:bg-blue-700 transition-all">
              Mağazayı Keşfet
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {purchases.map((p, i) => (
              <div key={i} className="bg-white border border-gray-200 rounded-[2rem] p-6 flex items-center justify-between hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-4">
                  <div className="w-14 h-14 rounded-2xl bg-gray-100 flex items-center justify-center text-3xl shadow-sm">
                    {p.appIcon}
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{p.appName}</h3>
                    <p className="text-sm text-gray-500">{p.amount} TL • {new Date(p.purchased_at).toLocaleDateString('tr-TR')}</p>
                  </div>
                </div>
                <Link href={`/${p.app_slug}`} className="p-3 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all">
                  <ExternalLink className="h-5 w-5" />
                </Link>
              </div>
            ))}
          </div>
        )}
      </motion.div>

      {/* Logout */}
      <div className="text-center">
        <button
          onClick={handleLogout}
          className="inline-flex items-center space-x-2 px-8 py-4 bg-gray-900 text-white font-bold rounded-2xl hover:bg-gray-800 transition-all active:scale-95"
        >
          <LogOut className="h-5 w-5" />
          <span>Çıkış Yap</span>
        </button>
      </div>
    </div>
  );
}
