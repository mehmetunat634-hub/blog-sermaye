'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ILAN_KATEGORILERI, URUN_DURUMLARI } from '@/lib/golet/constants';
import { ArrowLeft, Calculator, Sparkles, Megaphone } from 'lucide-react';

export default function PriceEstimate() {
  const [category, setCategory] = useState('');
  const [condition, setCondition] = useState('');
  const [age, setAge] = useState('');
  const [result, setResult] = useState<{ min: number; max: number; avg: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleEstimate = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/golet/price-estimate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ category, condition, age: age ? Number(age) : undefined }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setResult(data.estimate);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatPrice = (p: number) => p.toLocaleString() + ' TL';

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <Link href="/golet" className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors">
            <ArrowLeft className="h-5 w-5" />
            <span className="font-medium text-sm">Geri</span>
          </Link>
          <Link href="/golet" className="flex items-center space-x-2">
            <div className="w-7 h-7 bg-gradient-to-br from-orange-500 to-pink-500 rounded-lg flex items-center justify-center text-white">
              <Megaphone className="h-4 w-4" />
            </div>
            <span className="font-bold text-gray-900 text-sm">GoLet</span>
          </Link>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-50 to-pink-50 rounded-2xl flex items-center justify-center">
              <Calculator className="h-6 w-6 text-orange-600" />
            </div>
            <div>
              <h1 className="text-2xl font-black text-gray-900">Fiyat Tahmincisi</h1>
              <p className="text-sm text-gray-500 font-medium">Ürününüzün tahmini piyasa değerini öğrenin</p>
            </div>
          </div>

          <form onSubmit={handleEstimate} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-900 mb-2">Kategori</label>
              <select value={category} onChange={e => setCategory(e.target.value)} required
                className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500">
                <option value="">Seçiniz</option>
                {ILAN_KATEGORILERI.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-900 mb-2">Ürün Durumu</label>
              <select value={condition} onChange={e => setCondition(e.target.value)} required
                className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500">
                <option value="">Seçiniz</option>
                {URUN_DURUMLARI.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-900 mb-2">Ürün Yaşı (yıl, opsiyonel)</label>
              <input type="number" min="0" max="100" value={age} onChange={e => setAge(e.target.value)}
                placeholder="Örn: 3"
                className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
            </div>

            {error && <div className="p-4 bg-red-50 text-red-600 rounded-2xl text-sm font-medium">{error}</div>}

            <button type="submit" disabled={loading || !category || !condition}
              className="w-full py-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-2xl hover:from-orange-600 hover:to-pink-600 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/20">
              {loading ? (
                <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /><span>Hesaplanıyor...</span></>
              ) : (
                <><Sparkles className="h-5 w-5" /><span>Tahmin Et</span></>
              )}
            </button>
          </form>

          {result && (
            <div className="mt-8 p-6 bg-gradient-to-br from-orange-50 to-pink-50 rounded-3xl border border-orange-100 space-y-4">
              <h3 className="font-bold text-gray-900 flex items-center space-x-2">
                <Sparkles className="h-5 w-5 text-orange-500" />
                <span>Tahmini Fiyat Aralığı</span>
              </h3>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-white rounded-2xl p-4 text-center">
                  <p className="text-xs text-gray-500 font-medium mb-1">En Düşük</p>
                  <p className="text-lg font-black text-gray-900">{formatPrice(result.min)}</p>
                </div>
                <div className="bg-white rounded-2xl p-4 text-center ring-2 ring-orange-500">
                  <p className="text-xs text-orange-600 font-medium mb-1">Ortalama</p>
                  <p className="text-lg font-black text-orange-600">{formatPrice(result.avg)}</p>
                </div>
                <div className="bg-white rounded-2xl p-4 text-center">
                  <p className="text-xs text-gray-500 font-medium mb-1">En Yüksek</p>
                  <p className="text-lg font-black text-gray-900">{formatPrice(result.max)}</p>
                </div>
              </div>
              <p className="text-xs text-gray-400 text-center">Bu tahmin piyasa verilerine dayanmaktadır, kesin değildir.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
