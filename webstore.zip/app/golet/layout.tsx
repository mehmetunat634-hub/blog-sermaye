import { ToastProvider } from '@/components/Toast';

export default function GoletLayout({ children }: { children: React.ReactNode }) {
  return (
    <ToastProvider>
      {children}
    </ToastProvider>
  );
}
