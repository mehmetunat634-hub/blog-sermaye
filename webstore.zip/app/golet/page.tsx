'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { useGolet } from '@/lib/golet/useGolet';
import { ILAN_KATEGORILERI } from '@/lib/golet/constants';
import { Search, MapPin, MessageCircle, ChevronRight, Megaphone } from 'lucide-react';

export default function GoletHome() {
  const { publicListings, loadPublicListings } = useGolet();
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('Tümü');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPublicListings().then(() => setLoading(false));
  }, []);

  const filtered = publicListings.filter(l => {
    if (activeCategory !== 'Tümü' && l.category !== activeCategory) return false;
    if (search && !l.title.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const formatPrice = (p: number) => p.toLocaleString() + ' TL';

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Bar */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between gap-4">
            <Link href="/golet" className="flex items-center space-x-2 flex-shrink-0">
              <div className="w-9 h-9 bg-gradient-to-br from-orange-500 to-pink-500 rounded-xl flex items-center justify-center text-white shadow-md">
                <Megaphone className="h-5 w-5" />
              </div>
              <span className="text-xl font-black text-gray-900 hidden sm:inline">GoLet</span>
            </Link>

            <div className="relative flex-grow max-w-xl">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="İlanlarda ara..."
                className="w-full pl-12 pr-4 py-3 bg-gray-100 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 transition-all"
              />
            </div>

            <Link href="/golet/panel"
              className="flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:from-orange-600 hover:to-pink-600 transition-all text-sm shadow-md shadow-orange-500/20">
              <span>Panel</span>
              <ChevronRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <div className="flex space-x-2 overflow-x-auto scrollbar-hide pb-2">
            {['Tümü', ...ILAN_KATEGORILERI].map(cat => (
              <button key={cat} onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2 rounded-full whitespace-nowrap text-sm font-bold transition-all flex-shrink-0 ${
                  activeCategory === cat ? 'bg-orange-500 text-white shadow-md' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}>
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Listing Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-10 h-10 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20 space-y-4">
            <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto">
              <Search className="h-10 w-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">İlan bulunamadı</h3>
            <p className="text-gray-500 font-medium">Henüz bu kategoride ilan bulunmuyor.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 sm:gap-6">
            {filtered.map(listing => (
              <Link key={listing.id} href={`/golet/ilan/${listing.id}`}
                className="group bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-lg hover:-translate-y-1 transition-all">
                <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center text-4xl overflow-hidden">
                  {listing.photos?.[0] ? (
                    <img src={listing.photos[0]} alt={listing.title} className="w-full h-full object-cover" />
                  ) : (
                    <Megaphone className="text-gray-300 h-12 w-12" />
                  )}
                </div>
                <div className="p-3 sm:p-4 space-y-2">
                  <h3 className="font-bold text-gray-900 text-sm leading-tight line-clamp-2">{listing.title}</h3>
                  <p className="text-lg font-black text-orange-600">{formatPrice(listing.price)}</p>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span className="flex items-center space-x-1">
                      <MapPin className="h-3 w-3" />
                      <span>{listing.location || 'Belirtilmemiş'}</span>
                    </span>
                    {listing.condition === 'sifir' && (
                      <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full font-bold text-[10px]">Sıfır</span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
