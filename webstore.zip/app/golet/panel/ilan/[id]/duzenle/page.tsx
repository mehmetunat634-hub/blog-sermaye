'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useGolet } from '@/lib/golet/useGolet';
import { ILAN_KATEGORILERI, URUN_DURUMLARI } from '@/lib/golet/constants';
import { useToast } from '@/components/Toast';
import { ArrowLeft, Plus, X, Image, Save, Megaphone } from 'lucide-react';
import type { GoletListing } from '@/lib/golet/types';

export default function EditListing() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { updateListing } = useGolet();
  const toast = useToast();

  const [form, setForm] = useState({
    title: '',
    description: '',
    price: '',
    category: '',
    condition: 'ikinci-el',
    location: '',
    phone: '',
    whatsapp: '',
  });
  const [photos, setPhotos] = useState<string[]>(['']);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetch(`/api/golet/listings/${id}`)
      .then(r => r.json())
      .then(data => {
        const l = data.listing as GoletListing;
        if (l) {
          setForm({
            title: l.title,
            description: l.description || '',
            price: String(l.price),
            category: l.category,
            condition: l.condition,
            location: l.location || '',
            phone: l.phone || '',
            whatsapp: l.whatsapp || '',
          });
          setPhotos(l.photos?.length ? l.photos : ['']);
        }
      })
      .catch(() => toast.show('İlan bulunamadı', 'error'))
      .finally(() => setLoading(false));
  }, [id]);

  const addPhotoField = () => setPhotos(p => [...p, '']);
  const removePhotoField = (i: number) => setPhotos(p => p.filter((_, idx) => idx !== i));
  const updatePhoto = (i: number, val: string) => setPhotos(p => p.map((v, idx) => idx === i ? val : v));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.price || !form.category) {
      toast.show('Lütfen gerekli alanları doldurun', 'error');
      return;
    }
    setSubmitting(true);
    try {
      await updateListing(Number(id), {
        ...form,
        price: Number(form.price),
        photos: photos.filter(Boolean),
      });
      toast.show('İlan güncellendi!', 'success');
      router.push('/golet/panel');
    } catch (err: any) {
      toast.show(err.message, 'error');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="p-6 max-w-2xl mx-auto flex items-center justify-center py-20">
        <div className="w-10 h-10 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-6">
        <Link href="/golet/panel" className="inline-flex items-center space-x-2 text-sm text-gray-500 hover:text-gray-900 transition-colors mb-4">
          <ArrowLeft className="h-4 w-4" />
          <span>Panele Dön</span>
        </Link>
        <h1 className="text-2xl font-black text-gray-900">İlanı Düzenle</h1>
        <p className="text-sm text-gray-500 font-medium">#{id} nolu ilanı düzenleyin</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-gray-100 space-y-6">
        <div>
          <label className="block text-sm font-bold text-gray-900 mb-2">Başlık *</label>
          <input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))}
            className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-bold text-gray-900 mb-2">Kategori *</label>
            <select value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}
              className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500">
              {ILAN_KATEGORILERI.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-900 mb-2">Durum *</label>
            <select value={form.condition} onChange={e => setForm(p => ({ ...p, condition: e.target.value }))}
              className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500">
              {URUN_DURUMLARI.map(d => <option key={d.value} value={d.value}>{d.label}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-900 mb-2">Fiyat (TL) *</label>
          <input type="number" min="0" value={form.price} onChange={e => setForm(p => ({ ...p, price: e.target.value }))}
            className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-900 mb-2">Açıklama</label>
          <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} rows={4}
            className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 resize-none" />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-bold text-gray-900 mb-2">Konum</label>
            <input value={form.location} onChange={e => setForm(p => ({ ...p, location: e.target.value }))}
              className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-900 mb-2">Telefon</label>
            <input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))}
              className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-900 mb-2">WhatsApp</label>
          <input value={form.whatsapp} onChange={e => setForm(p => ({ ...p, whatsapp: e.target.value }))}
            className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-900 mb-2">Fotoğraflar (URL)</label>
          <div className="space-y-3">
            {photos.map((url, i) => (
              <div key={i} className="flex items-center space-x-2">
                <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {url ? <img src={url} alt="" className="w-full h-full object-cover" /> : <Image className="h-5 w-5 text-gray-400" />}
                </div>
                <input value={url} onChange={e => updatePhoto(i, e.target.value)}
                  placeholder={`Fotoğraf URL ${i + 1}`}
                  className="flex-grow px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
                {photos.length > 1 && (
                  <button type="button" onClick={() => removePhotoField(i)}
                    className="p-2 text-gray-400 hover:text-red-500 transition-colors">
                    <X className="h-4 w-4" />
                  </button>
                )}
              </div>
            ))}
            <button type="button" onClick={addPhotoField}
              className="flex items-center space-x-2 text-sm text-orange-600 font-bold hover:text-orange-700 transition-colors">
              <Plus className="h-4 w-4" />
              <span>Fotoğraf Ekle</span>
            </button>
          </div>
        </div>

        <button type="submit" disabled={submitting}
          className="w-full py-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-2xl hover:from-orange-600 hover:to-pink-600 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/20">
          {submitting ? (
            <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /><span>Kaydediliyor...</span></>
          ) : (
            <><Save className="h-5 w-5" /><span>Değişiklikleri Kaydet</span></>
          )}
        </button>
      </form>
    </div>
  );
}
