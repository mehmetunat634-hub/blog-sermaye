import AppGuard from '@/components/AppGuard';
import GoletPurchaseGuard from '@/components/apps/golet/GoletPurchaseGuard';
import GoletSidebar from '@/components/apps/golet/Sidebar';

export default function GoletPanelLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppGuard>
      <GoletPurchaseGuard>
        <div className="flex min-h-[calc(100vh-4rem)]">
          <GoletSidebar />
          <main className="flex-grow bg-gray-50 overflow-auto">
            {children}
          </main>
        </div>
      </GoletPurchaseGuard>
    </AppGuard>
  );
}
