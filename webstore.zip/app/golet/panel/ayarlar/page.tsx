'use client';

import { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/Toast';
import { Shield, Save, User, Phone } from 'lucide-react';

export default function GoletSettings() {
  const { user } = useAuth();
  const toast = useToast();
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [saving, setSaving] = useState(false);

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!password || !newPassword) {
      toast.show('Lütfen tüm alanları doldurun', 'error');
      return;
    }
    setSaving(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/auth/verify-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ password }),
      });
      if (!res.ok) throw new Error('Mevcut şifre yanlış');

      const regRes = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ password: newPassword }),
      });
      if (!regRes.ok) throw new Error('Şifre değiştirilemedi');

      toast.show('Şifre değiştirildi', 'success');
      setPassword('');
      setNewPassword('');
    } catch (err: any) {
      toast.show(err.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-black text-gray-900">Ayarlar</h1>
        <p className="text-sm text-gray-500 font-medium">Hesap ve uygulama ayarlarınızı yönetin</p>
      </div>

      {/* Profile Info */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-gray-100 mb-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-blue-50 rounded-2xl flex items-center justify-center">
            <User className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Profil Bilgileri</h3>
            <p className="text-xs text-gray-500">Hesap detaylarınız</p>
          </div>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between py-3 border-b border-gray-50">
            <span className="text-sm text-gray-500">Ad</span>
            <span className="text-sm font-bold text-gray-900">{user?.name}</span>
          </div>
          <div className="flex items-center justify-between py-3 border-b border-gray-50">
            <span className="text-sm text-gray-500">E-posta</span>
            <span className="text-sm font-bold text-gray-900">{user?.email}</span>
          </div>
          <div className="flex items-center justify-between py-3">
            <span className="text-sm text-gray-500">Bakiye</span>
            <span className="text-sm font-bold text-gray-900">{user?.balance.toLocaleString()} TL</span>
          </div>
        </div>
      </div>

      {/* Password Change */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-gray-100">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-orange-50 rounded-2xl flex items-center justify-center">
            <Shield className="h-5 w-5 text-orange-600" />
          </div>
          <div>
            <h3 className="font-bold text-gray-900">Şifre Değiştir</h3>
            <p className="text-xs text-gray-500">Uygulama şifrenizi güncelleyin</p>
          </div>
        </div>
        <form onSubmit={handleChangePassword} className="space-y-4">
          <div>
            <label className="block text-sm font-bold text-gray-900 mb-2">Mevcut Şifre</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)}
              className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-900 mb-2">Yeni Şifre</label>
            <input type="password" value={newPassword} onChange={e => setNewPassword(e.target.value)}
              className="w-full px-4 py-3.5 bg-gray-50 border border-gray-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
          </div>
          <button type="submit" disabled={saving || !password || !newPassword}
            className="w-full py-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-2xl hover:from-orange-600 hover:to-pink-600 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/20">
            {saving ? (
              <><div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /><span>Kaydediliyor...</span></>
            ) : (
              <><Save className="h-5 w-5" /><span>Şifreyi Değiştir</span></>
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
