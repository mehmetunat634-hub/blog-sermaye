'use client';

import { useGolet } from '@/lib/golet/useGolet';
import { ILAN_DURUMLARI } from '@/lib/golet/constants';
import Link from 'next/link';
import { PlusCircle, Pencil, Trash2, ExternalLink, Megaphone, BarChart3, Eye, MessageCircle } from 'lucide-react';
import { useState } from 'react';
import { useToast } from '@/components/Toast';

export default function GoletPanel() {
  const { listings, inquiries, deleteListing, updateListingStatus } = useGolet();
  const toast = useToast();
  const [deleting, setDeleting] = useState<number | null>(null);

  const handleDelete = async (id: number) => {
    if (!confirm('Bu ilanı silmek istediğinize emin misiniz?')) return;
    setDeleting(id);
    try {
      await deleteListing(id);
      toast.show('İlan silindi', 'success');
    } catch (err: any) {
      toast.show(err.message, 'error');
    } finally {
      setDeleting(null);
    }
  };

  const handleStatus = async (id: number, status: string) => {
    try {
      await updateListingStatus(id, status);
      toast.show('Durum güncellendi', 'success');
    } catch (err: any) {
      toast.show(err.message, 'error');
    }
  };

  const formatPrice = (p: number) => p.toLocaleString() + ' TL';

  // Summary cards
  const activeCount = listings.filter(l => l.status === 'active').length;
  const soldCount = listings.filter(l => l.status === 'sold').length;
  const totalViews = listings.reduce((s, l) => s + (l.views || 0), 0);
  const totalInquiries = inquiries.length;

  const stats = [
    { label: 'Toplam İlan', value: listings.length, icon: Megaphone, color: 'text-blue-600 bg-blue-50' },
    { label: 'Aktif', value: activeCount, icon: Eye, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'Satıldı', value: soldCount, icon: BarChart3, color: 'text-purple-600 bg-purple-50' },
    { label: 'Mesaj', value: totalInquiries, icon: MessageCircle, color: 'text-orange-600 bg-orange-50' },
  ];

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-black text-gray-900">İlanlarım</h1>
          <p className="text-sm text-gray-500 font-medium">İlanlarınızı yönetin, durumlarını güncelleyin</p>
        </div>
        <Link href="/golet/panel/ilan-ekle"
          className="flex items-center space-x-2 px-5 py-2.5 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:from-orange-600 hover:to-pink-600 transition-all active:scale-[0.98] shadow-md shadow-orange-500/20 text-sm">
          <PlusCircle className="h-5 w-5" />
          <span>Yeni İlan</span>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(s => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center mb-3 ${s.color}`}>
                <Icon className="h-5 w-5" />
              </div>
              <p className="text-2xl font-black text-gray-900">{s.value}</p>
              <p className="text-xs text-gray-500 font-medium">{s.label}</p>
            </div>
          );
        })}
      </div>

      {/* Listing Table */}
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
        {listings.length === 0 ? (
          <div className="text-center py-16 space-y-4">
            <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto">
              <Megaphone className="h-10 w-10 text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-gray-900">Henüz ilanınız yok</h3>
            <p className="text-gray-500 font-medium text-sm">İlk ilanınızı oluşturarak satışa başlayın.</p>
            <Link href="/golet/panel/ilan-ekle"
              className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:from-orange-600 hover:to-pink-600 transition-all text-sm">
              <PlusCircle className="h-5 w-5" />
              <span>İlan Oluştur</span>
            </Link>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100">
                  <th className="text-left px-5 py-4 font-bold text-gray-900">İlan</th>
                  <th className="text-left px-5 py-4 font-bold text-gray-900 hidden sm:table-cell">Kategori</th>
                  <th className="text-right px-5 py-4 font-bold text-gray-900">Fiyat</th>
                  <th className="text-center px-5 py-4 font-bold text-gray-900 hidden md:table-cell">Durum</th>
                  <th className="text-center px-5 py-4 font-bold text-gray-900 hidden md:table-cell">Gör.</th>
                  <th className="text-right px-5 py-4 font-bold text-gray-900">İşlem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {listings.map(listing => {
                  const statusInfo = ILAN_DURUMLARI.find(d => d.value === listing.status);
                  return (
                    <tr key={listing.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-5 py-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center flex-shrink-0 overflow-hidden">
                            {listing.photos?.[0] ? (
                              <img src={listing.photos[0]} alt="" className="w-full h-full object-cover" />
                            ) : (
                              <Megaphone className="h-5 w-5 text-gray-400" />
                            )}
                          </div>
                          <div>
                            <p className="font-bold text-gray-900 truncate max-w-[200px]">{listing.title}</p>
                            <p className="text-xs text-gray-400">#{listing.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-4 text-gray-500 hidden sm:table-cell">{listing.category}</td>
                      <td className="px-5 py-4 text-right font-bold text-gray-900">{formatPrice(listing.price)}</td>
                      <td className="px-5 py-4 text-center hidden md:table-cell">
                        <select value={listing.status} onChange={e => handleStatus(listing.id, e.target.value)}
                          className={`px-3 py-1.5 rounded-full text-xs font-bold border-none cursor-pointer ${
                            statusInfo?.color || 'bg-gray-100 text-gray-500'
                          }`}>
                          {ILAN_DURUMLARI.map(d => (
                            <option key={d.value} value={d.value}>{d.label}</option>
                          ))}
                        </select>
                      </td>
                      <td className="px-5 py-4 text-center text-gray-500 hidden md:table-cell">{listing.views}</td>
                      <td className="px-5 py-4">
                        <div className="flex items-center justify-end space-x-2">
                          <Link href={`/golet/ilan/${listing.id}`} target="_blank"
                            className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all">
                            <ExternalLink className="h-4 w-4" />
                          </Link>
                          <Link href={`/golet/panel/ilan/${listing.id}/duzenle`}
                            className="p-2 text-gray-400 hover:text-orange-600 hover:bg-orange-50 rounded-xl transition-all">
                            <Pencil className="h-4 w-4" />
                          </Link>
                          <button onClick={() => handleDelete(listing.id)} disabled={deleting === listing.id}
                            className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all disabled:opacity-50">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Inquiries Section */}
      {inquiries.length > 0 && (
        <div className="mt-8">
          <h2 className="text-lg font-black text-gray-900 mb-4">Gelen Mesajlar</h2>
          <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left px-5 py-4 font-bold text-gray-900">Alıcı</th>
                    <th className="text-left px-5 py-4 font-bold text-gray-900 hidden sm:table-cell">İlan</th>
                    <th className="text-left px-5 py-4 font-bold text-gray-900 hidden md:table-cell">Mesaj</th>
                    <th className="text-center px-5 py-4 font-bold text-gray-900">Durum</th>
                    <th className="text-right px-5 py-4 font-bold text-gray-900">Tarih</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {inquiries.map(inq => (
                    <tr key={inq.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-5 py-4">
                        <p className="font-bold text-gray-900">{inq.buyerName}</p>
                        <p className="text-xs text-gray-400">{inq.buyerPhone}</p>
                      </td>
                      <td className="px-5 py-4 text-gray-500 hidden sm:table-cell text-xs max-w-[150px] truncate">
                        {inq.listingTitle || `#${inq.listingId}`}
                      </td>
                      <td className="px-5 py-4 text-gray-500 hidden md:table-cell text-xs max-w-[200px] truncate">
                        {inq.buyerMessage || '-'}
                      </td>
                      <td className="px-5 py-4 text-center">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          inq.status === 'new' ? 'bg-amber-100 text-amber-700' :
                          inq.status === 'contacted' ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-500'
                        }`}>
                          {inq.status === 'new' ? 'Yeni' : inq.status === 'contacted' ? 'İletişime Geçildi' : 'Kapandı'}
                        </span>
                      </td>
                      <td className="px-5 py-4 text-right text-xs text-gray-400">
                        {new Date(inq.createdAt).toLocaleDateString('tr-TR')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
