'use client';

import { useGolet } from '@/lib/golet/useGolet';
import { Megaphone, Eye, MessageCircle, ShoppingBag } from 'lucide-react';
import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
} from 'recharts';

const COLORS = ['#f97316', '#ec4899', '#8b5cf6', '#06b6d4', '#22c55e', '#eab308', '#ef4444'];

export default function GoletStats() {
  const { listings, inquiries, stats } = useGolet();

  const activeCount = listings.filter(l => l.status === 'active').length;
  const soldCount = listings.filter(l => l.status === 'sold').length;
  const totalViews = listings.reduce((s, l) => s + (l.views || 0), 0);

  const statusData = [
    { name: 'Aktif', value: activeCount, color: '#22c55e' },
    { name: 'Satıldı', value: soldCount, color: '#3b82f6' },
    { name: 'Süresi Doldu', value: listings.length - activeCount - soldCount, color: '#9ca3af' },
  ].filter(d => d.value > 0);

  const catCount = listings.reduce<Record<string, number>>((acc, l) => {
    acc[l.category] = (acc[l.category] || 0) + 1;
    return acc;
  }, {});
  const categoryData = Object.entries(catCount)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  const cards = [
    { label: 'Toplam İlan', value: listings.length, icon: Megaphone, color: 'text-blue-600 bg-blue-50' },
    { label: 'Aktif İlan', value: activeCount, icon: Eye, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'Satılan', value: soldCount, icon: ShoppingBag, color: 'text-purple-600 bg-purple-50' },
    { label: 'Toplam Görüntülenme', value: totalViews, icon: Eye, color: 'text-orange-600 bg-orange-50' },
    { label: 'Gelen Mesaj', value: inquiries.length, icon: MessageCircle, color: 'text-pink-600 bg-pink-50' },
  ];

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="mb-8">
        <h1 className="text-2xl font-black text-gray-900">İstatistikler</h1>
        <p className="text-sm text-gray-500 font-medium">İlanlarınızın performansını görün</p>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        {cards.map(c => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
              <div className={`w-10 h-10 rounded-2xl flex items-center justify-center mb-3 ${c.color}`}>
                <Icon className="h-5 w-5" />
              </div>
              <p className="text-2xl font-black text-gray-900">{c.value}</p>
              <p className="text-xs text-gray-500 font-medium">{c.label}</p>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Status Distribution */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-6">Durum Dağılımı</h3>
          {statusData.length > 0 ? (
            <div className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={({ name, percent }: any) => `${name} %${((percent ?? 0) * 100).toFixed(0)}`}>
                    {statusData.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <p className="text-center text-gray-400 py-10">Henüz veri yok</p>
          )}
        </div>

        {/* Category Distribution */}
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-900 mb-6">Kategori Dağılımı</h3>
          {categoryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={categoryData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                  {categoryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-center text-gray-400 py-10">Henüz veri yok</p>
          )}
        </div>
      </div>
    </div>
  );
}
