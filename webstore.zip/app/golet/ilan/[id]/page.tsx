'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/Toast';
import { useGolet } from '@/lib/golet/useGolet';
import { ILAN_KATEGORILERI, URUN_DURUMLARI } from '@/lib/golet/constants';
import { ArrowLeft, MapPin, Phone, MessageCircle, Send, ChevronLeft, ChevronRight, Megaphone } from 'lucide-react';
import type { GoletListing } from '@/lib/golet/types';

export default function GoletListingDetail() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();
  const toast = useToast();
  const { submitInquiry } = useGolet();

  const [listing, setListing] = useState<GoletListing | null>(null);
  const [loading, setLoading] = useState(true);
  const [photoIndex, setPhotoIndex] = useState(0);
  const [showContact, setShowContact] = useState(false);
  const [contactForm, setContactForm] = useState({ buyerName: '', buyerPhone: '', buyerMessage: '' });
  const [sending, setSending] = useState(false);

  useEffect(() => {
    fetch(`/api/golet/listings/${id}`)
      .then(r => r.json())
      .then(data => setListing(data.listing ?? null))
      .catch(() => setListing(null))
      .finally(() => setLoading(false));
  }, [id]);

  const handleContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.show('İletişim bilgisi görmek için giriş yapmalısınız', 'error');
      router.push('/login');
      return;
    }
    setSending(true);
    try {
      await submitInquiry(Number(id), contactForm);
      toast.show('Mesajınız iletildi! Satıcı sizinle iletişime geçecek.', 'success');
      setContactForm({ buyerName: '', buyerPhone: '', buyerMessage: '' });
      setShowContact(false);
    } catch (err: any) {
      toast.show(err.message, 'error');
    } finally {
      setSending(false);
    }
  };

  const formatPrice = (p: number) => p.toLocaleString() + ' TL';
  const photos = listing?.photos?.length ? listing.photos : [];
  const conditionLabel = URUN_DURUMLARI.find(d => d.value === listing?.condition)?.label || listing?.condition;

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-orange-500/30 border-t-orange-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-20 h-20 bg-gray-100 rounded-3xl flex items-center justify-center mx-auto">
            <Megaphone className="h-10 w-10 text-gray-400" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">İlan bulunamadı</h2>
          <Link href="/golet" className="text-orange-600 font-bold hover:underline">İlanlara dön</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Nav */}
      <div className="bg-white border-b border-gray-200 sticky top-16 z-30">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-14 flex items-center justify-between">
          <button onClick={() => router.back()} className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors">
            <ArrowLeft className="h-5 w-5" />
            <span className="font-medium text-sm">Geri</span>
          </button>
          <Link href="/golet" className="flex items-center space-x-2">
            <div className="w-7 h-7 bg-gradient-to-br from-orange-500 to-pink-500 rounded-lg flex items-center justify-center text-white">
              <Megaphone className="h-4 w-4" />
            </div>
            <span className="font-bold text-gray-900 text-sm">GoLet</span>
          </Link>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
          {/* Left - Photos */}
          <div className="lg:col-span-3 space-y-4">
            <div className="relative aspect-square bg-white rounded-3xl overflow-hidden shadow-sm border border-gray-100 flex items-center justify-center">
              {photos.length > 0 ? (
                <>
                  <img src={photos[photoIndex]} alt={listing.title} className="w-full h-full object-cover" />
                  {photos.length > 1 && (
                    <>
                      <button onClick={() => setPhotoIndex(i => Math.max(0, i - 1))}
                        className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-lg hover:bg-white transition-all disabled:opacity-30"
                        disabled={photoIndex === 0}>
                        <ChevronLeft className="h-5 w-5 text-gray-700" />
                      </button>
                      <button onClick={() => setPhotoIndex(i => Math.min(photos.length - 1, i + 1))}
                        className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-lg hover:bg-white transition-all disabled:opacity-30"
                        disabled={photoIndex === photos.length - 1}>
                        <ChevronRight className="h-5 w-5 text-gray-700" />
                      </button>
                    </>
                  )}
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex space-x-2">
                    {photos.map((_, i) => (
                      <button key={i} onClick={() => setPhotoIndex(i)}
                        className={`w-2.5 h-2.5 rounded-full transition-all ${i === photoIndex ? 'bg-white w-6' : 'bg-white/50'}`} />
                    ))}
                  </div>
                </>
              ) : (
                <Megaphone className="h-20 w-20 text-gray-300" />
              )}
            </div>

            {photos.length > 1 && (
              <div className="flex space-x-3 overflow-x-auto pb-2">
                {photos.map((photo, i) => (
                  <button key={i} onClick={() => setPhotoIndex(i)}
                    className={`w-20 h-20 rounded-2xl overflow-hidden flex-shrink-0 border-2 transition-all ${
                      i === photoIndex ? 'border-orange-500 shadow-md' : 'border-transparent opacity-70 hover:opacity-100'
                    }`}>
                    <img src={photo} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right - Details */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 space-y-5">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                    listing.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-gray-100 text-gray-500'
                  }`}>
                    {listing.status === 'active' ? 'Aktif' : listing.status === 'sold' ? 'Satıldı' : 'Süresi Doldu'}
                  </span>
                  {conditionLabel && (
                    <span className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-bold">{conditionLabel}</span>
                  )}
                </div>
                <h1 className="text-2xl font-black text-gray-900">{listing.title}</h1>
                <p className="text-3xl font-black text-orange-600">{formatPrice(listing.price)}</p>
              </div>

              <div className="flex items-center space-x-2 text-sm text-gray-500">
                <MapPin className="h-4 w-4" />
                <span>{listing.location || 'Konum belirtilmemiş'}</span>
              </div>

              <div className="border-t border-gray-100 pt-5 space-y-3">
                <h3 className="font-bold text-gray-900">Açıklama</h3>
                <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">{listing.description || 'Açıklama eklenmemiş.'}</p>
              </div>

              <div className="border-t border-gray-100 pt-5 space-y-3">
                <h3 className="font-bold text-gray-900">Kategori</h3>
                <p className="text-sm text-gray-600">{listing.category}</p>
              </div>

              <div className="text-xs text-gray-400">
                İlan no: #{listing.id} &middot; {new Date(listing.createdAt).toLocaleDateString('tr-TR')} tarihinde yayınlandı &middot; {listing.views} görüntülenme
              </div>
            </div>

            {/* Contact Section */}
            <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 space-y-4">
              {!showContact ? (
                <button onClick={() => {
                  if (!user) {
                    toast.show('İletişime geçmek için giriş yapmalısınız', 'error');
                    router.push('/login');
                    return;
                  }
                  setShowContact(true);
                }}
                  className="w-full py-4 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-2xl hover:from-orange-600 hover:to-pink-600 transition-all active:scale-[0.98] flex items-center justify-center space-x-2 shadow-lg shadow-orange-500/20">
                  <MessageCircle className="h-5 w-5" />
                  <span>Satıcıya Mesaj Gönder</span>
                </button>
              ) : (
                <form onSubmit={handleContact} className="space-y-4">
                  <h3 className="font-bold text-gray-900">Satıcıya Mesaj Gönder</h3>
                  <input value={contactForm.buyerName} onChange={e => setContactForm(p => ({ ...p, buyerName: e.target.value }))}
                    placeholder="Adınız" required
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
                  <input value={contactForm.buyerPhone} onChange={e => setContactForm(p => ({ ...p, buyerPhone: e.target.value }))}
                    placeholder="Telefon numaranız" required
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500" />
                  <textarea value={contactForm.buyerMessage} onChange={e => setContactForm(p => ({ ...p, buyerMessage: e.target.value }))}
                    placeholder="Mesajınız" rows={3}
                    className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-4 focus:ring-orange-500/10 focus:border-orange-500 resize-none" />
                  <div className="flex space-x-3">
                    <button type="button" onClick={() => setShowContact(false)}
                      className="px-6 py-3 bg-gray-100 text-gray-600 font-bold rounded-xl hover:bg-gray-200 transition-all text-sm">
                      İptal
                    </button>
                    <button type="submit" disabled={sending || !contactForm.buyerName || !contactForm.buyerPhone}
                      className="flex-grow py-3 bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold rounded-xl hover:from-orange-600 hover:to-pink-600 transition-all active:scale-[0.98] disabled:opacity-50 flex items-center justify-center space-x-2 text-sm">
                      {sending ? 'Gönderiliyor...' : <><Send className="h-4 w-4" /><span>Gönder</span></>}
                    </button>
                  </div>
                </form>
              )}

              {/* Direct Contact */}
              {user && listing.phone && (
                <div className="p-4 bg-gray-50 rounded-2xl space-y-2">
                  <p className="text-sm font-bold text-gray-900 flex items-center space-x-2">
                    <Phone className="h-4 w-4 text-orange-500" />
                    <span>Telefon</span>
                  </p>
                  <a href={`tel:${listing.phone}`} className="text-lg font-bold text-orange-600 hover:underline">
                    {listing.phone}
                  </a>
                  {listing.whatsapp && (
                    <a href={`https://wa.me/${listing.whatsapp.replace(/\D/g, '')}`} target="_blank"
                      className="flex items-center space-x-2 text-sm font-bold text-emerald-600 hover:underline">
                      <MessageCircle className="h-4 w-4" />
                      <span>WhatsApp'tan yaz</span>
                    </a>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
