import StoreContent from '@/components/StoreContent';
import HomeWrapper from '@/components/HomeWrapper';

export default function Home() {
  return <HomeWrapper><StoreContent /></HomeWrapper>;
}
