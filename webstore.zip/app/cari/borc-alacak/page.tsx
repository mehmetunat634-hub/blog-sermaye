'use client';

import { useState } from 'react';
import { useCari } from '@/lib/cari/useCari';
import { Plus } from 'lucide-react';
import DebtForm from '@/components/apps/cari/DebtForm';
import DebtList from '@/components/apps/cari/DebtList';

export default function BorcAlacakPage() {
  const { debts, isLoaded, addDebt, updateDebtStatus, deleteDebt } = useCari();
  const [formOpen, setFormOpen] = useState(false);
  const [filter, setFilter] = useState<string>('all');

  if (!isLoaded) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  const filtered = filter === 'all' ? debts : debts.filter(d => d.status === filter);

  const activeAlacak = debts.filter(d => d.type === 'alacak' && d.status === 'aktif').reduce((s, d) => s + d.amount, 0);
  const activeBorc = debts.filter(d => d.type === 'borc' && d.status === 'aktif').reduce((s, d) => s + d.amount, 0);

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Borç / Alacak</h1>
          <p className="text-gray-500 font-medium">Kişisel borç ve alacak takibi</p>
        </div>
        <button
          onClick={() => setFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>Ekle</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-emerald-50 rounded-[2rem] p-6">
          <p className="text-sm font-medium text-emerald-700">Toplam Alacak (Aktif)</p>
          <p className="text-3xl font-black text-emerald-700">{activeAlacak.toLocaleString()} TL</p>
        </div>
        <div className="bg-red-50 rounded-[2rem] p-6">
          <p className="text-sm font-medium text-red-700">Toplam Borç (Aktif)</p>
          <p className="text-3xl font-black text-red-700">{activeBorc.toLocaleString()} TL</p>
        </div>
      </div>

      {/* Filter tabs */}
      <div className="flex space-x-2">
        {['all', 'aktif', 'odendi', 'iptal'].map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-5 py-2 rounded-xl text-sm font-bold transition-all ${
              filter === f ? 'bg-gray-900 text-white' : 'bg-white text-gray-500 hover:bg-gray-100'
            }`}
          >
            {f === 'all' ? 'Tümü' : f === 'aktif' ? 'Aktif' : f === 'odendi' ? 'Ödenen' : 'İptal'}
          </button>
        ))}
      </div>

      <DebtList debts={filtered} onUpdateStatus={updateDebtStatus} onDelete={deleteDebt} />

      <DebtForm open={formOpen} onClose={() => setFormOpen(false)} onSave={addDebt} />
    </div>
  );
}
