'use client';

import { useCari } from '@/lib/cari/useCari';

import DashboardCards from '@/components/apps/cari/DashboardCards';
import CashFlowChart from '@/components/apps/cari/CashFlowChart';
import ExpensePieChart from '@/components/apps/cari/ExpensePieChart';
import TransactionList from '@/components/apps/cari/TransactionList';

export default function CariDashboard() {
  const { transactions, stats, isLoaded, deleteTransaction } = useCari();

  if (!isLoaded) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Dashboard</h1>
        <p className="text-gray-500 font-medium">
          {new Date().toLocaleDateString('tr-TR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>
      </div>

      {/* Cards */}
      <DashboardCards stats={stats} />

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <CashFlowChart transactions={transactions} />
        <ExpensePieChart data={stats?.expenseByCategory || []} />
      </div>

      {/* Recent Transactions */}
      <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold text-gray-900">Son İşlemler</h2>
        </div>
        <TransactionList
          transactions={transactions.slice(0, 10)}
          onDelete={deleteTransaction}
        />
      </div>
    </div>
  );
}
