'use client';

import { useState } from 'react';
import { useCari } from '@/lib/cari/useCari';
import { Plus } from 'lucide-react';
import TransactionForm from '@/components/apps/cari/TransactionForm';
import TransactionList from '@/components/apps/cari/TransactionList';

export default function NakitAkisiPage() {
  const { transactions, isLoaded, addTransaction, deleteTransaction } = useCari();
  const [formOpen, setFormOpen] = useState(false);

  if (!isLoaded) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  const totalGelir = transactions.filter(t => t.type === 'gelir').reduce((s, t) => s + t.amount, 0);
  const totalGider = transactions.filter(t => t.type === 'gider').reduce((s, t) => s + t.amount, 0);

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Nakit Akışı</h1>
          <p className="text-gray-500 font-medium">Tüm gelir ve gider işlemleriniz</p>
        </div>
        <button
          onClick={() => setFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>İşlem Ekle</span>
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
          <p className="text-sm font-medium text-gray-500">Toplam Gelir</p>
          <p className="text-2xl font-black text-emerald-600">{totalGelir.toLocaleString()} TL</p>
        </div>
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
          <p className="text-sm font-medium text-gray-500">Toplam Gider</p>
          <p className="text-2xl font-black text-red-600">{totalGider.toLocaleString()} TL</p>
        </div>
        <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
          <p className="text-sm font-medium text-gray-500">Net Bakiye</p>
          <p className={`text-2xl font-black ${totalGelir - totalGider >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {(totalGelir - totalGider).toLocaleString()} TL
          </p>
        </div>
      </div>

      {/* Transaction List */}
      <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 mb-6">Tüm İşlemler</h2>
        <TransactionList transactions={transactions} onDelete={deleteTransaction} />
      </div>

      <TransactionForm open={formOpen} onClose={() => setFormOpen(false)} onSave={addTransaction} />
    </div>
  );
}
