'use client';

import { useCari } from '@/lib/cari/useCari';
import { useState } from 'react';
import TransactionForm from '@/components/apps/cari/TransactionForm';
import TransactionList from '@/components/apps/cari/TransactionList';
import ExpensePieChart from '@/components/apps/cari/ExpensePieChart';
import { Plus } from 'lucide-react';

export default function GiderlerPage() {
  const { transactions, isLoaded, addTransaction, deleteTransaction, stats } = useCari();
  const [formOpen, setFormOpen] = useState(false);

  if (!isLoaded) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  const giderler = transactions.filter(t => t.type === 'gider');
  const totalGider = giderler.reduce((s, t) => s + t.amount, 0);

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Gider Takibi</h1>
          <p className="text-gray-500 font-medium">Harcamalarınızı kategorilere göre yönetin</p>
        </div>
        <button
          onClick={() => setFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-red-600 text-white font-bold rounded-2xl hover:bg-red-700 transition-all active:scale-[0.98] shadow-lg shadow-red-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>Gider Ekle</span>
        </button>
      </div>

      <div className="bg-white rounded-[2rem] border border-gray-100 p-6 shadow-sm">
        <p className="text-sm font-medium text-gray-500">Toplam Gider</p>
        <p className="text-3xl font-black text-red-600">{totalGider.toLocaleString()} TL</p>
      </div>

      <ExpensePieChart data={stats?.expenseByCategory || []} />

      <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 mb-6">Tüm Giderler</h2>
        <TransactionList transactions={giderler} onDelete={deleteTransaction} />
      </div>

      <TransactionForm open={formOpen} onClose={() => setFormOpen(false)} onSave={addTransaction} />
    </div>
  );
}
