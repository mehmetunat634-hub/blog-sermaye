'use client';

import { useState } from 'react';
import { useCari } from '@/lib/cari/useCari';
import { Plus } from 'lucide-react';
import InvoiceForm from '@/components/apps/cari/InvoiceForm';
import InvoiceList from '@/components/apps/cari/InvoiceList';
import InvoicePDF from '@/components/apps/cari/InvoicePDF';
import type { CariInvoice } from '@/lib/cari/types';

export default function FaturalarPage() {
  const { invoices, isLoaded, addInvoice, updateInvoiceStatus, deleteInvoice } = useCari();
  const [formOpen, setFormOpen] = useState(false);
  const [viewingInvoice, setViewingInvoice] = useState<CariInvoice | null>(null);
  const [filter, setFilter] = useState<string>('all');

  if (!isLoaded) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  const filtered = filter === 'all' ? invoices : invoices.filter(inv => inv.status === filter);

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Faturalar</h1>
          <p className="text-gray-500 font-medium">Fatura oluşturun ve yönetin</p>
        </div>
        <button
          onClick={() => setFormOpen(true)}
          className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white font-bold rounded-2xl hover:bg-blue-700 transition-all active:scale-[0.98] shadow-lg shadow-blue-500/25"
        >
          <Plus className="h-5 w-5" />
          <span>Yeni Fatura</span>
        </button>
      </div>

      {/* Filter tabs */}
      <div className="flex space-x-2">
        {[
          { key: 'all', label: 'Tümü' },
          { key: 'taslak', label: 'Taslak' },
          { key: 'gonderildi', label: 'Gönderildi' },
          { key: 'odendi', label: 'Ödendi' },
        ].map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-5 py-2 rounded-xl text-sm font-bold transition-all ${
              filter === f.key ? 'bg-gray-900 text-white' : 'bg-white text-gray-500 hover:bg-gray-100'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <InvoiceList
        invoices={filtered}
        onUpdateStatus={updateInvoiceStatus}
        onDelete={deleteInvoice}
        onView={setViewingInvoice}
      />

      <InvoiceForm open={formOpen} onClose={() => setFormOpen(false)} onSave={addInvoice} />

      <InvoicePDF invoice={viewingInvoice} onClose={() => setViewingInvoice(null)} />
    </div>
  );
}
