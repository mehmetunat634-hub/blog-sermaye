import AppGuard from '@/components/AppGuard';
import CariSidebar from '@/components/apps/cari/Sidebar';
import CariInAppGuard from '@/components/apps/cari/CariInAppGuard';
import { CariRoleProvider } from '@/lib/cari/CariRoleContext';

export default function CariLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppGuard>
      <CariRoleProvider>
        <CariInAppGuard>
          <div className="flex min-h-[calc(100vh-4rem)]">
            <CariSidebar />
            <main className="flex-grow bg-gray-50 overflow-auto">
              {children}
            </main>
          </div>
        </CariInAppGuard>
      </CariRoleProvider>
    </AppGuard>
  );
}
