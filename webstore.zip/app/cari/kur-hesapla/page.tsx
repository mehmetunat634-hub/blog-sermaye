'use client';

import { useCari } from '@/lib/cari/useCari';
import ExchangeRateCalculator from '@/components/apps/cari/ExchangeRateCalculator';

export default function KurHesaplaPage() {
  const { rates, isLoaded, refreshRates } = useCari();

  if (!isLoaded) {
    return (
      <div className="p-20 flex items-center justify-center">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Kur Hesaplayıcı</h1>
        <p className="text-gray-500 font-medium">Canlı döviz kurları ile anlık hesaplama</p>
      </div>

      <ExchangeRateCalculator rates={rates} onRefresh={refreshRates} />
    </div>
  );
}
