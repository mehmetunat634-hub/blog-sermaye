import { mockApps } from '@/lib/data';
import AppCard from '@/components/AppCard';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';

export default function CategoriesPage() {
  const categoryMap = new Map<string, typeof mockApps>();

  for (const app of mockApps) {
    const existing = categoryMap.get(app.category);
    if (existing) {
      existing.push(app);
    } else {
      categoryMap.set(app.category, [app]);
    }
  }

  const categories = Array.from(categoryMap.entries());

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <Link
          href="/"
          className="inline-flex items-center space-x-2 text-sm text-gray-500 hover:text-gray-900 transition-colors mb-4"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Ana Sayfa</span>
        </Link>
        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Tüm Kategoriler</h1>
        <p className="text-gray-500 mt-1">
          {mockApps.length} uygulama • {categories.length} kategori
        </p>
      </div>

      {categories.length === 0 ? (
        <div className="text-center py-24 text-gray-400 font-medium">
          Henüz kategori bulunmuyor.
        </div>
      ) : (
        <div className="space-y-16">
          {categories.map(([category, apps]) => (
            <section key={category}>
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold text-gray-900 tracking-tight">{category}</h2>
                  <p className="text-gray-500">{apps.length} uygulama</p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-6">
                {apps.map((app) => (
                  <AppCard key={app.id} app={app} />
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}
