'use client';

import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Trophy, RotateCcw, HelpCircle, CheckCircle2, XCircle } from 'lucide-react';

const QUESTIONS = [
  { q: 'Türkiye\'nin başkenti neresidir?', a: ['İstanbul', 'Ankara', 'İzmir', 'Bursa'], correct: 1 },
  { q: 'Dünyanın en büyük okyanusu hangisidir?', a: ['Atlas Okyanusu', 'Hint Okyanusu', 'Pasifik Okyanusu', 'Arktik Okyanusu'], correct: 2 },
  { q: 'Hangi gezegen "Kızıl Gezegen" olarak bilinir?', a: ['Venüs', 'Jüpiter', 'Satürn', 'Mars'], correct: 3 },
  { q: 'İnsan vücudundaki en büyük organ hangisidir?', a: ['Karaciğer', 'Deri', 'Kalp', 'Beyin'], correct: 1 },
  { q: 'Türkiye\'de ilk yerli otomobilin adı nedir?', a: ['TOGG', 'Devrim', 'Anadol', 'Etox'], correct: 1 },
  { q: 'Hangi ülke dünyanın en çok konuşulan diline sahiptir?', a: ['İngiltere', 'ABD', 'Çin', 'Hindistan'], correct: 2 },
  { q: 'Pi sayısının yaklaşık değeri nedir?', a: ['2.14', '3.14', '4.14', '5.14'], correct: 1 },
  { q: 'Hangi hayvan en uzun süre yaşar?', a: ['Fil', 'Kaplumbağa', 'Balina', 'Papağan'], correct: 1 },
  { q: 'Türkiye\'nin en yüksek dağı hangisidir?', a: ['Erciyes', 'Ağrı', 'Süphan', 'Kaçkar'], correct: 1 },
  { q: 'Hangi element periyodik tabloda "Au" sembolüyle gösterilir?', a: ['Gümüş', 'Bakır', 'Altın', 'Alüminyum'], correct: 2 },
  { q: 'Osmanlı Devleti\'nin kurucusu kimdir?', a: ['Orhan Gazi', 'Osman Gazi', 'Fatih Sultan Mehmet', 'Yıldırım Beyazıt'], correct: 1 },
  { q: 'Dünyanın en uzun nehri hangisidir?', a: ['Amazon', 'Nil', 'Mississippi', 'Tuna'], correct: 1 },
  { q: 'Hangi hayvan türü uçamaz?', a: ['Kartal', 'Yarasa', 'Penguen', 'Martı'], correct: 2 },
  { q: 'Güneş sisteminin en büyük gezegeni hangisidir?', a: ['Satürn', 'Neptün', 'Uranüs', 'Jüpiter'], correct: 3 },
  { q: 'Türkiye\'de kaç bölge vardır?', a: ['5', '6', '7', '8'], correct: 3 },
  { q: 'Hangi renklerin karışımıyla mor renk elde edilir?', a: ['Kırmızı-Sarı', 'Mavi-Sarı', 'Kırmızı-Mavi', 'Yeşil-Sarı'], correct: 2 },
  { q: 'Dünyanın en kalabalık ülkesi hangisidir?', a: ['Hindistan', 'Çin', 'ABD', 'Endonezya'], correct: 0 },
  { q: 'Hangi organ kanı pompalar?', a: ['Akciğer', 'Böbrek', 'Kalp', 'Karaciğer'], correct: 2 },
  { q: 'Türkiye\'nin en büyük gölü hangisidir?', a: ['İznik Gölü', 'Van Gölü', 'Tuz Gölü', 'Beyşehir Gölü'], correct: 1 },
  { q: 'Hangi gezegen Dünya\'ya en yakındır?', a: ['Mars', 'Venüs', 'Merkür', 'Jüpiter'], correct: 1 },
];

type Screen = 'start' | 'quiz' | 'result';

export default function SakSekPage() {
  const [screen, setScreen] = useState<Screen>('start');
  const [current, setCurrent] = useState(0);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<(number | null)[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState(false);
  const [shuffled, setShuffled] = useState<typeof QUESTIONS>([]);

  const startGame = useCallback(() => {
    const s = [...QUESTIONS].sort(() => Math.random() - 0.5);
    setShuffled(s);
    setCurrent(0);
    setScore(0);
    setAnswers([]);
    setSelected(null);
    setShowFeedback(false);
    setScreen('quiz');
  }, []);

  const handleAnswer = (idx: number) => {
    if (showFeedback) return;
    setSelected(idx);
    setShowFeedback(true);

    const isCorrect = idx === shuffled[current].correct;
    if (isCorrect) setScore(prev => prev + 10);

    setAnswers(prev => {
      const next = [...prev];
      next[current] = idx;
      return next;
    });
  };

  const nextQuestion = () => {
    if (current < shuffled.length - 1) {
      setCurrent(prev => prev + 1);
      setSelected(null);
      setShowFeedback(false);
    } else {
      setScreen('result');
    }
  };

  const total = shuffled.length;
  const correctCount = answers.filter((a, i) => a === shuffled[i]?.correct).length;
  const progress = ((current + 1) / total) * 100;

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-gradient-to-br from-purple-50 via-white to-pink-50 flex items-center justify-center p-4">
      <AnimatePresence mode="wait">
        {screen === 'start' && (
          <motion.div
            key="start"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="text-center space-y-8 max-w-md"
          >
            <div className="w-28 h-28 bg-gradient-to-br from-purple-500 to-pink-500 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-2xl shadow-purple-500/20">
              <HelpCircle className="h-14 w-14 text-white" />
            </div>
            <div className="space-y-2">
              <h1 className="text-4xl font-black text-gray-900 tracking-tight">SakSek</h1>
              <p className="text-xl text-gray-500 font-medium">Soru Cevap Eğlencesi</p>
              <p className="text-gray-400 text-sm mt-4 max-w-xs mx-auto">
                {total} soruluk genel kültür yarışması. Her doğru cevap <strong className="text-purple-600">+10 puan</strong>!
              </p>
            </div>
            <button
              onClick={startGame}
              className="inline-flex items-center space-x-3 px-10 py-5 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold text-lg rounded-[2rem] hover:shadow-xl hover:shadow-purple-500/30 transition-all active:scale-[0.97]"
            >
              <Sparkles className="h-6 w-6" />
              <span>Başla</span>
            </button>
          </motion.div>
        )}

        {screen === 'quiz' && shuffled.length > 0 && (
          <motion.div
            key="quiz"
            initial={{ opacity: 0, x: 40 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -40 }}
            className="w-full max-w-2xl space-y-8"
          >
            {/* Progress */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-sm">
                <span className="font-bold text-gray-900">Soru {current + 1}/{total}</span>
                <span className="font-bold text-purple-600">{score} puan</span>
              </div>
              <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            {/* Question */}
            <div className="bg-white rounded-[2.5rem] p-8 shadow-lg border border-gray-100">
              <h2 className="text-2xl font-bold text-gray-900 leading-relaxed">
                {shuffled[current].q}
              </h2>
            </div>

            {/* Answers */}
            <div className="grid grid-cols-1 gap-3">
              {shuffled[current].a.map((answer, idx) => {
                let style = 'bg-white border-gray-200 hover:border-purple-300 hover:bg-purple-50';
                let icon = null;

                if (showFeedback) {
                  if (idx === shuffled[current].correct) {
                    style = 'bg-emerald-50 border-emerald-400 ring-2 ring-emerald-200';
                    icon = <CheckCircle2 className="h-6 w-6 text-emerald-500" />;
                  } else if (idx === selected) {
                    style = 'bg-red-50 border-red-400 ring-2 ring-red-200';
                    icon = <XCircle className="h-6 w-6 text-red-500" />;
                  } else {
                    style = 'bg-gray-50 border-gray-200 opacity-50';
                  }
                }

                return (
                  <motion.button
                    key={idx}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    onClick={() => handleAnswer(idx)}
                    className={`flex items-center justify-between w-full p-5 rounded-2xl border-2 text-left font-medium text-gray-900 transition-all ${style}`}
                  >
                    <div className="flex items-center space-x-4">
                      <span className="w-8 h-8 rounded-xl bg-gray-100 flex items-center justify-center text-sm font-black text-gray-500">
                        {String.fromCharCode(65 + idx)}
                      </span>
                      <span>{answer}</span>
                    </div>
                    {icon}
                  </motion.button>
                );
              })}
            </div>

            {/* Next button */}
            <AnimatePresence>
              {showFeedback && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-center"
                >
                  <button
                    onClick={nextQuestion}
                    className="px-8 py-4 bg-gray-900 text-white font-bold rounded-2xl hover:bg-gray-800 transition-all active:scale-[0.97]"
                  >
                    {current < total - 1 ? 'Sonraki Soru' : 'Sonuçları Gör'}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {screen === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center space-y-8 max-w-md"
          >
            <div className="w-28 h-28 bg-gradient-to-br from-amber-400 to-orange-500 rounded-[2.5rem] flex items-center justify-center mx-auto shadow-2xl shadow-amber-500/20">
              <Trophy className="h-14 w-14 text-white" />
            </div>

            <div className="space-y-2">
              <h1 className="text-4xl font-black text-gray-900 tracking-tight">{score} Puan</h1>
              <p className="text-gray-500 text-lg">
                <strong className="text-emerald-600">{correctCount}</strong> doğru,{' '}
                <strong className="text-red-500">{total - correctCount}</strong> yanlış
              </p>
            </div>

            {/* Score bar */}
            <div className="bg-white rounded-[2rem] p-8 shadow-lg border border-gray-100 space-y-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-500 font-medium">Başarım</span>
                <span className="font-bold text-gray-900">%{Math.round((correctCount / total) * 100)}</span>
              </div>
              <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${(correctCount / total) * 100}%` }}
                  transition={{ duration: 1, delay: 0.3 }}
                />
              </div>
              <p className="text-gray-400 text-sm font-medium">
                {correctCount === total && 'Mükemmel! Tüm soruları bildiniz! 🏆'}
                {correctCount >= total * 0.8 && correctCount < total && 'Harika! Çok iyi bir sonuç! 👏'}
                {correctCount >= total * 0.6 && correctCount < total * 0.8 && 'Güzel! Ortalamanın üstündesiniz! 👍'}
                {correctCount >= total * 0.4 && correctCount < total * 0.6 && 'Fena değil, biraz daha çalışmalısınız! 📚'}
                {correctCount < total * 0.4 && 'Biraz zorlandınız, tekrar deneyin! 💪'}
              </p>
            </div>

            <button
              onClick={startGame}
              className="inline-flex items-center space-x-3 px-8 py-4 bg-gray-900 text-white font-bold text-lg rounded-[2rem] hover:bg-gray-800 transition-all active:scale-[0.97]"
            >
              <RotateCcw className="h-5 w-5" />
              <span>Tekrar Oyna</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
