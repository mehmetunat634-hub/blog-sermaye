import db from '@/lib/db';
import { verifyPassword, signToken } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();

    if (!email || !password) {
      return Response.json({ error: 'Email ve şifre zorunludur' }, { status: 400 });
    }

    const row = await db.get('SELECT id, email, name, password, balance, role FROM users WHERE email = ?', [email]);
    if (!row) {
      return Response.json({ error: 'Email veya şifre hatalı' }, { status: 401 });
    }

    if (!verifyPassword(password, row.password)) {
      return Response.json({ error: 'Email veya şifre hatalı' }, { status: 401 });
    }

    const token = signToken({ userId: row.id, email: row.email });

    const response = Response.json({
      token,
      user: { id: row.id, email: row.email, name: row.name, balance: row.balance, role: row.role }
    });

    response.headers.set(
      'Set-Cookie',
      `token=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${7 * 24 * 60 * 60}`
    );

    return response;
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
