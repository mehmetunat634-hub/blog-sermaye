import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const row = await db.get(
      'SELECT id, email, name, balance, role, created_at FROM users WHERE id = ?',
      [payload.userId]
    );

    if (!row) {
      return Response.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    return Response.json({
      user: {
        id: row.id,
        email: row.email,
        name: row.name,
        balance: row.balance,
        role: row.role,
        createdAt: row.created_at
      }
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
