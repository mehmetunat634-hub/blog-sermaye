import db from '@/lib/db';
import { hashPassword } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const { email, name, password } = await request.json();

    if (!email || !name || !password) {
      return Response.json({ error: 'Tüm alanlar zorunludur' }, { status: 400 });
    }

    if (password.length < 6) {
      return Response.json({ error: 'Şifre en az 6 karakter olmalıdır' }, { status: 400 });
    }

    const existing = await db.get('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) {
      return Response.json({ error: 'Bu email zaten kayıtlı' }, { status: 409 });
    }

    const existingReq = await db.get(
      'SELECT id FROM registration_requests WHERE email = ? AND status = ?',
      [email, 'pending']
    );
    if (existingReq) {
      return Response.json({ error: 'Bu email için zaten bekleyen bir kayıt talebi var' }, { status: 409 });
    }

    const hashed = hashPassword(password);

    await db.run(
      'INSERT INTO registration_requests (name, email, password, status) VALUES (?, ?, ?, ?)',
      [name, email, hashed, 'pending']
    );

    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
