import db from '@/lib/db';
import { verifyToken, verifyPassword } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const { password } = await request.json();
    if (!password) {
      return Response.json({ error: 'Şifre zorunludur' }, { status: 400 });
    }

    const row = await db.get('SELECT password FROM users WHERE id = ?', [payload.userId]);
    if (!row) {
      return Response.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    if (!verifyPassword(password, row.password)) {
      return Response.json({ error: 'Şifre hatalı' }, { status: 401 });
    }

    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
