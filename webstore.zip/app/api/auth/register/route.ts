import db from '@/lib/db';
import { hashPassword, signToken } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const { email, name, password } = await request.json();

    if (!email || !name || !password) {
      return Response.json({ error: 'Tüm alanlar zorunludur' }, { status: 400 });
    }

    if (password.length < 6) {
      return Response.json({ error: 'Şifre en az 6 karakter olmalıdır' }, { status: 400 });
    }

    const existing = await db.get('SELECT id FROM users WHERE email = ?', [email]);
    if (existing) {
      return Response.json({ error: 'Bu email zaten kayıtlı' }, { status: 409 });
    }

    const hashed = hashPassword(password);
    const role = 'user';

    const existingAdmin = await db.get("SELECT id FROM users WHERE role = 'admin'");
    const countResult = await db.get('SELECT COUNT(*) as count FROM users');
    const isFirstUser = existingAdmin ? false : countResult.count === 0;
    const finalRole = isFirstUser ? 'admin' : role;

    const result = await db.run(
      'INSERT INTO users (email, name, password, balance, role) VALUES (?, ?, ?, 100, ?)',
      [email, name, hashed, finalRole]
    );

    const token = signToken({ userId: result.insertId, email });

    const response = Response.json({
      token,
      user: { id: result.insertId, email, name, balance: 100, role: finalRole }
    });

    response.headers.set(
      'Set-Cookie',
      `token=${token}; HttpOnly; Path=/; SameSite=Lax; Max-Age=${7 * 24 * 60 * 60}`
    );

    return response;
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
