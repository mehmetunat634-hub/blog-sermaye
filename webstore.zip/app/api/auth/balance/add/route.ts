import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const { amount, email } = await request.json();
    const addAmount = Math.max(0, Math.min(amount, 10000));

    const user = await db.get('SELECT email FROM users WHERE id = ?', [payload.userId]);

    await db.run('UPDATE users SET balance = balance + ? WHERE id = ?', [addAmount, payload.userId]);

    const row = await db.get('SELECT balance FROM users WHERE id = ?', [payload.userId]);

    return Response.json({
      balance: row.balance,
      email: email || user.email,
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
