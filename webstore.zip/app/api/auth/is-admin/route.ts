import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ isAdmin: false, error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ isAdmin: false, error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const row = await db.get('SELECT role FROM users WHERE id = ?', [payload.userId]);

    if (!row || row.role !== 'admin') {
      return Response.json({ isAdmin: false });
    }

    return Response.json({ isAdmin: true });
  } catch {
    return Response.json({ isAdmin: false, error: 'Sunucu hatası' }, { status: 500 });
  }
}
