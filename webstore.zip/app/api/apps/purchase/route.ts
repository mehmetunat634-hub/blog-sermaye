import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { mockApps } from '@/lib/data';

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const { appSlug } = await request.json();
    const app = mockApps.find(a => a.slug === appSlug);
    if (!app) {
      return Response.json({ error: 'Uygulama bulunamadı' }, { status: 404 });
    }

    if (app.price === 0) {
      return Response.json({ error: 'Ücretsiz uygulamalar satın alınamaz' }, { status: 400 });
    }

    const existing = await db.get(
      'SELECT id FROM purchases WHERE user_id = ? AND app_slug = ?',
      [payload.userId, appSlug]
    );

    if (existing) {
      return Response.json({ error: 'Bu uygulama zaten satın alınmış' }, { status: 409 });
    }

    const user = await db.get('SELECT balance FROM users WHERE id = ?', [payload.userId]);
    if (user.balance < app.price) {
      return Response.json({ error: 'Yetersiz bakiye' }, { status: 402 });
    }

    await db.run('UPDATE users SET balance = balance - ? WHERE id = ?', [app.price, payload.userId]);
    await db.run('INSERT INTO purchases (user_id, app_slug, amount) VALUES (?, ?, ?)', [payload.userId, appSlug, app.price]);

    return Response.json({ success: true, balance: user.balance - app.price });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
