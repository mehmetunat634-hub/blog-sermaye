import db from '@/lib/db';
import { mockApps } from '@/lib/data';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const rows = await db.all(
      'SELECT app_slug, amount, purchased_at FROM purchases WHERE user_id = ? ORDER BY purchased_at DESC',
      [payload.userId]
    );

    const purchased = rows.map((r: any) => {
      const app = mockApps.find(a => a.slug === r.app_slug);
      return {
        ...r,
        appName: app?.name || r.app_slug,
        appIcon: app?.icon || '📦',
      };
    });

    return Response.json({ purchases: purchased });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
