import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const rows = await db.all(
      'SELECT * FROM adisyon_kitchen_orders WHERE user_id = ? ORDER BY status ASC, sent_at ASC',
      [payload.userId]
    );

    return Response.json({
      orders: rows.map(r => ({
        id: r.id,
        tableId: r.table_id,
        tableName: r.table_name,
        items: JSON.parse(r.items),
        status: r.status,
        sentAt: r.sent_at,
      }))
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { tableId, tableName, items } = await request.json();
    const result = await db.run(
      'INSERT INTO adisyon_kitchen_orders (user_id, table_id, table_name, items) VALUES (?, ?, ?, ?)',
      [payload.userId, tableId, tableName, JSON.stringify(items)]
    );

    return Response.json({ id: result.insertId });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { orderId, status } = await request.json();
    const row = await db.get('SELECT user_id FROM adisyon_kitchen_orders WHERE id = ?', [orderId]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('UPDATE adisyon_kitchen_orders SET status = ? WHERE id = ?', [status, orderId]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
