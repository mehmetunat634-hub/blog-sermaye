import db from '@/lib/db';
import { verifyToken, hashPassword } from '@/lib/auth';

export async function GET(request: Request) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
  }
  const payload = verifyToken(authHeader.slice(7));
  if (!payload) {
    return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
  }

  const rows = await db.all(
    'SELECT id, name, created_at FROM adisyon_roles WHERE user_id = ? ORDER BY created_at ASC',
    [payload.userId]
  );
  return Response.json({ roles: rows });
}

export async function POST(request: Request) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
  }
  const payload = verifyToken(authHeader.slice(7));
  if (!payload) {
    return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
  }

  const { name, password } = await request.json();
  if (!name || !password) {
    return Response.json({ error: 'Rol adı ve şifre zorunludur' }, { status: 400 });
  }

  const existing = await db.get(
    'SELECT id FROM adisyon_roles WHERE user_id = ? AND name = ?',
    [payload.userId, name]
  );
  if (existing) {
    return Response.json({ error: 'Bu rol adı zaten mevcut' }, { status: 409 });
  }

  const hashed = hashPassword(password);
  const result = await db.run(
    'INSERT INTO adisyon_roles (user_id, name, password) VALUES (?, ?, ?)',
    [payload.userId, name, hashed]
  );

  return Response.json({ role: { id: result.insertId, name } }, { status: 201 });
}
