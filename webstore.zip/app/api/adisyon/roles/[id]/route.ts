import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
  }
  const payload = verifyToken(authHeader.slice(7));
  if (!payload) {
    return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
  }

  const { id } = await params;
  const result = await db.run('DELETE FROM adisyon_roles WHERE id = ? AND user_id = ?', [Number(id), payload.userId]);

  if (result.affectedRows === 0) {
    return Response.json({ error: 'Rol bulunamadı' }, { status: 404 });
  }

  return Response.json({ success: true });
}
