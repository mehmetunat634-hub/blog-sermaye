import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { tableName, items, total, discount, serviceCharge, paymentMethod } = await request.json();

    const result = await db.run(
      'INSERT INTO adisyon_bills (user_id, table_name, items, total, discount, service_charge, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [payload.userId, tableName, JSON.stringify(items), total, discount, serviceCharge, paymentMethod]
    );

    return Response.json({ id: result.insertId });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { billId } = await request.json();
    const row = await db.get('SELECT user_id FROM adisyon_bills WHERE id = ?', [billId]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('DELETE FROM adisyon_bills WHERE id = ?', [billId]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
