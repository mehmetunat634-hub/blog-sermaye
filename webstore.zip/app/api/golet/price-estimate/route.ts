export async function POST(request: Request) {
  try {
    const { category, condition, age } = await request.json();

    if (!category || !condition) {
      return Response.json({ error: 'Kategori ve durum zorunludur' }, { status: 400 });
    }

    const estimate = calculateEstimate(category, condition, age);
    return Response.json({ estimate });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function calculateEstimate(category: string, condition: string, age?: number) {
  const basePrices: Record<string, number> = {
    'Elektronik': 5000,
    'Araba': 500000,
    'Emlak': 2000000,
    'Giysi & Aksesuar': 500,
    'Ev & Bahçe': 1000,
    'Spor & Outdoor': 800,
    'Hobi & Oyuncak': 400,
    'Kitap & Dergi': 100,
    'Bebek & Çocuk': 300,
    'Diğer': 500,
  };

  let base = basePrices[category] || 500;

  if (condition === 'sifir') base *= 1.2;
  else if (condition === 'arizali') base *= 0.3;

  if (age && age > 0) {
    const depreciation = Math.min(age * 0.08, 0.7);
    base *= (1 - depreciation);
  }

  const min = Math.round(base * 0.7 / 10) * 10;
  const max = Math.round(base * 1.3 / 10) * 10;
  const avg = Math.round(base / 10) * 10;

  return { min, max, avg };
}
