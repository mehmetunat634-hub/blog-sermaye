import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const userId = payload.userId;

    const totalListings = await db.get('SELECT COUNT(*) as c FROM golet_listings WHERE user_id = ?', [userId]);
    const activeListings = await db.get('SELECT COUNT(*) as c FROM golet_listings WHERE user_id = ? AND status = ?', [userId, 'active']);
    const soldListings = await db.get('SELECT COUNT(*) as c FROM golet_listings WHERE user_id = ? AND status = ?', [userId, 'sold']);
    const totalViews = await db.get('SELECT COALESCE(SUM(views), 0) as c FROM golet_listings WHERE user_id = ?', [userId]);
    const totalInquiries = await db.get('SELECT COUNT(*) as c FROM golet_inquiries WHERE seller_id = ?', [userId]);

    const categoryRows = await db.all(
      'SELECT category, COUNT(*) as count FROM golet_listings WHERE user_id = ? GROUP BY category ORDER BY count DESC',
      [userId]
    );

    const statusRows = await db.all(
      'SELECT status, COUNT(*) as count FROM golet_listings WHERE user_id = ? GROUP BY status',
      [userId]
    );

    return Response.json({
      stats: {
        totalListings: Number(totalListings.c),
        activeListings: Number(activeListings.c),
        soldListings: Number(soldListings.c),
        totalViews: Number(totalViews.c),
        totalInquiries: Number(totalInquiries.c),
        categoryDistribution: categoryRows,
        statusDistribution: statusRows,
      },
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
