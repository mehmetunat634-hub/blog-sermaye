import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const mine = searchParams.get('mine');
    const category = searchParams.get('category');
    const search = searchParams.get('search');

    const authHeader = request.headers.get('authorization');
    const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7) : null;
    const payload = token ? verifyToken(token) : null;

    if (mine === 'true') {
      if (!payload) {
        return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
      }
      const rows = await db.all(
        'SELECT * FROM golet_listings WHERE user_id = ? ORDER BY updated_at DESC',
        [payload.userId]
      );
      const listings = rows.map(mapListing);
      return Response.json({ listings });
    }

    let sql = 'SELECT * FROM golet_listings WHERE status = ?';
    const params: any[] = ['active'];

    if (category && category !== 'Tümü') {
      sql += ' AND category = ?';
      params.push(category);
    }
    if (search) {
      sql += ' AND title LIKE ?';
      params.push(`%${search}%`);
    }

    sql += ' ORDER BY updated_at DESC';

    const rows = await db.all(sql, params);
    const listings = rows.map(mapListing);
    return Response.json({ listings });
  } catch (e) {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const { title, description, price, category, condition, location, phone, whatsapp, photos } = await request.json();

    if (!title || !price || !category) {
      return Response.json({ error: 'Başlık, fiyat ve kategori zorunludur' }, { status: 400 });
    }

    const result = await db.run(
      `INSERT INTO golet_listings (user_id, title, description, price, category, condition, location, phone, whatsapp, photos)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [payload.userId, title, description || '', price, category, condition || 'ikinci-el', location || '', phone || '', whatsapp || '', JSON.stringify(photos || [])]
    );

    return Response.json({ success: true, id: result.insertId }, { status: 201 });
  } catch (e) {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function mapListing(row: any) {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    description: row.description,
    price: Number(row.price),
    category: row.category,
    condition: row.condition,
    location: row.location,
    phone: row.phone,
    whatsapp: row.whatsapp,
    photos: (() => { try { return JSON.parse(row.photos || '[]'); } catch { return []; } })(),
    status: row.status,
    views: row.views,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}
