import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const { status } = await request.json();
    if (!['active', 'sold', 'expired'].includes(status)) {
      return Response.json({ error: 'Geçersiz durum' }, { status: 400 });
    }

    const listing = await db.get('SELECT * FROM golet_listings WHERE id = ? AND user_id = ?', [id, payload.userId]);
    if (!listing) {
      return Response.json({ error: 'İlan bulunamadı' }, { status: 404 });
    }

    await db.run('UPDATE golet_listings SET status = ? WHERE id = ?', [status, id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
