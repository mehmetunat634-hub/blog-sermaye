import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const row = await db.get('SELECT * FROM golet_listings WHERE id = ?', [id]);
    if (!row) {
      return Response.json({ error: 'İlan bulunamadı' }, { status: 404 });
    }

    // Increment views
    await db.run('UPDATE golet_listings SET views = views + 1 WHERE id = ?', [id]);

    return Response.json({ listing: mapListing(row) });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function PUT(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const listing = await db.get('SELECT * FROM golet_listings WHERE id = ? AND user_id = ?', [id, payload.userId]);
    if (!listing) {
      return Response.json({ error: 'İlan bulunamadı' }, { status: 404 });
    }

    const { title, description, price, category, condition, location, phone, whatsapp, photos, status } = await request.json();

    await db.run(
      `UPDATE golet_listings SET title = ?, description = ?, price = ?, category = ?, condition = ?, location = ?, phone = ?, whatsapp = ?, photos = ?, status = COALESCE(?, status) WHERE id = ?`,
      [
        title ?? listing.title, description ?? listing.description, price ?? listing.price,
        category ?? listing.category, condition ?? listing.condition, location ?? listing.location,
        phone ?? listing.phone, whatsapp ?? listing.whatsapp,
        photos ? JSON.stringify(photos) : listing.photos,
        status ?? null, id,
      ]
    );

    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const listing = await db.get('SELECT * FROM golet_listings WHERE id = ? AND user_id = ?', [id, payload.userId]);
    if (!listing) {
      return Response.json({ error: 'İlan bulunamadı' }, { status: 404 });
    }

    await db.run('DELETE FROM golet_listings WHERE id = ?', [id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function mapListing(row: any) {
  return {
    id: row.id,
    userId: row.user_id,
    title: row.title,
    description: row.description,
    price: Number(row.price),
    category: row.category,
    condition: row.condition,
    location: row.location,
    phone: row.phone,
    whatsapp: row.whatsapp,
    photos: (() => { try { return JSON.parse(row.photos || '[]'); } catch { return []; } })(),
    status: row.status,
    views: row.views,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}
