import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const rows = await db.all(
      `SELECT i.*, l.title as listing_title FROM golet_inquiries i
       LEFT JOIN golet_listings l ON i.listing_id = l.id
       WHERE i.seller_id = ? ORDER BY i.created_at DESC`,
      [payload.userId]
    );

    const inquiries = rows.map((r: any) => ({
      id: r.id,
      listingId: r.listing_id,
      sellerId: r.seller_id,
      listingTitle: r.listing_title,
      buyerName: r.buyer_name,
      buyerPhone: r.buyer_phone,
      buyerMessage: r.buyer_message,
      status: r.status,
      createdAt: r.created_at,
    }));

    return Response.json({ inquiries });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Mesaj göndermek için giriş yapmalısınız' }, { status: 401 });
    }
    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const { listingId, buyerName, buyerPhone, buyerMessage } = await request.json();
    if (!listingId || !buyerName || !buyerPhone) {
      return Response.json({ error: 'Ad, telefon ve ilan bilgisi zorunludur' }, { status: 400 });
    }

    const listing = await db.get('SELECT user_id FROM golet_listings WHERE id = ?', [listingId]);
    if (!listing) {
      return Response.json({ error: 'İlan bulunamadı' }, { status: 404 });
    }

    if (listing.user_id === payload.userId) {
      return Response.json({ error: 'Kendi ilanınıza mesaj gönderemezsiniz' }, { status: 400 });
    }

    await db.run(
      `INSERT INTO golet_inquiries (listing_id, seller_id, buyer_name, buyer_phone, buyer_message)
       VALUES (?, ?, ?, ?, ?)`,
      [listingId, listing.user_id, buyerName, buyerPhone, buyerMessage || '']
    );

    return Response.json({ success: true }, { status: 201 });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
