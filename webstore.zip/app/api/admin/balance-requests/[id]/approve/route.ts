import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.slice(7));
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const admin = await db.get('SELECT role FROM users WHERE id = ?', [payload.userId]);
    if (!admin || admin.role !== 'admin') {
      return Response.json({ error: 'Yetkiniz yok' }, { status: 403 });
    }

    const { id } = await params;

    const req = await db.get(
      'SELECT id, user_id, amount FROM balance_requests WHERE id = ? AND status = ?',
      [Number(id), 'pending']
    );
    if (!req) {
      return Response.json({ error: 'Talep bulunamadı veya zaten işlenmiş' }, { status: 404 });
    }

    await db.run('UPDATE balance_requests SET status = ? WHERE id = ?', ['approved', Number(id)]);
    await db.run('UPDATE users SET balance = balance + ? WHERE id = ?', [req.amount, req.user_id]);

    const row = await db.get('SELECT balance FROM users WHERE id = ?', [req.user_id]);
    const user = await db.get('SELECT name, email FROM users WHERE id = ?', [req.user_id]);

    return Response.json({
      success: true,
      balance: row.balance,
      user: { name: user.name, email: user.email },
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
