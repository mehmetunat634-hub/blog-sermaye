import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.slice(7));
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const admin = await db.get('SELECT role FROM users WHERE id = ?', [payload.userId]);
    if (!admin || admin.role !== 'admin') {
      return Response.json({ error: 'Yetkiniz yok' }, { status: 403 });
    }

    const url = new URL(request.url);
    const search = url.searchParams.get('search') || '';

    let rows;
    if (search) {
      rows = await db.all(
        'SELECT id, name, email, balance, role, created_at FROM users WHERE email LIKE ? ORDER BY created_at DESC',
        [`%${search}%`]
      );
    } else {
      rows = await db.all(
        'SELECT id, name, email, balance, role, created_at FROM users ORDER BY created_at DESC'
      );
    }

    return Response.json({ users: rows });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
