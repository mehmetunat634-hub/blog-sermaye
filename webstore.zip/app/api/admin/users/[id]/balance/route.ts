import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.slice(7));
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const admin = await db.get('SELECT role FROM users WHERE id = ?', [payload.userId]);
    if (!admin || admin.role !== 'admin') {
      return Response.json({ error: 'Yetkiniz yok' }, { status: 403 });
    }

    const { id } = await params;
    const { amount } = await request.json();
    const addAmount = Math.max(0, Math.min(amount, 100000));

    const user = await db.get('SELECT id, name, email FROM users WHERE id = ?', [Number(id)]);
    if (!user) {
      return Response.json({ error: 'Kullanıcı bulunamadı' }, { status: 404 });
    }

    await db.run('UPDATE users SET balance = balance + ? WHERE id = ?', [addAmount, Number(id)]);

    const row = await db.get('SELECT balance FROM users WHERE id = ?', [Number(id)]);

    return Response.json({
      success: true,
      balance: row.balance,
      user: { name: user.name, email: user.email },
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
