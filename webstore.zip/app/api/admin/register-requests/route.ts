import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.slice(7));
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const admin = await db.get('SELECT role FROM users WHERE id = ?', [payload.userId]);
    if (!admin || admin.role !== 'admin') {
      return Response.json({ error: 'Yetkiniz yok' }, { status: 403 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status') || 'pending';

    const requests = await db.all(
      'SELECT * FROM registration_requests WHERE status = ? ORDER BY created_at DESC',
      [status]
    );

    return Response.json({ requests });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
