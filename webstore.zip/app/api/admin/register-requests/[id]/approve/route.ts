import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const payload = verifyToken(authHeader.slice(7));
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const admin = await db.get('SELECT role FROM users WHERE id = ?', [payload.userId]);
    if (!admin || admin.role !== 'admin') {
      return Response.json({ error: 'Yetkiniz yok' }, { status: 403 });
    }

    const { id } = await params;

    const req = await db.get(
      'SELECT * FROM registration_requests WHERE id = ? AND status = ?',
      [Number(id), 'pending']
    );
    if (!req) {
      return Response.json({ error: 'Talep bulunamadı veya zaten işlenmiş' }, { status: 404 });
    }

    const existing = await db.get('SELECT id FROM users WHERE email = ?', [req.email]);
    if (existing) {
      await db.run('UPDATE registration_requests SET status = ? WHERE id = ?', ['rejected', Number(id)]);
      return Response.json({ error: 'Bu email zaten kayıtlı, talep reddedildi' }, { status: 409 });
    }

    const role = 'user';

    await db.run(
      'INSERT INTO users (email, name, password, balance, role) VALUES (?, ?, ?, 0, ?)',
      [req.email, req.name, req.password, role]
    );

    await db.run('UPDATE registration_requests SET status = ? WHERE id = ?', ['approved', Number(id)]);

    return Response.json({ success: true, email: req.email, name: req.name });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
