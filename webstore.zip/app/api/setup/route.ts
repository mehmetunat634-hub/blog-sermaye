import db from '@/lib/db';

export async function GET() {
  try {
    const existingAdmin = await db.get("SELECT id FROM users WHERE role = 'admin'");
    if (!existingAdmin) {
      const firstUser = await db.get('SELECT id FROM users ORDER BY id ASC LIMIT 1');
      if (firstUser) {
        await db.run("UPDATE users SET role = 'admin' WHERE id = ?", [firstUser.id]);
        return Response.json({ message: `User ${firstUser.id} promoted to admin` });
      }
    }
    return Response.json({ message: 'Admin already exists or no users found' });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
