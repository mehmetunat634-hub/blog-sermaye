export async function GET() {
  try {
    const res = await fetch('https://api.exchangerate-api.com/v4/latest/TRY');
    const data = await res.json();

    const currencies: { code: string; name: string; buying: number; selling: number }[] = [];

    const wanted = ['USD', 'EUR', 'GBP', 'CHF', 'JPY', 'CAD', 'AUD', 'SEK', 'NOK', 'DKK', 'SAR'];

    if (data.rates) {
      for (const code of wanted) {
        const rate = data.rates[code];
        if (rate) {
          const buying = Math.round((1 / rate) * 10000) / 10000;
          const selling = Math.round((1 / rate) * 10100) / 10000;
          currencies.push({ code, name: code, buying, selling });
        }
      }

      // Gold (approximate from XAU/USD)
      if (data.rates['XAU']) {
        const goldRate = 1 / data.rates['XAU'];
        currencies.push({ code: 'XAU', name: 'Altın (Gram)', buying: Math.round(goldRate * 100) / 100, selling: Math.round(goldRate * 101) / 100 });
      }
    }

    return Response.json(currencies);
  } catch {
    // Fallback static rates
    return Response.json([
      { code: 'USD', name: 'Amerikan Doları', buying: 30.50, selling: 30.80 },
      { code: 'EUR', name: 'Euro', buying: 33.20, selling: 33.55 },
      { code: 'GBP', name: 'İngiliz Sterlini', buying: 38.75, selling: 39.15 },
      { code: 'CHF', name: 'İsviçre Frangı', buying: 34.60, selling: 34.95 },
      { code: 'JPY', name: 'Japon Yeni', buying: 0.205, selling: 0.208 },
      { code: 'XAU', name: 'Altın (Gram)', buying: 1950.00, selling: 1975.00 },
      { code: 'CAD', name: 'Kanada Doları', buying: 22.80, selling: 23.05 },
      { code: 'AUD', name: 'Avustralya Doları', buying: 20.40, selling: 20.65 },
      { code: 'SEK', name: 'İsveç Kronu', buying: 2.95, selling: 3.00 },
      { code: 'NOK', name: 'Norveç Kronu', buying: 2.90, selling: 2.95 },
      { code: 'DKK', name: 'Danimarka Kronu', buying: 4.45, selling: 4.50 },
      { code: 'SAR', name: 'Suudi Arabistan Riyali', buying: 8.10, selling: 8.20 },
    ]);
  }
}
