import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const type = searchParams.get('type');

    let sql = 'SELECT * FROM cari_debts WHERE user_id = ?';
    const params: (string | number)[] = [payload.userId];

    if (status) { sql += ' AND status = ?'; params.push(status); }
    if (type) { sql += ' AND type = ?'; params.push(type); }

    sql += ' ORDER BY created_at DESC';

    const rows = await db.all(sql, params);
    return Response.json(rows.map(parseDebt));
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { personName, type, amount, dueDate, note } = await request.json();

    if (!personName || !type || !amount) {
      return Response.json({ error: 'Eksik alanlar' }, { status: 400 });
    }

    const result = await db.run(
      'INSERT INTO cari_debts (user_id, person_name, type, amount, due_date, note) VALUES (?, ?, ?, ?, ?, ?)',
      [payload.userId, personName, type, amount, dueDate || null, note || '']
    );

    const row = await db.get('SELECT * FROM cari_debts WHERE id = ?', [result.insertId]);
    return Response.json(parseDebt(row), { status: 201 });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { id, status } = await request.json();

    const row = await db.get('SELECT user_id FROM cari_debts WHERE id = ?', [id]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('UPDATE cari_debts SET status = ? WHERE id = ?', [status, id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return Response.json({ error: 'ID gerekli' }, { status: 400 });

    const row = await db.get('SELECT user_id FROM cari_debts WHERE id = ?', [id]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('DELETE FROM cari_debts WHERE id = ?', [id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function parseDebt(row: Record<string, unknown>) {
  return {
    id: row.id,
    userId: row.user_id,
    personName: row.person_name,
    type: row.type,
    amount: row.amount,
    dueDate: row.due_date,
    note: row.note,
    status: row.status,
    createdAt: row.created_at,
  };
}
