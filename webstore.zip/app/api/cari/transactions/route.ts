import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const category = searchParams.get('category');
    const from = searchParams.get('from');
    const to = searchParams.get('to');

    let sql = 'SELECT * FROM cari_transactions WHERE user_id = ?';
    const params: (string | number)[] = [payload.userId];

    if (type) { sql += ' AND type = ?'; params.push(type); }
    if (category) { sql += ' AND category = ?'; params.push(category); }
    if (from) { sql += ' AND transaction_date >= ?'; params.push(from); }
    if (to) { sql += ' AND transaction_date <= ?'; params.push(to); }

    sql += ' ORDER BY transaction_date DESC, created_at DESC';

    const rows = await db.all(sql, params);
    return Response.json(rows.map(parseTransaction));
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { type, amount, category, description, transactionDate } = await request.json();

    if (!type || !amount || !category || !transactionDate) {
      return Response.json({ error: 'Eksik alanlar' }, { status: 400 });
    }

    const result = await db.run(
      'INSERT INTO cari_transactions (user_id, type, amount, category, description, transaction_date) VALUES (?, ?, ?, ?, ?, ?)',
      [payload.userId, type, amount, category, description || '', transactionDate]
    );

    const row = await db.get('SELECT * FROM cari_transactions WHERE id = ?', [result.insertId]);
    return Response.json(parseTransaction(row), { status: 201 });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return Response.json({ error: 'ID gerekli' }, { status: 400 });

    const row = await db.get('SELECT user_id FROM cari_transactions WHERE id = ?', [id]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('DELETE FROM cari_transactions WHERE id = ?', [id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function parseTransaction(row: Record<string, unknown>) {
  return {
    id: row.id,
    userId: row.user_id,
    type: row.type,
    amount: row.amount,
    category: row.category,
    description: row.description,
    transactionDate: row.transaction_date,
    createdAt: row.created_at,
  };
}
