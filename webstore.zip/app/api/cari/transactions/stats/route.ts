import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const userId = payload.userId;

    const incomeRow = await db.get(
      'SELECT COALESCE(SUM(amount), 0) as total FROM cari_transactions WHERE user_id = ? AND type = ?',
      [userId, 'gelir']
    );
    const expenseRow = await db.get(
      'SELECT COALESCE(SUM(amount), 0) as total FROM cari_transactions WHERE user_id = ? AND type = ?',
      [userId, 'gider']
    );

    const totalIncome = Number(incomeRow.total);
    const totalExpense = Number(expenseRow.total);
    const balance = totalIncome - totalExpense;

    const now = new Date();
    const monthStart = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;

    const monthlyIncomeRow = await db.get(
      'SELECT COALESCE(SUM(amount), 0) as total FROM cari_transactions WHERE user_id = ? AND type = ? AND transaction_date >= ?',
      [userId, 'gelir', monthStart]
    );
    const monthlyExpenseRow = await db.get(
      'SELECT COALESCE(SUM(amount), 0) as total FROM cari_transactions WHERE user_id = ? AND type = ? AND transaction_date >= ?',
      [userId, 'gider', monthStart]
    );

    const debtRow = await db.get(
      "SELECT COALESCE(SUM(amount), 0) as total FROM cari_debts WHERE user_id = ? AND type = ? AND status = 'aktif'",
      [userId, 'borc']
    );
    const receivableRow = await db.get(
      "SELECT COALESCE(SUM(amount), 0) as total FROM cari_debts WHERE user_id = ? AND type = ? AND status = 'aktif'",
      [userId, 'alacak']
    );

    const recentRows = await db.all(
      'SELECT * FROM cari_transactions WHERE user_id = ? ORDER BY transaction_date DESC, created_at DESC LIMIT 10',
      [userId]
    );

    const expenseByCategory = await db.all(
      'SELECT category, COALESCE(SUM(amount), 0) as total FROM cari_transactions WHERE user_id = ? AND type = ? GROUP BY category ORDER BY total DESC',
      [userId, 'gider']
    );

    return Response.json({
      totalIncome,
      totalExpense,
      balance,
      activeDebt: Number(debtRow.total),
      activeReceivable: Number(receivableRow.total),
      monthlyIncome: Number(monthlyIncomeRow.total),
      monthlyExpense: Number(monthlyExpenseRow.total),
      recentTransactions: recentRows.map(parseTransaction),
      expenseByCategory: expenseByCategory.map((r: Record<string, unknown>) => ({ category: r.category as string, total: Number(r.total) })),
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function parseTransaction(row: Record<string, unknown>) {
  return {
    id: row.id,
    userId: row.user_id,
    type: row.type,
    amount: row.amount,
    category: row.category,
    description: row.description,
    transactionDate: row.transaction_date,
    createdAt: row.created_at,
  };
}
