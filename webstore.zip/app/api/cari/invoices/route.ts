import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');

    let sql = 'SELECT * FROM cari_invoices WHERE user_id = ?';
    const params: (string | number)[] = [payload.userId];

    if (status) { sql += ' AND status = ?'; params.push(status); }
    sql += ' ORDER BY created_at DESC';

    const rows = await db.all(sql, params);
    return Response.json(rows.map(parseInvoice));
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { customerName, customerPhone, customerAddress, items, taxRate } = await request.json();

    if (!customerName || !items || items.length === 0) {
      return Response.json({ error: 'Eksik alanlar' }, { status: 400 });
    }

    const year = new Date().getFullYear();
    const prefix = `FTR-${year}-`;
    const lastInvoice = await db.get(
      "SELECT invoice_no FROM cari_invoices WHERE user_id = ? AND invoice_no LIKE ? ORDER BY id DESC LIMIT 1",
      [payload.userId, `${prefix}%`]
    );

    let nextNum = 1;
    if (lastInvoice) {
      const lastNum = parseInt(lastInvoice.invoice_no.replace(prefix, ''), 10);
      if (!isNaN(lastNum)) nextNum = lastNum + 1;
    }
    const invoiceNo = `${prefix}${String(nextNum).padStart(3, '0')}`;

    const subtotal = items.reduce((s: number, item: Record<string, unknown>) => s + Number(item.quantity) * Number(item.unitPrice), 0);
    const taxAmount = Math.round(subtotal * taxRate * 100) / 10000;
    const total = subtotal + taxAmount;

    const result = await db.run(
      `INSERT INTO cari_invoices (user_id, invoice_no, customer_name, customer_phone, customer_address, items, subtotal, tax_rate, tax_amount, total)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [payload.userId, invoiceNo, customerName, customerPhone || '', customerAddress || '', JSON.stringify(items), subtotal, taxRate, taxAmount, total]
    );

    const row = await db.get('SELECT * FROM cari_invoices WHERE id = ?', [result.insertId]);
    return Response.json(parseInvoice(row), { status: 201 });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { id, status } = await request.json();

    const row = await db.get('SELECT user_id FROM cari_invoices WHERE id = ?', [id]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('UPDATE cari_invoices SET status = ? WHERE id = ?', [status, id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return Response.json({ error: 'ID gerekli' }, { status: 400 });

    const row = await db.get('SELECT user_id FROM cari_invoices WHERE id = ?', [id]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('DELETE FROM cari_invoices WHERE id = ?', [id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function parseInvoice(row: Record<string, unknown>) {
  return {
    id: row.id as number,
    userId: row.user_id as number,
    invoiceNo: row.invoice_no as string,
    customerName: row.customer_name as string,
    customerPhone: row.customer_phone as string,
    customerAddress: row.customer_address as string,
    items: JSON.parse(row.items as string),
    subtotal: row.subtotal as number,
    taxRate: row.tax_rate as number,
    taxAmount: row.tax_amount as number,
    total: row.total as number,
    status: row.status as string,
    createdAt: row.created_at as string,
  };
}
