import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const rows = await db.all(
      'SELECT * FROM cari_contacts WHERE user_id = ? ORDER BY name ASC',
      [payload.userId]
    );
    return Response.json(rows.map(parseContact));
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { name, phone, email, address } = await request.json();
    if (!name) return Response.json({ error: 'İsim gerekli' }, { status: 400 });

    const result = await db.run(
      'INSERT INTO cari_contacts (user_id, name, phone, email, address) VALUES (?, ?, ?, ?, ?)',
      [payload.userId, name, phone || '', email || '', address || '']
    );

    const row = await db.get('SELECT * FROM cari_contacts WHERE id = ?', [result.insertId]);
    return Response.json(parseContact(row), { status: 201 });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function parseContact(row: Record<string, unknown>) {
  return {
    id: row.id,
    userId: row.user_id,
    name: row.name,
    phone: row.phone,
    email: row.email,
    address: row.address,
    createdAt: row.created_at,
  };
}
