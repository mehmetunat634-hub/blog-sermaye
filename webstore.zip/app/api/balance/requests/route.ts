import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const payload = verifyToken(token);
    if (!payload) {
      return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
    }

    const { amount, email } = await request.json();
    const addAmount = Math.max(0, Math.min(amount, 10000));
    const targetEmail = (email || '').trim() || undefined;

    const user = await db.get('SELECT id, email FROM users WHERE id = ?', [payload.userId]);

    await db.run(
      'INSERT INTO balance_requests (user_id, email, amount, status) VALUES (?, ?, ?, ?)',
      [payload.userId, targetEmail || user.email, addAmount, 'pending']
    );

    return Response.json({
      success: true,
      email: targetEmail || user.email,
      amount: addAmount,
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
