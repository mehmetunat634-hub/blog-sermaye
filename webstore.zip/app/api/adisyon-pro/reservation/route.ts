import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const rows = await db.all(
      'SELECT * FROM adisyon_pro_reservations WHERE user_id = ? ORDER BY date ASC, time ASC',
      [payload.userId]
    );

    return Response.json({
      reservations: rows.map(r => ({
        id: r.id,
        tableName: r.table_name,
        guestName: r.guest_name,
        guestCount: r.guest_count,
        date: r.date,
        time: r.time,
        phone: r.phone,
        status: r.status,
        createdAt: r.created_at,
      }))
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { tableName, guestName, guestCount, date, time, phone } = await request.json();
    const result = await db.run(
      'INSERT INTO adisyon_pro_reservations (user_id, table_name, guest_name, guest_count, date, time, phone) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [payload.userId, tableName, guestName, guestCount, date, time, phone || '']
    );

    return Response.json({ id: result.insertId });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function DELETE(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { id } = await request.json();
    const row = await db.get('SELECT user_id FROM adisyon_pro_reservations WHERE id = ?', [id]);
    if (!row || row.user_id !== payload.userId) return Response.json({ error: 'Bulunamadı' }, { status: 404 });

    await db.run('UPDATE adisyon_pro_reservations SET status = ? WHERE id = ?', ['cancelled', id]);
    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
