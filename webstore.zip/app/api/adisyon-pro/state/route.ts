import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const row = await db.get('SELECT tables FROM adisyon_pro_state WHERE user_id = ?', [payload.userId]);
    const tables = row ? JSON.parse(row.tables) : [];

    const bills = await db.all(
      'SELECT * FROM adisyon_pro_bills WHERE user_id = ? ORDER BY closed_at DESC',
      [payload.userId]
    );

    const kitchenOrders = await db.all(
      "SELECT * FROM adisyon_pro_kitchen_orders WHERE user_id = ? AND status != 'ready' ORDER BY sent_at ASC",
      [payload.userId]
    );

    return Response.json({ tables, bills: bills.map(parseBill), kitchenOrders: kitchenOrders.map(parseKitchen) });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { tables } = await request.json();
    const existing = await db.get('SELECT 1 FROM adisyon_pro_state WHERE user_id = ?', [payload.userId]);
    if (existing) {
      await db.run(
        'UPDATE adisyon_pro_state SET tables = ?, updated_at = NOW() WHERE user_id = ?',
        [JSON.stringify(tables), payload.userId]
      );
    } else {
      await db.run(
        'INSERT INTO adisyon_pro_state (user_id, tables) VALUES (?, ?)',
        [payload.userId, JSON.stringify(tables)]
      );
    }

    return Response.json({ success: true });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}

function parseBill(row: any) {
  return {
    id: row.id,
    tableName: row.table_name,
    items: JSON.parse(row.items),
    total: row.total,
    discount: row.discount,
    serviceCharge: row.service_charge,
    paymentMethod: row.payment_method,
    closedAt: row.closed_at,
  };
}

function parseKitchen(row: any) {
  return {
    id: row.id,
    tableId: row.table_id,
    tableName: row.table_name,
    items: JSON.parse(row.items),
    status: row.status,
    sentAt: row.sent_at,
  };
}
