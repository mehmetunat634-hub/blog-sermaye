import db from '@/lib/db';
import { verifyToken, hashPassword } from '@/lib/auth';

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
  }
  const payload = verifyToken(authHeader.slice(7));
  if (!payload) {
    return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
  }

  const { id } = await params;
  const { name, password } = await request.json();

  if (name) {
    const existing = await db.get(
      'SELECT id FROM adisyon_pro_roles WHERE user_id = ? AND name = ? AND id != ?',
      [payload.userId, name, Number(id)]
    );
    if (existing) {
      return Response.json({ error: 'Bu rol adı zaten mevcut' }, { status: 409 });
    }
  }

  if (name && password) {
    const hashed = hashPassword(password);
    await db.run(
      'UPDATE adisyon_pro_roles SET name = ?, password = ? WHERE id = ? AND user_id = ?',
      [name, hashed, Number(id), payload.userId]
    );
  } else if (name) {
    await db.run(
      'UPDATE adisyon_pro_roles SET name = ? WHERE id = ? AND user_id = ?',
      [name, Number(id), payload.userId]
    );
  } else if (password) {
    const hashed = hashPassword(password);
    await db.run(
      'UPDATE adisyon_pro_roles SET password = ? WHERE id = ? AND user_id = ?',
      [hashed, Number(id), payload.userId]
    );
  }

  return Response.json({ success: true });
}

export async function DELETE(request: Request, { params }: { params: Promise<{ id: string }> }) {
  const authHeader = request.headers.get('authorization');
  if (!authHeader?.startsWith('Bearer ')) {
    return Response.json({ error: 'Oturum bulunamadı' }, { status: 401 });
  }
  const payload = verifyToken(authHeader.slice(7));
  if (!payload) {
    return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });
  }

  const { id } = await params;
  const result = await db.run('DELETE FROM adisyon_pro_roles WHERE id = ? AND user_id = ?', [Number(id), payload.userId]);

  if (result.affectedRows === 0) {
    return Response.json({ error: 'Rol bulunamadı' }, { status: 404 });
  }

  return Response.json({ success: true });
}
