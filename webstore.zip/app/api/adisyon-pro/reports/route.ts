import db from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) return Response.json({ error: 'Oturum gerekli' }, { status: 401 });
    const payload = verifyToken(authHeader.slice(7));
    if (!payload) return Response.json({ error: 'Oturum süresi dolmuş' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const date = searchParams.get('date') || new Date().toISOString().split('T')[0];

    const todayBills = await db.all(
      'SELECT * FROM adisyon_pro_bills WHERE user_id = ? AND DATE(closed_at) = ? ORDER BY closed_at DESC',
      [payload.userId, date]
    );

    const totalRevenue = todayBills.reduce((s: number, b: any) => s + b.total, 0);
    const totalDiscount = todayBills.reduce((s: number, b: any) => s + b.discount, 0);
    const orderCount = todayBills.length;

    const categorySales: Record<string, number> = {};
    const itemSales: Record<string, { name: string; totalQty: number; totalRevenue: number }> = {};

    for (const bill of todayBills) {
      const items = JSON.parse(bill.items);
      for (const item of items) {
        const category = item.category || 'Diğer';
        categorySales[category] = (categorySales[category] || 0) + item.price * item.quantity;
        if (!itemSales[item.id]) itemSales[item.id] = { name: item.name, totalQty: 0, totalRevenue: 0 };
        itemSales[item.id].totalQty += item.quantity;
        itemSales[item.id].totalRevenue += item.price * item.quantity;
      }
    }

    const cashTotal = todayBills.filter(b => b.payment_method === 'cash').reduce((s, b) => s + b.total, 0);
    const cardTotal = todayBills.filter(b => b.payment_method === 'card').reduce((s, b) => s + b.total, 0);

    const topItems = Object.values(itemSales).sort((a, b) => b.totalQty - a.totalQty).slice(0, 10);

    return Response.json({
      date,
      totalRevenue,
      totalDiscount,
      orderCount,
      cashTotal,
      cardTotal,
      categorySales: Object.entries(categorySales).map(([category, revenue]) => ({ category, revenue })),
      topItems,
    });
  } catch {
    return Response.json({ error: 'Sunucu hatası' }, { status: 500 });
  }
}
