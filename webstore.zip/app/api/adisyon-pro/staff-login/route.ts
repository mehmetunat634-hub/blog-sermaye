import db from '@/lib/db';
import { verifyPassword } from '@/lib/auth';

export async function POST(request: Request) {
  const { password } = await request.json();
  if (!password) {
    return Response.json({ error: 'Şifre zorunludur' }, { status: 400 });
  }

  const rows = await db.all('SELECT id, name, password FROM adisyon_pro_roles');
  for (const row of rows) {
    if (verifyPassword(password, row.password)) {
      return Response.json({ role: { id: row.id, name: row.name } });
    }
  }

  return Response.json({ error: 'Şifre hatalı' }, { status: 401 });
}
