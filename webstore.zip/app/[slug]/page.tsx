import { mockApps } from '@/lib/data';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Star, Download, Shield, Share2, Info, ChevronRight } from 'lucide-react';

interface PageProps {
  params: Promise<{ slug: string }>;
}

export default async function AppDetail({ params }: PageProps) {
  const { slug } = await params;
  const app = mockApps.find((a) => a.slug === slug);

  if (!app) {
    notFound();
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="flex flex-col md:flex-row gap-12 items-start">
        {/* Left: Icon and Header */}
        <div className="flex-shrink-0">
          <div className="w-48 h-48 rounded-[3rem] bg-gray-100 flex items-center justify-center text-7xl shadow-xl">
            {app.icon}
          </div>
        </div>

        {/* Right: Info and Actions */}
        <div className="flex-grow space-y-6">
          <div className="space-y-2">
            <h1 className="text-4xl font-bold text-gray-900 tracking-tight">{app.name}</h1>
            <p className="text-xl text-blue-600 font-medium">{app.developer}</p>
            <p className="text-gray-500 uppercase tracking-widest text-sm font-semibold">{app.category}</p>
          </div>

          <div className="flex items-center space-x-8 py-4 border-y border-gray-100">
            <div className="text-center">
              <div className="flex items-center justify-center space-x-1 font-bold text-gray-900">
                <span>{app.rating}</span>
                <Star className="h-4 w-4 fill-gray-900" />
              </div>
              <p className="text-xs text-gray-500 font-medium">1.2B Değerlendirme</p>
            </div>
            <div className="w-px h-8 bg-gray-200" />
            <div className="text-center">
              <div className="font-bold text-gray-900">1M+</div>
              <p className="text-xs text-gray-500 font-medium">Kullanıcı</p>
            </div>
            <div className="w-px h-8 bg-gray-200" />
            <div className="text-center">
              <div className="font-bold text-gray-900">E</div>
              <p className="text-xs text-gray-500 font-medium">Herkes İçin</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Link 
              href={`/${app.slug}`}
              className="flex-grow sm:flex-grow-0 px-12 py-3 bg-blue-600 hover:bg-blue-700 text-white text-center font-bold rounded-full transition-all shadow-lg shadow-blue-500/25 active:scale-95"
            >
              {app.isPaid ? `${app.price} TL / ay Satın Al` : 'Hemen Başlat'}
            </Link>
            <button className="p-3 text-gray-500 hover:bg-gray-100 rounded-full transition-colors border border-gray-200">
              <Share2 className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Description Section */}
      <div className="mt-20 space-y-12">
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-gray-900">Uygulama Hakkında</h2>
            <ChevronRight className="h-6 w-6 text-gray-400" />
          </div>
          <p className="text-lg text-gray-600 leading-relaxed max-w-3xl">
            {app.description} Bu web uygulaması, kullanıcılarına en iyi deneyimi sunmak için modern teknolojilerle geliştirilmiştir.
            Minimalist arayüzü ve güçlü özellikleriyle iş akışınızı kolaylaştırır.
          </p>
        </section>

        {/* Features Placeholder */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-6 rounded-3xl bg-gray-50 space-y-3">
            <Shield className="h-8 w-8 text-blue-600" />
            <h3 className="font-bold text-gray-900">Güvenli</h3>
            <p className="text-sm text-gray-500">Verileriniz uçtan uca şifrelenir ve asla üçüncü taraflarla paylaşılmaz.</p>
          </div>
          <div className="p-6 rounded-3xl bg-gray-50 space-y-3">
            <Download className="h-8 w-8 text-blue-600" />
            <h3 className="font-bold text-gray-900">Hızlı Erişim</h3>
            <p className="text-sm text-gray-500">Kurulum gerektirmez, tarayıcınızdan anında kullanmaya başlayın.</p>
          </div>
          <div className="p-6 rounded-3xl bg-gray-50 space-y-3">
            <Info className="h-8 w-8 text-blue-600" />
            <h3 className="font-bold text-gray-900">Modern</h3>
            <p className="text-sm text-gray-500">En son tasarım trendleri ve kullanıcı deneyimi standartlarına uygundur.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
