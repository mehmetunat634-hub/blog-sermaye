import AppGuard from '@/components/AppGuard';

export default function SlugLayout({ children }: { children: React.ReactNode }) {
  return <AppGuard>{children}</AppGuard>;
}
