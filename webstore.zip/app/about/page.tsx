import Hero from '@/components/about/Hero';
import StatsGrid from '@/components/about/StatsGrid';
import DahaFazlaBilgi from '@/components/about/DahaFazlaBilgi';
import { ChevronRight, Layout, Zap, Smartphone } from 'lucide-react';
import Link from 'next/link';

export default function AboutPage() {
  return (
    <div className="bg-white">
      <Hero />

      {/* Manifesto Section */}
      <section className="py-32 bg-gray-50/50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-sm font-bold text-blue-600 uppercase tracking-[0.3em] mb-8">Vizyonumuz</h2>
          <blockquote className="text-3xl md:text-5xl font-medium text-gray-900 leading-tight tracking-tight">
            "Yazılımın sadece bir tık uzakta olduğu, kurulum ve bekleme sürelerinin tarihe karıştığı bir dünya inşa ediyoruz."
          </blockquote>
          <div className="mt-12 flex flex-col items-center">
            <div className="h-16 w-px bg-gradient-to-b from-blue-600 to-transparent" />
          </div>
        </div>
      </section>

      <StatsGrid />

      {/* How it works */}
      <section className="py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between mb-20">
            <div className="max-w-xl">
              <h2 className="text-4xl font-bold text-gray-900 tracking-tight mb-6">Nasıl Çalışır?</h2>
              <p className="text-lg text-gray-500">Karmaşıklığı sizin için basitleştirdik. Üç adımda favori uygulamanıza kavuşun.</p>
            </div>
            <Link href="/" className="mt-8 md:mt-0 flex items-center space-x-2 text-blue-600 font-bold group">
              <span>Hemen Dene</span>
              <ChevronRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                icon: <Layout className="h-10 w-10 text-blue-600" />,
                title: 'Keşfet',
                description: 'Yüzlerce modern web uygulaması arasından size en uygun olanı seçin.'
              },
              {
                icon: <Zap className="h-10 w-10 text-purple-600" />,
                title: 'Anında Aç',
                description: 'Kurulum gerektirmez. Uygulamalarınız tarayıcıda saniyeler içinde yüklenir.'
              },
              {
                icon: <Smartphone className="h-10 w-10 text-emerald-600" />,
                title: 'Her Yerde Kullan',
                description: 'Verileriniz bulutla senkronize. Masaüstü veya mobilde kaldığınız yerden devam edin.'
              }
            ].map((step, i) => (
              <div key={i} className="space-y-6 group">
                <div className="w-20 h-20 rounded-[2rem] bg-gray-50 flex items-center justify-center group-hover:scale-110 group-hover:bg-white group-hover:shadow-xl transition-all duration-300">
                  {step.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900">{step.title}</h3>
                <p className="text-gray-500 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Developer CTA */}
      <section className="py-24 px-4">
        <div className="max-w-5xl mx-auto bg-gray-900 rounded-[3rem] p-12 md:p-20 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600 blur-[100px] opacity-20 -translate-y-1/2 translate-x-1/2" />
          
          <div className="relative z-10 text-center space-y-8">
            <h2 className="text-3xl md:text-5xl font-bold text-white tracking-tight">
              Siz Odaklanın, Biz Dağıtalım.
            </h2>
            <p className="text-gray-400 text-lg max-w-2xl mx-auto leading-relaxed">
              Uygulama geliştiricileri için en kolay dağıtım platformu. Kodunuzu ParasızSepet'e ekleyin, dünya çapında milyonlara ulaşın.
            </p>
            <DahaFazlaBilgi />
          </div>
        </div>
      </section>
    </div>
  );
}
