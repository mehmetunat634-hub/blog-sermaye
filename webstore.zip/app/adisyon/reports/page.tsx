'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, Wallet, ReceiptText, Target, Percent, CreditCard } from 'lucide-react';

interface ReportData {
  date: string;
  totalRevenue: number;
  totalDiscount: number;
  orderCount: number;
  cashTotal: number;
  cardTotal: number;
  categorySales: { category: string; revenue: number }[];
  topItems: { name: string; totalQty: number; totalRevenue: number }[];
}

export default function ReportsPage() {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [data, setData] = useState<ReportData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) return;
    setLoading(true);
    fetch(`/api/adisyon/reports?date=${date}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(r => r.json())
      .then(d => setData(d))
      .finally(() => setLoading(false));
  }, [date]);

  if (loading) return (
    <div className="p-20 flex items-center justify-center">
      <div className="text-center space-y-4">
        <div className="w-10 h-10 border-4 border-blue-600/30 border-t-blue-600 rounded-full animate-spin mx-auto" />
        <p className="font-medium text-gray-500">Yükleniyor...</p>
      </div>
    </div>
  );

  if (!data) return (
    <div className="p-20 text-center">
      <p className="text-gray-400 font-medium">Giriş yapmalısınız</p>
    </div>
  );

  const maxCategory = Math.max(...data.categorySales.map(c => c.revenue), 1);
  const maxItem = Math.max(...data.topItems.map(i => i.totalQty), 1);
  const totalPayment = data.cashTotal + data.cardTotal;

  return (
    <div className="p-8 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Raporlar</h1>
          <p className="text-gray-500 font-medium">Günlük satış analizi</p>
        </div>
        <input
          type="date"
          value={date}
          onChange={e => setDate(e.target.value)}
          className="px-4 py-2 bg-white border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/20"
        />
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <SummaryCard icon={<Wallet className="h-6 w-6 text-emerald-600" />} label="Toplam Ciro" value={`${data.totalRevenue} TL`} bg="bg-emerald-50" />
        <SummaryCard icon={<ReceiptText className="h-6 w-6 text-blue-600" />} label="Toplam Sipariş" value={data.orderCount.toString()} bg="bg-blue-50" />
        <SummaryCard icon={<Percent className="h-6 w-6 text-rose-600" />} label="Toplam İndirim" value={`${data.totalDiscount} TL`} bg="bg-rose-50" />
        <SummaryCard icon={<Target className="h-6 w-6 text-amber-600" />} label="Ortalama Sepet" value={data.orderCount > 0 ? `${Math.round(data.totalRevenue / data.orderCount)} TL` : '0 TL'} bg="bg-amber-50" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Payment Methods */}
        <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Ödeme Yöntemleri</h2>
          {totalPayment > 0 ? (
            <div className="space-y-5">
              <PaymentBar label="Nakit" amount={data.cashTotal} total={totalPayment} color="bg-green-500" icon="💵" />
              <PaymentBar label="Kart" amount={data.cardTotal} total={totalPayment} color="bg-purple-500" icon="💳" />
              <div className="pt-4 border-t border-gray-100 flex justify-between">
                <span className="font-bold text-gray-900">Toplam</span>
                <span className="font-black text-gray-900">{totalPayment} TL</span>
              </div>
            </div>
          ) : (
            <p className="text-gray-400 font-medium text-center py-8">Veri yok</p>
          )}
        </div>

        {/* Category Sales */}
        <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
          <h2 className="text-lg font-bold text-gray-900 mb-6">Kategori Bazında Satış</h2>
          {data.categorySales.length > 0 ? (
            <div className="space-y-4">
              {data.categorySales.map((cat) => (
                <div key={cat.category}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-bold text-gray-700">{cat.category}</span>
                    <span className="font-black text-gray-900">{cat.revenue} TL</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${(cat.revenue / maxCategory) * 100}%` }}
                      className="h-full bg-blue-500 rounded-full"
                    />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-400 font-medium text-center py-8">Veri yok</p>
          )}
        </div>
      </div>

      {/* Top Items */}
      <div className="bg-white rounded-[2rem] border border-gray-100 p-8 shadow-sm">
        <h2 className="text-lg font-bold text-gray-900 mb-6">En Çok Satan Ürünler</h2>
        {data.topItems.length > 0 ? (
          <div className="space-y-4">
            {data.topItems.map((item, i) => (
              <div key={i} className="flex items-center space-x-4">
                <span className="w-8 h-8 bg-gray-100 rounded-xl flex items-center justify-center text-sm font-black text-gray-500 flex-shrink-0">
                  {i + 1}
                </span>
                <div className="flex-grow">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-gray-900 text-sm">{item.name}</span>
                    <span className="font-bold text-gray-700 text-sm">{item.totalRevenue} TL</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="flex-grow h-2 bg-gray-100 rounded-full overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${(item.totalQty / maxItem) * 100}%` }}
                        className="h-full bg-blue-500 rounded-full"
                      />
                    </div>
                    <span className="text-xs font-bold text-gray-400 flex-shrink-0">{item.totalQty} adet</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-gray-400 font-medium text-center py-8">Veri yok</p>
        )}
      </div>
    </div>
  );
}

function SummaryCard({ icon, label, value, bg }: { icon: React.ReactNode; label: string; value: string; bg: string }) {
  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className={`${bg} rounded-[2rem] p-6 flex items-center space-x-4`}>
      <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-sm">{icon}</div>
      <div>
        <div className="text-2xl font-black text-gray-900">{value}</div>
        <div className="text-sm font-medium text-gray-500">{label}</div>
      </div>
    </motion.div>
  );
}

function PaymentBar({ label, amount, total, color, icon }: { label: string; amount: number; total: number; color: string; icon: string }) {
  const pct = total > 0 ? (amount / total) * 100 : 0;
  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <span className="flex items-center space-x-2 font-bold text-gray-700">
          <span>{icon}</span>
          <span>{label}</span>
        </span>
        <span className="font-bold text-gray-900">{amount} TL (%{Math.round(pct)})</span>
      </div>
      <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
        <motion.div initial={{ width: 0 }} animate={{ width: `${pct}%` }} className={`h-full ${color} rounded-full`} />
      </div>
    </div>
  );
}
