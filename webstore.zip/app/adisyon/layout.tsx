import Sidebar from '@/components/apps/adisyon/Sidebar';
import AppGuard from '@/components/AppGuard';
import InAppGuard from '@/components/InAppGuard';
import { AdisyonRoleProvider } from '@/lib/adisyon/AdisyonRoleContext';
import { ToastProvider } from '@/components/Toast';

export default function AdisyonLayout({ children }: { children: React.ReactNode }) {
  return (
    <AppGuard>
      <AdisyonRoleProvider>
        <InAppGuard>
          <ToastProvider>
            <div className="flex min-h-[calc(100vh-4rem)]">
              <Sidebar />
              <main className="flex-grow bg-gray-50 overflow-auto">
                {children}
              </main>
            </div>
          </ToastProvider>
        </InAppGuard>
      </AdisyonRoleProvider>
    </AppGuard>
  );
}
