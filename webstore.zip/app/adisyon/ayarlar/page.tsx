'use client';

import { useState, useEffect } from 'react';
import { useAdisyonRole } from '@/lib/adisyon/AdisyonRoleContext';
import { useRouter } from 'next/navigation';
import { useToast } from '@/components/Toast';
import { Settings, Table, UserCog, Plus, Trash2, Pencil, Check, X, Save, Eye, EyeOff } from 'lucide-react';

interface Role {
  id: number;
  name: string;
  created_at: string;
}

export default function AyarlarPage() {
  const { isOwner } = useAdisyonRole();
  const router = useRouter();
  const toast = useToast();

  // Table state
  const [tables, setTables] = useState<{ id: number; name: string }[]>([]);
  const [newTableName, setNewTableName] = useState('');
  const [editingTableId, setEditingTableId] = useState<number | null>(null);
  const [editTableName, setEditTableName] = useState('');
  const [tablesLoading, setTablesLoading] = useState(true);

  // Role state
  const [roles, setRoles] = useState<Role[]>([]);
  const [newRoleName, setNewRoleName] = useState('');
  const [newRolePassword, setNewRolePassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rolesLoading, setRolesLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOwner) { router.push('/adisyon'); return; }
    loadTables();
    loadRoles();
  }, [isOwner, router]);

  const token = () => localStorage.getItem('token');

  async function loadTables() {
    try {
      const res = await fetch('/api/adisyon/state', {
        headers: { Authorization: `Bearer ${token()}` },
      });
      const data = await res.json();
      if (data.tables?.length > 0) {
        setTables(data.tables.map((t: any) => ({ id: t.id, name: t.name })));
      } else {
        setTables(Array.from({ length: 12 }, (_, i) => ({ id: i + 1, name: `Masa ${i + 1}` })));
      }
    } catch {} finally {
      setTablesLoading(false);
    }
  }

  async function saveTables(newTables: { id: number; name: string }[]) {
    setTables(newTables);
    try {
      await fetch('/api/adisyon/state', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` },
        body: JSON.stringify({ tables: newTables }),
      });
    } catch {}
  }

  function addTable() {
    if (!newTableName.trim()) return;
    const maxId = tables.reduce((max, t) => Math.max(max, t.id), 0);
    saveTables([...tables, { id: maxId + 1, name: newTableName.trim() }]);
    setNewTableName('');
    toast.show('Masa eklendi', 'success');
  }

  function startEditTable(table: { id: number; name: string }) {
    setEditingTableId(table.id);
    setEditTableName(table.name);
  }

  function saveEditTable(id: number) {
    if (!editTableName.trim()) return;
    saveTables(tables.map(t => t.id === id ? { ...t, name: editTableName.trim() } : t));
    setEditingTableId(null);
    toast.show('Masa adı güncellendi', 'success');
  }

  function deleteTable(id: number) {
    saveTables(tables.filter(t => t.id !== id));
    toast.show('Masa silindi', 'info');
  }

  async function loadRoles() {
    try {
      const res = await fetch('/api/adisyon/roles', {
        headers: { Authorization: `Bearer ${token()}` },
      });
      if (res.ok) {
        const data = await res.json();
        setRoles(data.roles);
      }
    } catch {} finally {
      setRolesLoading(false);
    }
  }

  async function addRole() {
    setError('');
    if (!newRoleName.trim() || !newRolePassword.trim()) {
      setError('Rol adı ve şifre zorunludur');
      return;
    }
    try {
      const res = await fetch('/api/adisyon/roles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token()}` },
        body: JSON.stringify({ name: newRoleName.trim(), password: newRolePassword }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setRoles(prev => [...prev, data.role]);
      setNewRoleName('');
      setNewRolePassword('');
      toast.show('Rol oluşturuldu', 'success');
    } catch (err: any) {
      setError(err.message);
    }
  }

  async function deleteRole(id: number) {
    try {
      await fetch(`/api/adisyon/roles/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token()}` },
      });
      setRoles(prev => prev.filter(r => r.id !== id));
      toast.show('Rol silindi', 'info');
    } catch {}
  }

  if (!isOwner) return null;

  return (
    <div className="max-w-4xl mx-auto px-6 py-10 space-y-12">
      {/* Header */}
      <div className="flex items-center space-x-4">
        <div className="w-12 h-12 bg-gray-900 rounded-2xl flex items-center justify-center">
          <Settings className="h-6 w-6 text-white" />
        </div>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 tracking-tight">Ayarlar</h1>
          <p className="text-gray-500 font-medium">Masa ve personel yönetimi</p>
        </div>
      </div>

      {/* Table Management */}
      <section className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
        <div className="flex items-center space-x-3 mb-6">
          <Table className="h-6 w-6 text-gray-900" />
          <h2 className="text-xl font-bold text-gray-900 tracking-tight">Masa Yönetimi</h2>
        </div>

        {tablesLoading ? (
          <div className="text-center py-12 text-gray-500 font-medium">Yükleniyor...</div>
        ) : (
          <>
            <div className="space-y-2 mb-6">
              {tables.map(table => (
                <div key={table.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                  {editingTableId === table.id ? (
                    <div className="flex items-center space-x-2 flex-grow">
                      <input
                        type="text"
                        value={editTableName}
                        onChange={e => setEditTableName(e.target.value)}
                        className="flex-grow px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500"
                        autoFocus
                      />
                      <button
                        onClick={() => saveEditTable(table.id)}
                        className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                      >
                        <Check className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => setEditingTableId(null)}
                        className="p-2 text-gray-400 hover:bg-gray-100 rounded-lg transition-colors"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <span className="font-medium text-gray-900">{table.name}</span>
                      <div className="flex items-center space-x-1">
                        <button
                          onClick={() => startEditTable(table)}
                          className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Pencil className="h-4 w-4" />
                        </button>
                        <button
                          onClick={() => deleteTable(table.id)}
                          className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>
              ))}
            </div>

            <div className="flex items-center space-x-3">
              <input
                type="text"
                value={newTableName}
                onChange={e => setNewTableName(e.target.value)}
                placeholder="Yeni masa adı"
                className="flex-grow px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500"
                onKeyDown={e => e.key === 'Enter' && addTable()}
              />
              <button
                onClick={addTable}
                disabled={!newTableName.trim()}
                className="flex items-center space-x-2 px-5 py-3 bg-gray-900 text-white font-bold rounded-xl hover:bg-gray-800 transition-all disabled:opacity-50"
              >
                <Plus className="h-4 w-4" />
                <span>Masa Ekle</span>
              </button>
            </div>
          </>
        )}
      </section>

      {/* Role Management */}
      <section className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
        <div className="flex items-center space-x-3 mb-6">
          <UserCog className="h-6 w-6 text-gray-900" />
          <h2 className="text-xl font-bold text-gray-900 tracking-tight">Personel Rolleri</h2>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 text-red-600 rounded-xl text-sm font-medium">{error}</div>
        )}

        {rolesLoading ? (
          <div className="text-center py-12 text-gray-500 font-medium">Yükleniyor...</div>
        ) : (
          <>
            <div className="space-y-2 mb-6">
              {roles.length === 0 ? (
                <p className="text-center py-8 text-gray-400 font-medium">Henüz rol tanımlanmamış</p>
              ) : (
                roles.map(role => (
                  <div key={role.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                        <UserCog className="h-4 w-4 text-emerald-600" />
                      </div>
                      <span className="font-medium text-gray-900">{role.name}</span>
                    </div>
                    <button
                      onClick={() => deleteRole(role.id)}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                ))
              )}
            </div>

            <div className="bg-gray-50 rounded-2xl p-5 space-y-4">
              <h3 className="font-bold text-gray-900 text-sm">Yeni Rol Ekle</h3>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  value={newRoleName}
                  onChange={e => setNewRoleName(e.target.value)}
                  placeholder="Rol adı (örn. garson)"
                  className="px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500"
                />
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={newRolePassword}
                    onChange={e => setNewRolePassword(e.target.value)}
                    placeholder="Rol şifresi"
                    className="w-full px-4 py-3 bg-white border border-gray-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500 pr-10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <button
                onClick={addRole}
                disabled={!newRoleName.trim() || !newRolePassword.trim()}
                className="flex items-center space-x-2 px-5 py-3 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 transition-all disabled:opacity-50"
              >
                <Save className="h-4 w-4" />
                <span>Rol Ekle</span>
              </button>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
